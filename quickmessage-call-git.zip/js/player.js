// Our own audio and video players (the browser's default controls differ everywhere). The audio player draws a waveform.
import { icon } from "./ui.js";

const fmt = s => { if (!isFinite(s) || s < 0) s = 0; const m = Math.floor(s / 60), r = Math.floor(s % 60); return m + ":" + String(r).padStart(2, "0"); };
const SPEEDS = [1, 1.25, 1.5, 2, 0.75];
const mk = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const btn = (cls, label, html) => { const b = mk("button", cls, html); b.type = "button"; b.setAttribute("aria-label", label); b.title = label; return b; };

// One media element plays at a time.
let current = null;
function exclusive(m) { if (current && current !== m) { try { current.pause(); } catch (_) { /* ignore */ } } current = m; }

// ------------------------------------------------------------------ waveform
const BARS = 64;
function pseudoPeaks(seed) {
  let h = 2166136261; for (const c of String(seed)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  const out = []; for (let i = 0; i < BARS; i++) { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; out.push(0.25 + 0.7 * ((h >>> 0) % 1000) / 1000 * (0.6 + 0.4 * Math.sin(i / 5))); }
  return out;
}
async function realPeaks(src) {
  const r = await fetch(src); if (!r.ok) throw new Error("fetch");
  const len = +r.headers.get("content-length") || 0; if (len > 25e6) throw new Error("big");
  const buf = await r.arrayBuffer(); if (buf.byteLength > 25e6) throw new Error("big");
  const AC = window.OfflineAudioContext || window.webkitOfflineAudioContext || window.AudioContext;
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  try {
    const au = await ctx.decodeAudioData(buf);
    const d = au.getChannelData(0), step = Math.max(1, Math.floor(d.length / BARS)), out = [];
    for (let i = 0; i < BARS; i++) { let max = 0; for (let j = i * step; j < Math.min(d.length, (i + 1) * step); j += Math.max(1, step >> 6)) max = Math.max(max, Math.abs(d[j])); out.push(max); }
    const top = Math.max(...out, 0.01);
    return out.map(v => Math.max(0.08, v / top));
  } finally { try { ctx.close(); } catch (_) { /* ignore */ } }
}

function drawWave(cv, peaks, frac) {
  const dpr = devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
  if (!w || !h) return;
  if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
  const g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
  const cs = getComputedStyle(cv), on = cs.getPropertyValue("--qp-on").trim() || "#4f46e5", off = cs.getPropertyValue("--qp-off").trim() || "#9aa3b8";
  const n = peaks.length, gap = 2, bw = Math.max(2, (w - gap * (n - 1)) / n);
  for (let i = 0; i < n; i++) {
    const bh = Math.max(3, peaks[i] * h), x = i * (bw + gap);
    g.fillStyle = (i + 0.5) / n <= frac ? on : off;
    g.beginPath(); (g.roundRect || g.rect).call(g, x, (h - bh) / 2, bw, bh, 2); g.fill();
  }
}

export function audioPlayer(src, { title = "" } = {}) {
  const root = mk("div", "qp qp-audio");
  const a = new Audio(); a.preload = "metadata"; a.src = src;
  const play = btn("qp-btn qp-play", "Play", icon("play", 20));
  const wave = mk("canvas", "qp-wave"); wave.setAttribute("role", "slider"); wave.setAttribute("aria-label", "Seek"); wave.tabIndex = 0;
  const time = mk("span", "qp-time", "0:00");
  const spd = btn("qp-btn qp-speed", "Playback speed", "1×");
  root.append(play, wave, time, spd);
  if (title) root.title = title;
  let peaks = pseudoPeaks(src.slice(0, 200)), frac = 0, dur = 0;
  const paint = () => drawWave(wave, peaks, frac);
  const upd = () => { dur = a.duration; frac = dur ? a.currentTime / dur : 0; time.textContent = a.paused && !a.currentTime ? fmt(dur) : fmt(a.currentTime) + " / " + fmt(dur); paint(); };
  a.addEventListener("loadedmetadata", upd); a.addEventListener("durationchange", upd); a.addEventListener("timeupdate", upd);
  a.addEventListener("play", () => { exclusive(a); play.innerHTML = icon("pause", 20); play.title = "Pause"; });
  a.addEventListener("pause", () => { play.innerHTML = icon("play", 20); play.title = "Play"; });
  a.addEventListener("ended", () => { a.currentTime = 0; upd(); });
  a.addEventListener("error", () => { time.textContent = "Can't play"; });
  play.onclick = () => (a.paused ? a.play().catch(() => {}) : a.pause());
  spd.onclick = () => { const i = (SPEEDS.indexOf(a.playbackRate) + 1) % SPEEDS.length; a.playbackRate = SPEEDS[i]; spd.textContent = SPEEDS[i] + "×"; };
  const seekTo = e => { const r = wave.getBoundingClientRect(); const f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); if (dur) { a.currentTime = f * dur; upd(); } };
  let dragging = false;
  wave.addEventListener("pointerdown", e => { dragging = true; wave.setPointerCapture(e.pointerId); seekTo(e); });
  wave.addEventListener("pointermove", e => { if (dragging) seekTo(e); });
  wave.addEventListener("pointerup", () => { dragging = false; });
  wave.addEventListener("keydown", e => { if (e.key === "ArrowRight") a.currentTime += 5; else if (e.key === "ArrowLeft") a.currentTime -= 5; else if (e.key === " ") { e.preventDefault(); play.click(); } });
  // real waveform once the bubble is on screen (falls back to the generated one if the file can't be read, e.g. no CORS)
  let started = false;
  const go = () => { if (started) return; started = true; realPeaks(src).then(p => { peaks = p; paint(); }).catch(() => {}); };
  if ("IntersectionObserver" in window) { const io = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) { io.disconnect(); go(); paint(); } }); io.observe(root); } else go();
  new ResizeObserver(paint).observe(wave);
  root.audio = a;
  return root;
}

// ------------------------------------------------------------------ video
export function videoPlayer(src, { poster = "", onLayout, autoplay = false, title = "" } = {}) {
  const root = mk("div", "qp qp-video paused");
  root.tabIndex = 0;
  const v = document.createElement("video"); v.playsInline = true; v.preload = "metadata"; v.src = src; if (poster) v.poster = poster; if (title) v.title = title;
  v.setAttribute("webkit-playsinline", "");
  const big = btn("qp-big", "Play", icon("play", 34));
  const bar = mk("div", "qp-bar");
  const play = btn("qp-btn qp-play", "Play", icon("play", 18));
  const cur = mk("span", "qp-time", "0:00");
  const seek = mk("div", "qp-seek"); const buf = mk("div", "qp-buf"); const fill = mk("div", "qp-fill"); const knob = mk("div", "qp-knob");
  seek.append(buf, fill, knob); seek.setAttribute("role", "slider"); seek.setAttribute("aria-label", "Seek"); seek.tabIndex = 0;
  const dur = mk("span", "qp-time", "0:00");
  const mute = btn("qp-btn", "Mute", icon("volume", 18));
  const vol = document.createElement("input"); vol.type = "range"; vol.min = 0; vol.max = 1; vol.step = 0.05; vol.value = 1; vol.className = "qp-vol"; vol.setAttribute("aria-label", "Volume");
  const spd = btn("qp-btn qp-speed", "Playback speed", "1×");
  const pip = document.pictureInPictureEnabled ? btn("qp-btn", "Picture in picture", icon("pip", 18)) : null;
  const fs = btn("qp-btn", "Full screen", icon("maximize", 18));
  bar.append(play, cur, seek, dur, mute, vol, spd, ...(pip ? [pip] : []), fs);
  root.append(v, big, bar);

  const setPlaying = p => { root.classList.toggle("paused", !p); play.innerHTML = icon(p ? "pause" : "play", 18); big.innerHTML = icon("play", 34); play.title = p ? "Pause" : "Play"; };
  v.addEventListener("play", () => { exclusive(v); setPlaying(true); wake(); });
  v.addEventListener("pause", () => { setPlaying(false); root.classList.add("show"); });
  v.addEventListener("ended", () => { root.classList.add("show"); });
  const upd = () => { const d = v.duration || 0; fill.style.width = knob.style.left = (d ? v.currentTime / d * 100 : 0) + "%"; cur.textContent = fmt(v.currentTime); dur.textContent = fmt(d); if (v.buffered.length && d) buf.style.width = v.buffered.end(v.buffered.length - 1) / d * 100 + "%"; };
  v.addEventListener("timeupdate", upd); v.addEventListener("progress", upd); v.addEventListener("durationchange", upd);
  v.addEventListener("loadedmetadata", () => { upd(); onLayout && onLayout(v); });
  v.addEventListener("error", () => { root.classList.add("failed"); cur.textContent = "Can't play"; });
  v.addEventListener("volumechange", () => { mute.innerHTML = icon(v.muted || v.volume === 0 ? "volumeX" : "volume", 18); vol.value = v.muted ? 0 : v.volume; });
  const toggle = () => (v.paused ? v.play().catch(() => {}) : v.pause());
  play.onclick = toggle; big.onclick = toggle;
  v.addEventListener("click", () => { toggle(); });
  v.addEventListener("dblclick", () => fs.click());
  mute.onclick = () => { v.muted = !v.muted; };
  vol.oninput = () => { v.muted = false; v.volume = +vol.value; };
  spd.onclick = () => { const i = (SPEEDS.indexOf(v.playbackRate) + 1) % SPEEDS.length; v.playbackRate = SPEEDS[i]; spd.textContent = SPEEDS[i] + "×"; };
  if (pip) pip.onclick = () => { if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {}); else v.requestPictureInPicture().catch(() => {}); };
  fs.onclick = () => {
    const on = document.fullscreenElement || document.webkitFullscreenElement;
    if (on) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else if (root.requestFullscreen) root.requestFullscreen().catch(() => {});
    else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen();
  };
  document.addEventListener("fullscreenchange", () => { const on = document.fullscreenElement === root; root.classList.toggle("fullscreen", on); fs.innerHTML = icon(on ? "minimize" : "maximize", 18); });
  let dragging = false;
  const seekTo = e => { const r = seek.getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); if (v.duration) { v.currentTime = f * v.duration; upd(); } };
  seek.addEventListener("pointerdown", e => { dragging = true; seek.setPointerCapture(e.pointerId); seekTo(e); });
  seek.addEventListener("pointermove", e => { if (dragging) seekTo(e); });
  seek.addEventListener("pointerup", () => { dragging = false; });
  seek.addEventListener("keydown", e => { if (e.key === "ArrowRight") v.currentTime += 5; else if (e.key === "ArrowLeft") v.currentTime -= 5; });
  root.addEventListener("keydown", e => {
    if (e.target !== root) return;
    if (e.key === " " || e.key === "k") { e.preventDefault(); toggle(); } else if (e.key === "ArrowRight") v.currentTime += 5; else if (e.key === "ArrowLeft") v.currentTime -= 5;
    else if (e.key === "f") fs.click(); else if (e.key === "m") mute.click();
  });
  // controls fade out while playing
  let hideT = null;
  function wake() { root.classList.add("show"); clearTimeout(hideT); if (!v.paused) hideT = setTimeout(() => root.classList.remove("show"), 2500); }
  root.addEventListener("pointermove", wake); root.addEventListener("pointerdown", wake); root.addEventListener("focusin", wake);
  if (autoplay) v.play().catch(() => {});
  root.video = v;
  return root;
}
