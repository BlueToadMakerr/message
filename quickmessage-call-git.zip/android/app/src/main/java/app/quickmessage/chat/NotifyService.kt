package app.quickmessage.chat

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Native notifications, independent of the page being open (a WebView can't receive web push reliably):
 *   - incoming calls: a full-screen alert (callRings/{you}) that opens the app on the call
 *   - new messages: a notification per chat (privateChats/{chat}/lastMessage), only while the app isn't on screen
 * It talks to the database directly with the signed-in account's token, handed over by the website (js/app-bridge.js).
 */
class NotifyService : Service() {
    companion object {
        private const val CH_RUN = "run"
        private const val CH_MSG = "messages"
        private const val CH_CALL = "calls2"
        private const val ACT_REPLY = "app.quickmessage.REPLY"
        private const val ACT_DECLINE = "app.quickmessage.DECLINE"
        private const val KEY_REPLY = "reply"
        private const val ID_FG = 1
        private const val MAX_CHATS = 40

        @Volatile var inCall = false

        /** Tells the service a call is up, so it can hold the camera/microphone foreground types (Android blocks background capture otherwise). */
        fun setCall(ctx: Context, on: Boolean) {
            inCall = on
            val i = Intent(ctx, NotifyService::class.java).putExtra("call", on)
            try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {}
        }

        fun start(ctx: Context) {
            val st = Store(ctx)
            if (!st.signedIn || (!st.notify && !inCall)) return
            val i = Intent(ctx, NotifyService::class.java)
            try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {}
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, NotifyService::class.java)); cancelAll(ctx) }
        fun cancelAll(ctx: Context) { (ctx.getSystemService(NOTIFICATION_SERVICE) as NotificationManager).let { nm -> nm.cancelAll(); } }
    }

    @Volatile private var running = false
    private var wake: android.os.PowerManager.WakeLock? = null
    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val names = ConcurrentHashMap<String, String>()
    private val chatThreads = ConcurrentHashMap<String, Thread>()
    private val seenRings = HashSet<String>()
    private class Msg(val id: String, val text: String, val ts: Long, val from: String?)   // from == null → me
    private val history = ConcurrentHashMap<String, MutableList<Msg>>()
    private val titles = ConcurrentHashMap<String, String>()

    override fun onBind(i: Intent?): IBinder? = null
    private fun nm() = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        store = Store(this)
        fb = Firebase(store)
        when (intent?.action) {
            ACT_REPLY -> { handleReply(intent); return START_STICKY }
            ACT_DECLINE -> { handleDecline(intent); return START_STICKY }
        }
        if (intent?.hasExtra("call") == true) inCall = intent.getBooleanExtra("call", false)
        if (!store.signedIn && !inCall) { stopSelf(); return START_NOT_STICKY }
        fb = Firebase(store)
        foreground()
        holdWake()
        if (!inCall && !store.notify) { running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        if (!running && store.signedIn) {
            running = true
            Thread({ ringsLoop() }, "rings").start()
            Thread({ chatsLoop() }, "chats").start()
        }
        return START_STICKY
    }

    // Keeps the CPU awake so the live connections (and the page's own) keep running while the screen is off.
    private fun holdWake() {
        if (wake?.isHeld == true) return
        wake = (getSystemService(POWER_SERVICE) as android.os.PowerManager).newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "quickmessage:listen").also { it.setReferenceCounted(false); it.acquire() }
    }

    override fun onDestroy() { try { wake?.release() } catch (_: Exception) {}; running = false; chatThreads.values.forEach { it.interrupt() }; chatThreads.clear(); super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun builder(ch: String) = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun foreground() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel(CH_RUN, "Running in background", NotificationManager.IMPORTANCE_MIN))
            nm().createNotificationChannel(NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH))
            nm().deleteNotificationChannel("calls")
            nm().createNotificationChannel(NotificationChannel(CH_CALL, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC; enableVibration(true)
                vibrationPattern = longArrayOf(0, 800, 600, 800, 600)
                setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE),
                    android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIC).build())
                setBypassDnd(true) })
        }
        val n = builder(CH_RUN).setContentTitle("QuickMessage").setContentText(if (inCall) "In a call" else "Listening for messages and calls")
            .setSmallIcon(android.R.drawable.stat_notify_chat).setOngoing(true).setContentIntent(open(null, false, 0)).build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (inCall) {   // keep the call's microphone/camera alive while the app is in the background
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            try { startForeground(ID_FG, n, t) } catch (e: Exception) { startForeground(ID_FG, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        } else startForeground(ID_FG, n)
    }

    private fun open(chat: String?, ring: Boolean, req: Int, answer: Boolean = false): PendingIntent {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (chat != null) i.putExtra(MainActivity.EXTRA_CHAT, chat)
        if (ring) i.putExtra(MainActivity.EXTRA_RING, true)
        if (answer) i.putExtra(MainActivity.EXTRA_ANSWER, true)
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun nameOf(uid: String): String = names.getOrPut(uid) {
        try { (fb.get("accsettings/$uid/settings/displayName") as? String)?.takeIf { it.isNotBlank() } ?: "Someone" } catch (_: Exception) { "Someone" }
    }

    private fun nap(ms: Long): Boolean = try { Thread.sleep(ms); true } catch (_: InterruptedException) { false }

    /** Runs [body] again (with a growing pause) whenever the stream ends or fails; stops when the service stops or we sign out. */
    private fun forever(body: () -> Unit) {
        var backoff = 2000L
        while (running && store.signedIn && store.notify) {
            try { body(); backoff = 2000L }
            catch (e: ApiException) { if (e.code == 401 || e.code == 403) backoff = 60_000L }
            catch (_: Exception) {}
            if (!nap(backoff)) return
            backoff = (backoff * 2).coerceAtMost(60_000L)
        }
    }

    // ------------------------------------------------------------------ incoming calls
    private fun ringsLoop() = forever {
        val me = store.uid ?: return@forever
        fb.stream("callRings/$me", { running }) { _, path, data ->
            val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
            when {
                parts.isEmpty() && data is JSONObject -> data.keys().forEach { k -> data.optJSONObject(k)?.let { ring(k, it) } }
                parts.size == 1 && data is JSONObject -> ring(parts[0], data)
                parts.size == 1 && data == null -> nm().cancel(("ring" + parts[0]).hashCode())
            }
        }
    }

    private fun ring(chatId: String, r: JSONObject) {
        if (!store.notify) return
        val me = store.uid ?: return
        val id = r.optString("ringId"); val from = r.optString("fromUid")
        if (id.isEmpty() || from == me || !seenRings.add(id)) return
        if (System.currentTimeMillis() - r.optLong("createdAt", 0) > 90_000) return     // an old ring left behind
        if (MainActivity.visible) return                                                // the page shows its own call overlay
        val who = nameOf(from)
        val rid = ("ring$chatId").hashCode()
        val pi = open(chatId, true, rid)
        val answer = open(chatId, true, rid + 1, answer = true)
        val decline = PendingIntent.getService(this, rid + 2, Intent(this, NotifyService::class.java).setAction(ACT_DECLINE).putExtra("chat", chatId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = builder(CH_CALL).setSmallIcon(android.R.drawable.sym_action_call).setCategory(Notification.CATEGORY_CALL)
            .setPriority(Notification.PRIORITY_MAX).setOngoing(true).setAutoCancel(false).setContentIntent(pi).setFullScreenIntent(pi, true)
            .setTimeoutAfter(60_000).setVisibility(Notification.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT >= 31) {
            val person = android.app.Person.Builder().setName(who).setImportant(true).build()
            b.setStyle(Notification.CallStyle.forIncomingCall(person, decline, answer))
        } else {
            b.setContentTitle("Incoming call").setContentText("$who is calling you")
                .addAction(Notification.Action.Builder(null, "Decline", decline).build())
                .addAction(Notification.Action.Builder(null, "Answer", answer).build())
        }
        val n = b.build()
        n.flags = n.flags or Notification.FLAG_INSISTENT or Notification.FLAG_NO_CLEAR        // the ringtone keeps looping until you act
        nm().notify(rid, n)
    }

    private fun handleDecline(i: Intent) {
        val chat = i.getStringExtra("chat") ?: return
        nm().cancel(("ring$chat").hashCode())
        val me = store.uid ?: return
        Thread {
            try { fb.delete("callRings/$me/$chat") } catch (_: Exception) {}
            try { fb.delete("calls/$chat/ringing/$me") } catch (_: Exception) {}
        }.start()
    }

    // ------------------------------------------------------------------ messages
    private fun chatsLoop() = forever {
        val me = store.uid ?: return@forever
        fb.stream("chatList/$me", { running }) { _, path, data ->
            val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
            when {
                parts.isEmpty() && data is JSONObject -> data.keys().forEach { watchChat(it) }
                parts.size == 1 && data != null -> watchChat(parts[0])
            }
        }
    }

    private fun watchChat(chatId: String) {
        if (chatThreads.size >= MAX_CHATS || chatThreads.containsKey(chatId)) return
        val t = Thread({
            var baseline: String? = null
            forever {
                fb.stream("privateChats/$chatId/lastMessage", { running }) { _, path, data ->
                    if (path != "/" || data !is JSONObject) return@stream
                    val id = data.optString("id")
                    if (baseline == null) { baseline = id; return@stream }
                    if (id == baseline) return@stream
                    baseline = id
                    message(chatId, data)
                }
            }
        }, "chat-$chatId")
        chatThreads[chatId] = t
        t.start()
    }

    private fun textOf(m: JSONObject): String {
        val t = m.optString("text")
        return when (m.optString("type")) {
            "image" -> "📷 Photo"; "video" -> "🎥 Video"
            "file" -> "📎 " + t.ifBlank { "File" }
            "event" -> "📞 " + t.ifBlank { "Call" }
            else -> t.ifBlank { "Sent an attachment" }
        }
    }

    private fun message(chatId: String, m: JSONObject) {
        if (!store.notify) return
        val me = store.uid ?: return
        val from = m.optString("fromUid")
        if (from == me || MainActivity.visible) return
        var title = ""
        try {
            val chatName = fb.get("privateChats/$chatId/chatData/name") as? String
            if (!chatName.isNullOrBlank()) title = chatName
        } catch (_: Exception) {}
        titles[chatId] = title
        // a little history for the notification: the last few messages of the chat (loaded once, then kept up to date)
        val list = history.getOrPut(chatId) {
            val l = java.util.Collections.synchronizedList(ArrayList<Msg>())
            try { fb.recent("privateChats/$chatId/messages", 6).forEach { (k, o) ->
                val f = o.optString("fromUid"); l.add(Msg(k, textOf(o), o.optLong("timestamp"), if (f == me) null else f)) } } catch (_: Exception) {}
            l
        }
        val id = m.optString("id")
        if (list.none { it.id == id }) list.add(Msg(id, textOf(m), m.optLong("timestamp", System.currentTimeMillis()), from))
        while (list.size > 8) list.removeAt(0)
        postMessages(chatId)
    }

    private fun postMessages(chatId: String) {
        val list = history[chatId] ?: return
        val title = titles[chatId] ?: ""
        val last = synchronized(list) { list.lastOrNull { it.from != null } }
        val lastText = last?.text ?: ""
        val b = builder(CH_MSG).setSmallIcon(android.R.drawable.stat_notify_chat).setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE)
            .setContentIntent(open(chatId, false, chatId.hashCode())).setOnlyAlertOnce(false)
        if (Build.VERSION.SDK_INT >= 28) {
            val meP = android.app.Person.Builder().setName("You").build()
            val style = Notification.MessagingStyle(meP)
            if (title.isNotBlank()) { style.setConversationTitle(title); style.setGroupConversation(true) }
            synchronized(list) { list.toList() }.forEach { msg ->
                val p = if (msg.from == null) meP else android.app.Person.Builder().setName(nameOf(msg.from)).build()
                style.addMessage(msg.text, msg.ts, p)
            }
            b.setStyle(style)
        } else {
            val who = last?.from?.let { nameOf(it) } ?: "New message"
            b.setContentTitle(if (title.isNotBlank()) "$who · $title" else who).setContentText(lastText).setStyle(Notification.BigTextStyle().bigText(lastText))
        }
        // reply straight from the notification
        val ri = android.app.RemoteInput.Builder(KEY_REPLY).setLabel("Reply").build()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getService(this, chatId.hashCode(), Intent(this, NotifyService::class.java).setAction(ACT_REPLY).putExtra("chat", chatId), flags)
        val act = Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Reply", pi)
            .addRemoteInput(ri).setAllowGeneratedReplies(true)
        if (Build.VERSION.SDK_INT >= 28) act.setSemanticAction(Notification.Action.SEMANTIC_ACTION_REPLY)
        b.addAction(act.build())
        nm().notify(chatId.hashCode(), b.build())
    }

    private fun handleReply(i: Intent) {
        val chat = i.getStringExtra("chat") ?: return
        val text = android.app.RemoteInput.getResultsFromIntent(i)?.getCharSequence(KEY_REPLY)?.toString()?.trim()
        val me = store.uid
        if (text.isNullOrEmpty() || me == null) { nm().cancel(chat.hashCode()); return }
        val ts = System.currentTimeMillis()
        val list = history.getOrPut(chat) { java.util.Collections.synchronizedList(ArrayList<Msg>()) }
        list.add(Msg("local$ts", text, ts, null))
        postMessages(chat)                                          // shows your reply in the thread right away
        Thread {
            try {
                val key = fb.post("privateChats/$chat/messages", JSONObject().put("fromUid", me).put("text", text.take(4000)).put("timestamp", ts).toString())
                fb.put("privateChats/$chat/lastMessage", JSONObject().put("fromUid", me).put("text", text.take(4000)).put("timestamp", ts).put("id", key).toString())
                synchronized(list) { list.removeAll { it.id == "local$ts" }; list.add(Msg(key, text, ts, null)) }
            } catch (_: Exception) {
                android.os.Handler(mainLooper).post { android.widget.Toast.makeText(this, "Couldn't send your reply", android.widget.Toast.LENGTH_SHORT).show() }
            }
            postMessages(chat)
        }.start()
    }
}
