// Android companion (website side). The website stays the "brain"; a paired Android app is a remote camera/mic/screen device.
// Data model (all in Realtime Database, see database.rules.json):
//   pairings/{code}                   {uid, expiresAt, claim?:{authUid, deviceId, name}}   short-lived, created here, claimed by the app
//   companionAuth/{appAuthUid}        {owner, deviceId, name}     written here when you confirm a pairing; the app's "credential"
//   companions/{uid}/{deviceId}       {name, authUid, pairedAt}   your device list
//   companionLink/{uid}/{deviceId}    state (written by the app: online, lastSeen, capabilities, media) + commands (written here)
import { db } from "./firebase.js";
import { ref, set, get, update, remove, push, onValue, onDisconnect } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";

export const CODE_TTL_MS = 5 * 60 * 1000;
export const ONLINE_MS = 60 * 1000;     // the app heartbeats every 20 s

const newCode = () => String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, "0");

/** Create a pairing request. Resolves with { code, expiresAt, stop() }; onClaim(claim|null) fires when an app enters the code. */
export async function createPairing(uid, onClaim) {
  for (let i = 0; i < 5; i++) {
    const code = newCode(), r = ref(db, `pairings/${code}`);
    if ((await get(r).catch(() => null))?.exists()) continue;           // vanishingly rare collision
    const expiresAt = Date.now() + CODE_TTL_MS;
    await set(r, { uid, createdAt: Date.now(), expiresAt });
    onDisconnect(r).remove().catch(() => {});
    const un = onValue(ref(db, `pairings/${code}/claim`), s => onClaim && onClaim(s.val()));
    return { code, expiresAt, stop: () => { un(); remove(r).catch(() => {}); onDisconnect(r).cancel().catch(() => {}); } };
  }
  throw new Error("Couldn't create a pairing code. Try again.");
}

/** You confirmed the device that claimed the code: this is the moment it becomes paired. */
export async function confirmPairing(uid, code, claim) {
  await update(ref(db), {
    [`companionAuth/${claim.authUid}`]: { owner: uid, deviceId: claim.deviceId, name: claim.name },
    [`companions/${uid}/${claim.deviceId}`]: { name: claim.name, authUid: claim.authUid, pairedAt: Date.now() },
    [`pairings/${code}`]: null
  });
}

export const rejectPairing = code => remove(ref(db, `pairings/${code}`));

/** Unpair: the app's credential stops working immediately (its companionAuth node is gone). */
export async function unpair(uid, deviceId, authUid) {
  await update(ref(db), {
    [`companionAuth/${authUid}`]: null,
    [`companions/${uid}/${deviceId}`]: null,
    [`companionLink/${uid}/${deviceId}`]: null
  });
}

/** Live device list with presence: cb([{deviceId, name, authUid, online, lastSeen, caps, media}]) */
export function watchCompanions(uid, cb) {
  let list = {}, states = {};
  const emit = () => cb(Object.entries(list).map(([deviceId, d]) => {
    const st = states[deviceId] || {};
    const online = st.online === true && typeof st.lastSeen === "number" && Date.now() - st.lastSeen < ONLINE_MS;
    return { deviceId, ...d, online, lastSeen: st.lastSeen || null, caps: st.capabilities || null, media: st.media || null };
  }));
  const u1 = onValue(ref(db, `companions/${uid}`), s => { list = s.val() || {}; emit(); }, () => {});
  const u2 = onValue(ref(db, `companionLink/${uid}`), s => {
    states = {}; for (const [id, v] of Object.entries(s.val() || {})) states[id] = v.state || {};
    emit();
  }, () => {});
  const tick = setInterval(emit, 15000);
  return () => { u1(); u2(); clearInterval(tick); };
}

/** Send a command to one specific device (never "any device"). Types: ping, set-microphone, set-camera, set-screen. */
export function sendCommand(uid, deviceId, cmd) {
  const r = push(ref(db, `companionLink/${uid}/${deviceId}/commands`));
  return set(r, { ...cmd, t: Date.now(), id: r.key }).then(() => r.key);
}
