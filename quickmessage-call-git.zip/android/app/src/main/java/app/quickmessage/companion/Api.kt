package app.quickmessage.companion

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Project settings. Copy these from js/firebase.js on the website. */
object Config {
    const val API_KEY = "AIzaSyBNynmpC9-jTZd56WnpsjnbJa7THeyTMWY"
    // The default Realtime Database URL for project quickmessage-ac953. If your database was created in another region it
    // looks like https://quickmessage-ac953-default-rtdb.<region>.firebasedatabase.app (see Firebase console > Realtime Database).
    const val DB_URL = "https://quickmessage-ac953-default-rtdb.firebaseio.com"
}

class ApiException(val code: Int, message: String) : Exception(message)

/** Persistent app state. The refresh token + deviceId are the "companion token": there is no login in this app. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("companion", Context.MODE_PRIVATE)
    private fun str(k: String): String? = p.getString(k, null)
    private fun set(k: String, v: String?) { p.edit().putString(k, v).apply() }
    var refreshToken: String?
        get() = str("rt")
        set(v) = set("rt", v)
    var authUid: String?
        get() = str("auid")
        set(v) = set("auid", v)
    var deviceId: String?
        get() = str("did")
        set(v) = set("did", v)
    var owner: String?
        get() = str("owner")
        set(v) = set("owner", v)
    var name: String
        get() = str("name") ?: ""
        set(v) = set("name", v)
    var status: String
        get() = str("status") ?: ""
        set(v) = set("status", v)
    val paired: Boolean get() = owner != null && deviceId != null
    fun forget() { p.edit().remove("owner").remove("did").remove("name").remove("status").apply() }
}

/** Minimal Firebase client over REST (anonymous auth + Realtime Database + server-sent events). */
class Firebase(private val store: Store) {
    @Volatile private var idToken: String? = null
    @Volatile private var tokenAt = 0L

    private fun http(url: String, method: String, body: String? = null, form: Boolean = false, accept: String? = null): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = if (accept != null) 0 else 20000
        if (accept != null) c.setRequestProperty("Accept", accept)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        return c
    }

    private fun read(c: HttpURLConnection): String {
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw ApiException(code, text.take(200))
        return text
    }

    /** Signs in anonymously the first time, then silently refreshes. The anonymous uid stays the same for this install. */
    @Synchronized fun token(): String {
        val cur = idToken
        if (cur != null && System.currentTimeMillis() - tokenAt < 50 * 60 * 1000) return cur
        val rt = store.refreshToken
        if (rt != null) {
            val j = JSONObject(read(http("https://securetoken.googleapis.com/v1/token?key=${Config.API_KEY}", "POST",
                "grant_type=refresh_token&refresh_token=$rt", form = true)))
            store.refreshToken = j.getString("refresh_token"); store.authUid = j.getString("user_id")
            idToken = j.getString("id_token")
        } else {
            val j = JSONObject(read(http("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${Config.API_KEY}", "POST",
                "{\"returnSecureToken\":true}")))
            store.refreshToken = j.getString("refreshToken"); store.authUid = j.getString("localId")
            idToken = j.getString("idToken")
        }
        tokenAt = System.currentTimeMillis()
        return idToken!!
    }

    private fun url(path: String) = "${Config.DB_URL}/${path.trim('/')}.json?auth=${token()}"

    /** Returns the JSON value at [path] (JSONObject, String, Number, Boolean) or null. */
    fun get(path: String): Any? = parse(read(http(url(path), "GET")))
    fun put(path: String, json: String) { read(http(url(path), "PUT", json)) }
    fun patch(path: String, json: String) { read(http(url(path), "PATCH", json)) }
    fun post(path: String, json: String) { read(http(url(path), "POST", json)) }
    fun delete(path: String) { read(http(url(path), "DELETE")) }

    private fun parse(t: String): Any? {
        val s = t.trim()
        return when {
            s == "null" || s.isEmpty() -> null
            s.startsWith("{") -> JSONObject(s)
            s.startsWith("\"") -> org.json.JSONTokener(s).nextValue()
            else -> org.json.JSONTokener(s).nextValue()
        }
    }

    /**
     * Blocks, calling [onEvent](event, path, data) for every put/patch until the stream ends or [alive] turns false.
     * Returns normally when the server closes the stream (token expiry, network) so the caller can reconnect.
     */
    fun stream(path: String, alive: () -> Boolean, onEvent: (String, String, Any?) -> Unit) {
        val c = http(url(path), "GET", accept = "text/event-stream")
        if (c.responseCode !in 200..299) throw ApiException(c.responseCode, c.errorStream?.bufferedReader()?.readText()?.take(200) ?: "")
        BufferedReader(InputStreamReader(c.inputStream)).use { r ->
            var event = ""
            while (alive()) {
                val line = r.readLine() ?: break
                when {
                    line.startsWith("event:") -> event = line.removePrefix("event:").trim()
                    line.startsWith("data:") -> {
                        val d = line.removePrefix("data:").trim()
                        if (event == "put" || event == "patch") {
                            val j = JSONObject(d)
                            onEvent(event, j.optString("path", "/"), if (j.isNull("data")) null else j.get("data"))
                        } else if (event == "cancel" || event == "auth_revoked") break
                    }
                }
            }
        }
        c.disconnect()
    }
}
