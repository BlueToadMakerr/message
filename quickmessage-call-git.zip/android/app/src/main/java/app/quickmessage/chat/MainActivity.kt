package app.quickmessage.chat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.*
import android.widget.FrameLayout

/**
 * QuickMessage as an app: the website runs in a WebView and the app adds what a WebView can't do by itself, through the
 * `QMApp` bridge (see js/app-bridge.js, js/bars.js, js/call/media.js):
 *   - screen sharing (captured natively, streamed into the page)
 *   - notifications for messages and full-screen incoming-call alerts (NotifyService)
 *   - status / navigation bars that follow the site's background colour
 *   - clearing the cache from Account → App
 */
class MainActivity : Activity() {
    companion object {
        @Volatile var visible = false
        @Volatile var instance: MainActivity? = null
        const val EXTRA_CHAT = "chatId"
        const val EXTRA_RING = "ring"
        private const val REQ_PERMS = 1
        private const val REQ_FILE = 2
        private const val REQ_PROJECTION = 3
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var pendingWebPerm: PermissionRequest? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var barColor = Color.WHITE
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        instance = this
        root = FrameLayout(this).apply { setBackgroundColor(barColor) }
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, insets ->
            val top: Int; val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = bars.top; bottom = maxOf(bars.bottom, ime.bottom)
            } else {
                @Suppress("DEPRECATION") run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
            }
            v.setPadding(0, top, 0, bottom)
            insets
        }
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            @Suppress("DEPRECATION") databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = true
            setSupportMultipleWindows(false)
            userAgentString = userAgentString + " QuickMessageApp/1"
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.addJavascriptInterface(Bridge(), "QMApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val site = Uri.parse(Config.SITE_URL)
                if (u.host == site.host || u.scheme == "blob" || u.scheme == "about") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
            override fun onPageFinished(v: WebView, url: String?) { loaded = true }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { askWebPermission(r) } }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { startActivityForResult(p.createIntent(), REQ_FILE); true } catch (_: Exception) { fileCb = null; false }
            }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_PERMS)
        NotifyService.start(this)
        if (b != null) web.restoreState(b) else open(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); open(i) }

    private fun open(i: Intent?) {
        val chat = i?.getStringExtra(EXTRA_CHAT)
        if (i?.getBooleanExtra(EXTRA_RING, false) == true) {
            if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
            else @Suppress("DEPRECATION") window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        val safe = chat != null && Regex("^[\\w-]{1,64}$").matches(chat)
        if (!loaded || web.url == null) { web.loadUrl(Config.SITE_URL + "index.html" + if (safe) "?chat=$chat" else ""); return }
        if (safe) web.evaluateJavascript("window.QM&&QM.openChat&&QM.openChat('$chat')", null)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); web.saveState(o) }
    override fun onStart() { super.onStart(); visible = true; NotifyService.cancelAll(this) }
    override fun onStop() { super.onStop(); visible = false }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { super.onPause(); web.onPause() }
    override fun onDestroy() { if (instance === this) instance = null; web.destroy(); super.onDestroy() }
    @Deprecated("Deprecated in Java") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }

    // ------------------------------------------------------------------ camera / microphone for calls
    private fun askWebPermission(r: PermissionRequest) {
        val need = ArrayList<String>()
        for (res in r.resources) {
            if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) need.add(Manifest.permission.CAMERA)
            if (res == PermissionRequest.RESOURCE_AUDIO_CAPTURE) need.add(Manifest.permission.RECORD_AUDIO)
        }
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { r.grant(r.resources); return }
        pendingWebPerm?.deny(); pendingWebPerm = r
        requestPermissions(missing.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 10) return
        val r = pendingWebPerm ?: return
        pendingWebPerm = null
        val granted = r.resources.filter {
            (it != PermissionRequest.RESOURCE_VIDEO_CAPTURE || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
            (it != PermissionRequest.RESOURCE_AUDIO_CAPTURE || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        }
        if (granted.isEmpty()) r.deny() else r.grant(granted.toTypedArray())
    }

    // ------------------------------------------------------------------ screen share + results
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_FILE -> { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCb = null }
            REQ_PROJECTION -> {
                if (res == RESULT_OK && data != null) {
                    ScreenService.onFrame = { b64 -> runOnUiThread { js("window.__qmScreenFrame&&window.__qmScreenFrame('$b64')") } }
                    ScreenService.onState = { st -> runOnUiThread { js("window.__qmScreenState&&window.__qmScreenState('$st')") } }
                    ScreenService.start(this, res, data)
                } else js("window.__qmScreenState&&window.__qmScreenState('denied')")
            }
        }
    }

    private fun js(code: String) { if (!isDestroyed) web.evaluateJavascript(code, null) }

    /** What the website can call (window.QMApp.*). */
    inner class Bridge {
        @JavascriptInterface fun isApp() = true

        @JavascriptInterface fun startScreen() = runOnUiThread {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
        }

        @JavascriptInterface fun stopScreen() { ScreenService.stop(this@MainActivity) }

        @JavascriptInterface fun setSession(uid: String, refreshToken: String) {
            val s = Store(this@MainActivity)
            if (s.uid != uid || s.refreshToken != refreshToken) { s.uid = uid; s.refreshToken = refreshToken }
            NotifyService.start(this@MainActivity)
        }

        @JavascriptInterface fun logout() { Store(this@MainActivity).forget(); NotifyService.stop(this@MainActivity) }

        @JavascriptInterface fun clearCache() = runOnUiThread { web.clearCache(true) }   // HTTP cache only: signing in lives in site storage, which stays

        /** Colours the area behind the status and navigation bars like the site's background. */
        @JavascriptInterface fun setBars(color: String, lightBackground: Boolean) = runOnUiThread {
            try { barColor = Color.parseColor(color) } catch (_: Exception) { return@runOnUiThread }
            root.setBackgroundColor(barColor)
            if (Build.VERSION.SDK_INT >= 30) {
                val m = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                window.insetsController?.setSystemBarsAppearance(if (lightBackground) m else 0, m)
            } else {
                @Suppress("DEPRECATION") run {
                    var f = window.decorView.systemUiVisibility
                    f = if (lightBackground) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                    window.decorView.systemUiVisibility = f
                }
            }
        }
    }
}
