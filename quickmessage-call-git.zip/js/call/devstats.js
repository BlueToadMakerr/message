import { devCard, devGrid, devPill, devBar, devWho } from "../dev.js";
import { getProfile } from "../users.js";
// Developer mode: a floating panel with live call statistics (WebRTC getStats) and the raw call state. Opened by the small { } button in the call.
const prev = new Map();            // "linkId|ssrc|dir" -> { t, bytes, frames }
const round = (v, d = 1) => (typeof v === "number" && isFinite(v) ? Math.round(v * 10 ** d) / 10 ** d : v);

async function linkStats(sid, link) {
  const pc = link.pc;
  if (!pc) return { note: "no peer connection right now" };
  let rep; try { rep = await pc.getStats(); } catch (e) { return { error: String(e) }; }
  const by = {}; rep.forEach(r => { by[r.id] = r; });
  const now = performance.now();
  const rate = (key, bytes, frames) => {
    const p = prev.get(key); prev.set(key, { t: now, bytes, frames });
    if (!p || now <= p.t) return {};
    return { kbps: round(((bytes - p.bytes) * 8) / (now - p.t)), fpsMeasured: frames == null || p.frames == null ? undefined : round(((frames - p.frames) * 1000) / (now - p.t)) };
  };
  const out = { connection: pc.connectionState, ice: pc.iceConnectionState, gathering: pc.iceGatheringState, signaling: pc.signalingState, linkState: link.state, epoch: link.epoch, iceRestarts: link._iceRestarts, resets: link._resets, outbound: [], inbound: [] };
  let pair = null;
  rep.forEach(r => { if (r.type === "transport" && r.selectedCandidatePairId) pair = by[r.selectedCandidatePairId] || pair; });
  if (!pair) rep.forEach(r => { if (r.type === "candidate-pair" && (r.nominated || r.selected) && r.state === "succeeded") pair = r; });
  if (pair) {
    const cand = c => c && { type: c.candidateType, protocol: c.protocol, network: c.networkType, address: c.address || c.ip, port: c.port, relayProtocol: c.relayProtocol };
    out.path = { local: cand(by[pair.localCandidateId]), remote: cand(by[pair.remoteCandidateId]), rttMs: round((pair.currentRoundTripTime || 0) * 1000), availableOutKbps: round((pair.availableOutgoingBitrate || 0) / 1000), availableInKbps: round((pair.availableIncomingBitrate || 0) / 1000), bytesSent: pair.bytesSent, bytesReceived: pair.bytesReceived, requestsSent: pair.requestsSent, responsesReceived: pair.responsesReceived };
  }
  try { const c = pc.getConfiguration(); out.config = { iceTransportPolicy: c.iceTransportPolicy, bundlePolicy: c.bundlePolicy, iceServers: (c.iceServers || []).map(s => ({ urls: s.urls })) }; } catch (_) { /* ignore */ }
  rep.forEach(r => {
    const codec = r.codecId && by[r.codecId] ? by[r.codecId].mimeType : undefined;
    if (r.type === "outbound-rtp" && !r.isRemote) {
      out.outbound.push({ kind: r.kind, ssrc: r.ssrc, content: r.contentType, codec, ...rate(`${sid}|${r.ssrc}|o`, r.bytesSent || 0, r.framesEncoded), fps: r.framesPerSecond, size: r.frameWidth ? `${r.frameWidth}×${r.frameHeight}` : undefined, framesEncoded: r.framesEncoded, targetKbps: r.targetBitrate ? round(r.targetBitrate / 1000) : undefined, limited: r.qualityLimitationReason, limitDurations: r.qualityLimitationDurations, encoder: r.encoderImplementation, nack: r.nackCount, pli: r.pliCount, retransmittedBytes: r.retransmittedBytesSent, packetsSent: r.packetsSent });
    } else if (r.type === "inbound-rtp" && !r.isRemote) {
      out.inbound.push({ kind: r.kind, ssrc: r.ssrc, codec, ...rate(`${sid}|${r.ssrc}|i`, r.bytesReceived || 0, r.framesDecoded), fps: r.framesPerSecond, size: r.frameWidth ? `${r.frameWidth}×${r.frameHeight}` : undefined, framesDecoded: r.framesDecoded, framesDropped: r.framesDropped, packetsLost: r.packetsLost, packetsReceived: r.packetsReceived, jitterMs: round((r.jitter || 0) * 1000), jitterBufferMs: r.jitterBufferEmittedCount ? round((r.jitterBufferDelay / r.jitterBufferEmittedCount) * 1000) : undefined, freezes: r.freezeCount, decoder: r.decoderImplementation, audioLevel: r.audioLevel, concealedSamples: r.concealedSamples, nack: r.nackCount, pli: r.pliCount });
    }
  });
  return out;
}

const trackInfo = t => t && { id: t.id, kind: t.kind, label: t.label, state: t.readyState, enabled: t.enabled, muted: t.muted, hint: t.contentHint || undefined, settings: (() => { try { return t.getSettings(); } catch (_) { return null; } })() };

export async function callSnapshot(S) {
  const links = {};
  await Promise.all([...S.links].map(async ([sid, link]) => { links[sid] = await linkStats(sid, link); }));
  const m = S.media;
  return {
    time: new Date().toISOString(), chatId: S.chatId, me: S.me, mySession: S.room && S.room.sid, joined: S.joined,
    summary: Object.fromEntries(Object.entries(links).map(([sid, l]) => [sid.slice(0, 6), [l.connection, l.path ? `${l.path.local && l.path.local.type}→${l.path.remote && l.path.remote.type} ${l.path.rttMs}ms` : "", ...(l.outbound || []).map(o => `↑${o.kind} ${o.kbps ?? "?"}kbps${o.fps != null ? " " + o.fps + "fps" : ""}${o.size ? " " + o.size : ""}${o.limited && o.limited !== "none" ? " (limited: " + o.limited + ")" : ""}`), ...(l.inbound || []).map(i => `↓${i.kind} ${i.kbps ?? "?"}kbps${i.fps != null ? " " + i.fps + "fps" : ""}${i.size ? " " + i.size : ""} lost ${i.packetsLost ?? 0}`)].filter(Boolean).join(" | ")])),
    local: m && { micOn: m.micOn, camOn: m.camOn, canScreen: m.canScreen, screenSharing: !!m.screen, deafened: !!S.deafened, mic: trackInfo(m.mic), cam: trackInfo(m.cam), screen: m.screen ? { video: trackInfo(m.screen.video), audio: trackInfo(m.screen.audio) } : null },
    sessions: S.sessions, links
  };
}

const dropPrev = new Map();        // "sid|ssrc" -> { t, dropped }
const tone = (v, good, bad) => (v == null ? "" : v <= good ? "ok" : v <= bad ? "warn" : "bad");
const kb = v => (v == null ? "?" : v >= 1000 ? (v / 1000).toFixed(2) + " Mbps" : Math.round(v) + " kbps");

/** Visual view: one card per person in the call (like a voice-connection panel), plus one for this device. */
export async function visualCall(S, snap) {
  const cards = [];
  const now = performance.now();
  // ---- me
  const m = snap.local || {};
  const outs = Object.values(snap.links).flatMap(l => l.outbound || []);
  const vOut = outs.filter(o => o.kind === "video"), aOut = outs.filter(o => o.kind === "audio");
  const prof = await getProfile(S.me).catch(() => null);
  const set = t => t && t.settings ? t.settings : {};
  const sz = st => (st.width ? `${st.width}×${st.height}` : "");
  cards.push(devCard("", [
    ["Microphone", m.mic ? devPill(m.micOn ? "on" : "muted", m.micOn ? "ok" : "warn") : devPill("none", "bad")],
    ["Mic device", m.mic && m.mic.label],
    ["Mic sample rate", set(m.mic).sampleRate ? set(m.mic).sampleRate + " Hz" : ""],
    ["Camera", m.cam ? `${sz(set(m.cam))} @ ${Math.round(set(m.cam).frameRate || 0)} fps` : devPill("off")],
    ["Screen share", m.screen && m.screen.video ? `${sz(set(m.screen.video))} @ ${Math.round(set(m.screen.video).frameRate || 0)} fps` : devPill("off")],
    ["Sending video", vOut.length ? `${Math.max(...vOut.map(o => o.fps || 0))} fps · ${kb(vOut.reduce((a, o) => a + (o.kbps || 0), 0))} total` : ""],
    ["Sending audio", aOut.length ? kb(aOut.reduce((a, o) => a + (o.kbps || 0), 0)) + " total" : ""],
    ["Deafened", m.deafened ? devPill("yes", "warn") : ""]
  ], { head: devWho((prof && prof.displayName) || "You", prof && prof.pfp, "You · this device · " + String(snap.mySession || "").slice(0, 6)) }));
  // ---- everyone else
  for (const [sid, l] of Object.entries(snap.links)) {
    const ses = (snap.sessions || {})[sid] || {};
    const p = ses.uid ? await getProfile(ses.uid).catch(() => null) : null;
    const rtt = l.path && l.path.rttMs;
    const vin = (l.inbound || []).filter(i => i.kind === "video"), ain = (l.inbound || []).filter(i => i.kind === "audio");
    const rows = [
      ["Connection", devPill(l.connection || l.note || "?", l.connection === "connected" ? "ok" : l.connection === "failed" ? "bad" : "warn")],
      ["Ping (RTT)", rtt != null ? [rtt + " ms", devBar(Math.min(rtt, 400), 400, tone(rtt, 80, 200))].reduce((a, b) => { const w = document.createElement("span"); w.append(a, " ", b); return w; }) : ""],
      ["Route", l.path ? `${l.path.local && l.path.local.type} → ${l.path.remote && l.path.remote.type} (${l.path.local && l.path.local.protocol})` : "", l.path && (l.path.local.type === "relay" || l.path.remote.type === "relay") ? "warn" : ""],
      ["Bandwidth (up / down)", l.path ? `${kb(l.path.availableOutKbps)} / ${kb(l.path.availableInKbps)}` : ""]
    ];
    for (const i of vin) {
      const key = sid + "|" + i.ssrc, pr = dropPrev.get(key); dropPrev.set(key, { t: now, dropped: i.framesDropped || 0 });
      const dps = pr && now > pr.t ? Math.round((((i.framesDropped || 0) - pr.dropped) * 1000) / (now - pr.t) * 10) / 10 : 0;
      rows.push(["Video in", `${i.fps ?? "?"} fps · ${i.size || "?"} · ${kb(i.kbps)}`, i.fps != null && i.fps < 10 ? "warn" : ""]);
      rows.push(["Dropped frames", `${i.framesDropped ?? 0}${dps ? ` (${dps}/s)` : ""} of ${i.framesDecoded ?? 0}`, dps > 1 ? "bad" : (i.framesDropped || 0) > 0 ? "warn" : ""]);
      rows.push(["Freezes", i.freezes, i.freezes > 0 ? "warn" : ""]);
      rows.push(["Decoder", [i.codec, i.decoder].filter(Boolean).join(" · ")]);
    }
    for (const i of ain) {
      const total = (i.packetsReceived || 0) + (i.packetsLost || 0), loss = total ? Math.round((i.packetsLost / total) * 1000) / 10 : 0;
      rows.push(["Audio in", `${kb(i.kbps)} · jitter ${i.jitterMs} ms`, tone(i.jitterMs, 20, 60)]);
      rows.push(["Packet loss", loss + "% (" + (i.packetsLost || 0) + ")", tone(loss, 1, 5)]);
    }
    for (const o of l.outbound || []) {
      if (o.kind === "video") rows.push(["Video out", `${o.fps ?? "?"} fps · ${o.size || "?"} · ${kb(o.kbps)}${o.content === "screenshare" ? " · screen" : ""}`]);
      if (o.kind === "video" && o.limited && o.limited !== "none") rows.push(["Limited by", devPill(o.limited, "warn")]);
      if (o.kind === "video" && o.targetKbps) rows.push(["Target", kb(o.targetKbps)]);
    }
    cards.push(devCard("", rows, { head: devWho((p && p.displayName) || "Someone", p && p.pfp, [ses.device, sid.slice(0, 6)].filter(Boolean).join(" · ")) }));
  }
  if (cards.length === 1) cards.push(devCard("Nobody else yet", [["Waiting", "Stats appear when someone joins"]]));
  return devGrid(cards);
}

let panel = null, timer = 0;
export function toggleDevPanel(S, plain) {
  if (panel) { clearInterval(timer); panel.remove(); panel = null; return; }
  panel = document.createElement("div"); panel.className = "dev-panel";
  panel.innerHTML = `<div class="dev-panel-head"><strong>Call stats</strong><span class="dev-tabs"><button type="button" class="dev-tab on" data-a="vis">Visual</button><button type="button" class="dev-tab" data-a="raw">Raw</button></span><span class="grow"></span><button type="button" class="dev-btn" data-a="copy">Copy</button><button type="button" class="dev-btn" data-a="pause">Pause</button><button type="button" class="dev-btn" data-a="x" aria-label="Close">✕</button></div><div class="dev-pane"></div>`;
  document.body.append(panel);
  const pane = panel.querySelector(".dev-pane"); let paused = false, last = "", mode = "vis", snap = null;
  const draw = async () => {
    if (!snap) return;
    if (mode === "vis") { try { pane.replaceChildren(await visualCall(S, snap)); } catch (e) { pane.textContent = String(e); } }
    else { const pre = pane.querySelector("pre") || pane.appendChild(Object.assign(document.createElement("pre"), { className: "dev-pre" })); pre.textContent = last; }
  };
  const tick = async () => { if (paused) return; try { snap = await callSnapshot(S); last = plain(snap); } catch (e) { last = String(e); } draw(); };
  panel.addEventListener("click", async e => {
    const a = e.target && e.target.dataset && e.target.dataset.a;
    if (a === "x") toggleDevPanel(S, plain);
    else if (a === "pause") { paused = !paused; e.target.textContent = paused ? "Resume" : "Pause"; }
    else if (a === "vis" || a === "raw") { mode = a; panel.querySelectorAll(".dev-tab").forEach(b => b.classList.toggle("on", b.dataset.a === a)); pane.replaceChildren(); draw(); }
    else if (a === "copy") { try { await navigator.clipboard.writeText(last); e.target.textContent = "Copied ✓"; setTimeout(() => { e.target.textContent = "Copy"; }, 1200); } catch (_) { /* ignore */ } }
  });
  tick(); timer = setInterval(tick, 1000);
}
