# QuickMessage Companion (Android)

A paired media device for the QuickMessage website. The site stays the brain; this app has **no login**: you enter a 6-digit code.

## Status
| Phase | What | State |
|---|---|---|
| 1 | Pairing (code, confirm on the website, persistent credential), device list, unpair | written |
| 2 | Persistent connection: heartbeat/presence, command stream, auto-reconnect, unpair detection | written |
| 3 | Remote controls: `ping`, `set-microphone/camera/screen`, `switch-camera` | written |
| 4-6 | Microphone / camera / screen over WebRTC to the website (the website feeds them into the call) | written, **untested on a real phone** |
| 7 | Background operation: foreground service, notification to connect, boot start | written, untested |
| 8 | Website integration: "My phone" button in the call dock, source pickers, phone screen as a second shared screen | written and tested against a simulated phone |

**The Android code has not been compiled or run** (the sandbox it was written in can't download the Android toolchain). The website
side was tested end to end against a simulated phone that speaks the same protocol with real WebRTC. Expect a compile error or two
on the first build, and some real-device fixes (camera/mic foreground-service rules differ between Android versions).

## Using it
1. Pair once (Account > Android companion). The app then keeps itself connected in the background and the website shows it online.
2. In a call, press **My phone** in the dock. Pick the phone (only online ones can be used). The phone shows a notification: tap **Connect**.
   The app opens so Android can ask for camera / microphone permission.
3. In the panel choose, separately, where the **microphone** and **camera** come from (this device / phone / off) and whether to
   **share the screen** from this device, the phone, or both at once. Screen sharing asks for Android's one-time screen-capture consent
   each time (Android requires that).
4. **Disconnect phone** (website), **Disconnect from the call** (app) or the notification's Disconnect button end the phone session.
   Hanging up on the website ends it too; the phone stops capturing and drops its notification.

## Build
No Android Studio needed: push the repo to GitHub, open **Actions > Build Android companion > Run workflow**, then download the
`quickmessage-companion-debug` artifact (`app-debug.apk`) and install it on the phone (allow "install unknown apps").
Or open the `android/` folder in Android Studio and press Run.

## One-time Firebase setup
1. **Authentication > Sign-in method > Anonymous > Enable.** The app's anonymous account is only a handle; it can do nothing until you confirm the pairing on the website.
2. Publish the updated `database.rules.json` (new `pairings`, `companionAuth`, `companions`, `companionLink` sections).
3. If your Realtime Database isn't in the default region, set `Config.DB_URL` in `Api.kt`.

## How it works (no Firebase SDK, no google-services.json)
The app talks to Firebase over REST + server-sent events with an anonymous account kept for the install via its refresh token.
- Website creates `pairings/{code}`; the app enters the code and writes a `claim` (its anonymous uid, a new `deviceId`, device name).
- You press **Confirm pairing** on the website (you see the device name). It writes `companionAuth/{appUid}`: that node *is* the app's credential. Deleting it (Unpair) cuts the app off at once.
- `companionLink/{you}/{deviceId}`: `state` is written by the app (online, lastSeen, capabilities, `session`, `media`); `commands` is written by the website and deleted by the app once handled.
- A call session: the website writes `session` {id, status:"requested"} and acts as the WebRTC *offerer* with three receive-only m-lines (0 mic, 1 camera, 2 screen). Signalling goes through `rtc/{id}/web` and `rtc/{id}/app`. The app answers all three as send-only and later plugs tracks in/out of those senders, so switching sources never renegotiates. The app reports what it is really doing in `state.media`; the website only believes that.

## Command protocol
```json
{ "type": "ping" }
{ "type": "set-microphone", "enabled": true }
{ "type": "set-camera", "enabled": true, "facing": "back" }
{ "type": "set-screen", "enabled": true }
{ "type": "switch-camera" }
```
The app replies through `state` (`lastPing`, `media`, `session`, `error`), so the website shows actual state, not assumed state.
