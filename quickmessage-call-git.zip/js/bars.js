// App: native insets and picture-in-picture state, polled in every frame (frames don't inherit the top window's CSS variables).
if (window.QMApp && window.QMApp.insets) {
  const sync = () => {
    try {
      const i = JSON.parse(window.QMApp.insets()), st = document.documentElement.style;
      st.setProperty("--sat", i.t + "px"); st.setProperty("--sab", i.b + "px"); st.setProperty("--sal", i.l + "px"); st.setProperty("--sar", i.r + "px");
      document.documentElement.classList.toggle("qm-pip", !!window.QMApp.inPip());
    } catch (_) { /* ignore */ }
  };
  sync(); setInterval(sync, 500); addEventListener("resize", sync);
}
// Keeps the browser's top bar (theme-color) and the Android app's status/navigation bars the same colour as the app's background.
// Runs only in the top window; the full-screen call layer counts as "the background" while it is up.
if (window.top === window) {
  let last = "";
  const hex = c => {
    const m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(c || "");
    return m ? "#" + [m[1], m[2], m[3]].map(n => (+n).toString(16).padStart(2, "0")).join("") : null;
  };
  const apply = () => {
    let color = null;
    try {
      const layer = document.getElementById("callLayer");
      const callUp = layer && !layer.hidden && !layer.classList.contains("min");
      const el = callUp ? layer : document.body;
      color = hex(getComputedStyle(el).backgroundColor);
      if (callUp && (!color || color === "#000000")) color = hex(getComputedStyle(document.body).backgroundColor);
      if (callUp) { const f = document.getElementById("callFrame"); const cb = f && f.contentDocument && hex(getComputedStyle(f.contentDocument.body).backgroundColor); if (cb) color = cb; }
    } catch (_) { /* cross-frame access can fail while loading */ }
    if (!color || color === last) return;
    last = color;
    let meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) { meta = document.createElement("meta"); meta.name = "theme-color"; document.head.append(meta); }
    meta.content = color;
    const n = parseInt(color.slice(1), 16), lum = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    try { window.QMApp && window.QMApp.setBars && window.QMApp.setBars(color, lum > 0.55); } catch (_) { /* not in the app */ }
  };
  document.addEventListener("DOMContentLoaded", apply);
  matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", apply);
  new MutationObserver(apply).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  setInterval(apply, 700);
  apply();
}
