// Developer mode: a floating panel with live call statistics (WebRTC getStats) and the raw call state. Opened by the small { } button in the call.
const prev = new Map();            // "linkId|ssrc|dir" -> { t, bytes, frames }
const round = (v, d = 1) => (typeof v === "number" && isFinite(v) ? Math.round(v * 10 ** d) / 10 ** d : v);

async function linkStats(sid, link) {
  const pc = link.pc;
  if (!pc) return { note: "no peer connection right now" };
  let rep; try { rep = await pc.getStats(); } catch (e) { return { error: String(e) }; }
  const by = {}; rep.forEach(r => { by[r.id] = r; });
  const now = performance.now();
  const rate = (key, bytes, frames) => {
    const p = prev.get(key); prev.set(key, { t: now, bytes, frames });
    if (!p || now <= p.t) return {};
    return { kbps: round(((bytes - p.bytes) * 8) / (now - p.t)), fpsMeasured: frames == null || p.frames == null ? undefined : round(((frames - p.frames) * 1000) / (now - p.t)) };
  };
  const out = { connection: pc.connectionState, ice: pc.iceConnectionState, gathering: pc.iceGatheringState, signaling: pc.signalingState, linkState: link.state, epoch: link.epoch, iceRestarts: link._iceRestarts, resets: link._resets, outbound: [], inbound: [] };
  let pair = null;
  rep.forEach(r => { if (r.type === "transport" && r.selectedCandidatePairId) pair = by[r.selectedCandidatePairId] || pair; });
  if (!pair) rep.forEach(r => { if (r.type === "candidate-pair" && (r.nominated || r.selected) && r.state === "succeeded") pair = r; });
  if (pair) {
    const cand = c => c && { type: c.candidateType, protocol: c.protocol, network: c.networkType, address: c.address || c.ip, port: c.port, relayProtocol: c.relayProtocol };
    out.path = { local: cand(by[pair.localCandidateId]), remote: cand(by[pair.remoteCandidateId]), rttMs: round((pair.currentRoundTripTime || 0) * 1000), availableOutKbps: round((pair.availableOutgoingBitrate || 0) / 1000), availableInKbps: round((pair.availableIncomingBitrate || 0) / 1000), bytesSent: pair.bytesSent, bytesReceived: pair.bytesReceived, requestsSent: pair.requestsSent, responsesReceived: pair.responsesReceived };
  }
  try { const c = pc.getConfiguration(); out.config = { iceTransportPolicy: c.iceTransportPolicy, bundlePolicy: c.bundlePolicy, iceServers: (c.iceServers || []).map(s => ({ urls: s.urls })) }; } catch (_) { /* ignore */ }
  rep.forEach(r => {
    const codec = r.codecId && by[r.codecId] ? by[r.codecId].mimeType : undefined;
    if (r.type === "outbound-rtp" && !r.isRemote) {
      out.outbound.push({ kind: r.kind, ssrc: r.ssrc, content: r.contentType, codec, ...rate(`${sid}|${r.ssrc}|o`, r.bytesSent || 0, r.framesEncoded), fps: r.framesPerSecond, size: r.frameWidth ? `${r.frameWidth}×${r.frameHeight}` : undefined, framesEncoded: r.framesEncoded, targetKbps: r.targetBitrate ? round(r.targetBitrate / 1000) : undefined, limited: r.qualityLimitationReason, limitDurations: r.qualityLimitationDurations, encoder: r.encoderImplementation, nack: r.nackCount, pli: r.pliCount, retransmittedBytes: r.retransmittedBytesSent, packetsSent: r.packetsSent });
    } else if (r.type === "inbound-rtp" && !r.isRemote) {
      out.inbound.push({ kind: r.kind, ssrc: r.ssrc, codec, ...rate(`${sid}|${r.ssrc}|i`, r.bytesReceived || 0, r.framesDecoded), fps: r.framesPerSecond, size: r.frameWidth ? `${r.frameWidth}×${r.frameHeight}` : undefined, framesDecoded: r.framesDecoded, framesDropped: r.framesDropped, packetsLost: r.packetsLost, packetsReceived: r.packetsReceived, jitterMs: round((r.jitter || 0) * 1000), jitterBufferMs: r.jitterBufferEmittedCount ? round((r.jitterBufferDelay / r.jitterBufferEmittedCount) * 1000) : undefined, freezes: r.freezeCount, decoder: r.decoderImplementation, audioLevel: r.audioLevel, concealedSamples: r.concealedSamples, nack: r.nackCount, pli: r.pliCount });
    }
  });
  return out;
}

const trackInfo = t => t && { id: t.id, kind: t.kind, label: t.label, state: t.readyState, enabled: t.enabled, muted: t.muted, hint: t.contentHint || undefined, settings: (() => { try { return t.getSettings(); } catch (_) { return null; } })() };

export async function callSnapshot(S) {
  const links = {};
  await Promise.all([...S.links].map(async ([sid, link]) => { links[sid] = await linkStats(sid, link); }));
  const m = S.media;
  return {
    time: new Date().toISOString(), chatId: S.chatId, me: S.me, mySession: S.room && S.room.sid, joined: S.joined,
    summary: Object.fromEntries(Object.entries(links).map(([sid, l]) => [sid.slice(0, 6), [l.connection, l.path ? `${l.path.local && l.path.local.type}→${l.path.remote && l.path.remote.type} ${l.path.rttMs}ms` : "", ...(l.outbound || []).map(o => `↑${o.kind} ${o.kbps ?? "?"}kbps${o.fps != null ? " " + o.fps + "fps" : ""}${o.size ? " " + o.size : ""}${o.limited && o.limited !== "none" ? " (limited: " + o.limited + ")" : ""}`), ...(l.inbound || []).map(i => `↓${i.kind} ${i.kbps ?? "?"}kbps${i.fps != null ? " " + i.fps + "fps" : ""}${i.size ? " " + i.size : ""} lost ${i.packetsLost ?? 0}`)].filter(Boolean).join(" | ")])),
    local: m && { micOn: m.micOn, camOn: m.camOn, canScreen: m.canScreen, screenSharing: !!m.screen, deafened: !!S.deafened, mic: trackInfo(m.mic), cam: trackInfo(m.cam), screen: m.screen ? { video: trackInfo(m.screen.video), audio: trackInfo(m.screen.audio) } : null },
    sessions: S.sessions, links
  };
}

let panel = null, timer = 0;
export function toggleDevPanel(S, plain) {
  if (panel) { clearInterval(timer); panel.remove(); panel = null; return; }
  panel = document.createElement("div"); panel.className = "dev-panel";
  panel.innerHTML = `<div class="dev-panel-head"><strong>Call stats</strong><span class="grow"></span><button type="button" class="dev-btn" data-a="copy">Copy</button><button type="button" class="dev-btn" data-a="pause">Pause</button><button type="button" class="dev-btn" data-a="x" aria-label="Close">✕</button></div><pre class="dev-pre"></pre>`;
  document.body.append(panel);
  const pre = panel.querySelector("pre"); let paused = false, last = "";
  const tick = async () => { if (paused) return; try { last = plain(await callSnapshot(S)); } catch (e) { last = String(e); } pre.textContent = last; };
  panel.addEventListener("click", async e => {
    const a = e.target && e.target.dataset && e.target.dataset.a;
    if (a === "x") toggleDevPanel(S, plain);
    else if (a === "pause") { paused = !paused; e.target.textContent = paused ? "Resume" : "Pause"; }
    else if (a === "copy") { try { await navigator.clipboard.writeText(last); e.target.textContent = "Copied ✓"; setTimeout(() => { e.target.textContent = "Copy"; }, 1200); } catch (_) { /* ignore */ } }
  });
  tick(); timer = setInterval(tick, 1000);
}
