package app.quickmessage.companion

import android.os.Build
import org.json.JSONObject
import java.security.SecureRandom

/** Result of a pairing attempt; [error] is a message for the user. */
class PairResult(val ok: Boolean, val error: String? = null)

object Pairing {
    /**
     * 1. read pairings/{code} (created by the website, proves the code is live)
     * 2. add a claim with this install's anonymous uid + a fresh deviceId
     * 3. wait for the website user to confirm: that creates companionAuth/{ourUid}, which is our credential
     */
    fun pair(fb: Firebase, store: Store, code: String, status: (String) -> Unit, cancelled: () -> Boolean): PairResult {
        try {
            status("Checking code…")
            val p = fb.get("pairings/$code") as? JSONObject ?: return PairResult(false, "That code isn't valid or has expired.")
            if (p.optLong("expiresAt") < System.currentTimeMillis() - 30_000) return PairResult(false, "That code has expired.")
            fb.token()
            val uid = store.authUid ?: return PairResult(false, "Couldn't sign in.")
            val deviceId = ByteArray(10).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
            val name = (Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL).take(50)
            fb.put("pairings/$code/claim", JSONObject().put("authUid", uid).put("deviceId", deviceId).put("name", name).toString())
            status("Waiting for you to confirm on the website…")
            val deadline = System.currentTimeMillis() + 5 * 60_000
            while (!cancelled() && System.currentTimeMillis() < deadline) {
                Thread.sleep(2000)
                val auth = fb.get("companionAuth/$uid") as? JSONObject
                if (auth != null) {
                    store.owner = auth.getString("owner"); store.deviceId = auth.getString("deviceId"); store.name = auth.optString("name", name)
                    return PairResult(true)
                }
                if (fb.get("pairings/$code") == null) return PairResult(false, "Pairing was rejected or cancelled.")
            }
            return PairResult(false, if (cancelled()) null else "Timed out waiting for confirmation.")
        } catch (e: ApiException) {
            return PairResult(false, if (e.code == 400 && e.message?.contains("ADMIN_ONLY_OPERATION") == true || e.message?.contains("OPERATION_NOT_ALLOWED") == true)
                "Anonymous sign-in is turned off for this Firebase project (enable it under Authentication > Sign-in method)." else "Server said ${e.code}: ${e.message}")
        } catch (e: Exception) {
            return PairResult(false, "Network problem: ${e.message}")
        }
    }
}
