package app.quickmessage.companion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Pair screen (enter the 6-digit code from the website) and a simple status screen. No login, no passwords. */
class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var pairing = false
    @Volatile private var cancelled = false
    private lateinit var root: LinearLayout
    private var statusView: TextView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this); fb = Firebase(store)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        setContentView(root)
        render()
        ui.post(object : Runnable { override fun run() { tick(); ui.postDelayed(this, 1000) } })
    }

    override fun onDestroy() { cancelled = true; super.onDestroy() }

    private var shownPaired: Boolean? = null
    private fun tick() {
        if (shownPaired != store.paired && !pairing) render()
        if (store.paired) statusView?.text = "Paired as \"${store.name}\"\n${store.status}"
    }

    private fun render() {
        shownPaired = store.paired
        root.removeAllViews()
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; gravity = Gravity.CENTER; setPadding(0, 16, 0, 16) }
        root.addView(text("QuickMessage Companion", 24f))
        if (store.paired) {
            statusView = text("")
            root.addView(statusView)
            val svc = Intent(this, CompanionService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
            root.addView(Button(this).apply {
                text = "Forget this pairing on the phone"
                setOnClickListener {
                    stopService(Intent(this@MainActivity, CompanionService::class.java))
                    store.forget(); render()
                }
            })
            root.addView(text("To remove the device completely, use Unpair on the website's Account page.", 13f))
        } else {
            root.addView(text("On the website open Account → Android companion → Pair an Android device, then enter the 6-digit code here."))
            val code = EditText(this).apply { hint = "123456"; inputType = InputType.TYPE_CLASS_NUMBER; gravity = Gravity.CENTER; textSize = 28f; maxLines = 1
                filters = arrayOf(android.text.InputFilter.LengthFilter(6)) }
            val msg = text("")
            val go = Button(this).apply { text = "Pair" }
            go.setOnClickListener {
                val c = code.text.toString().trim()
                if (c.length != 6) { msg.text = "Enter all 6 digits."; return@setOnClickListener }
                pairing = true; cancelled = false; go.isEnabled = false
                Thread {
                    val r = Pairing.pair(fb, store, c, { s -> ui.post { msg.text = s } }, { cancelled })
                    ui.post {
                        pairing = false
                        if (r.ok) render() else { go.isEnabled = true; msg.text = r.error ?: "" }
                    }
                }.start()
            }
            root.addView(code); root.addView(go); root.addView(msg)
        }
    }
}
