// App shell (index.html): chat list on the left; the open chat/account page in an <iframe> on the right (desktop) or
// full-screen over the list (mobile); and ONE persistent call <iframe> that survives switching chats, with a
// Discord-style "in call" bar while the call is minimised. Embedded pages reach this through `parent.QM` (see embed.js).
import { watchIncomingCalls } from "./incoming.js";
import { fmtDuration } from "./call-banner.js";
import { icon, avatarEl, localToast } from "./ui.js";

window.__qmToast = localToast;       // embedded pages route their toasts here (see ui.js toast)
import { getProfile } from "./users.js";

const $ = id => document.getElementById(id);
const split = matchMedia("(min-width: 900px)");
let uid = null, stopRings = null, timer = null;
const st = { chatId: null, pane: null, call: { chatId: null, joined: false, visible: false, muted: false, canMic: true, startLocal: null, title: "" } };

const els = () => ({
  detail: $("detailFrame"), layer: $("callLayer"), callFrame: $("callFrame"), bar: $("callBar")
});

// Changing iframe.src adds an entry to the *page's* history, so the browser's Back button would navigate the iframe
// (leaving a blank white pane). location.replace() swaps the content without touching history.
function navFrame(frame, url, retry = false) {
  try { frame.contentWindow.location.replace(url); } catch (_) { frame.src = url; }
  armWatch(frame, url, retry);
}

// ---- frame watchdog: a page that fails to load (network blip, host error page, crashed module) used to leave a white pane.
// Every embedded page calls QM.frameReady() once it has booted. If that doesn't happen in time we reload the frame (with a
// cache-busting param), and after a few tries show an explicit error with a Retry button instead of a blank pane.
const READY_MS = 15000, MAX_TRIES = 3;
const watch = new Map();                  // frame -> { url, tries, timer }
function clearWatch(frame) { const w = watch.get(frame); if (w) { clearTimeout(w.timer); watch.delete(frame); } showFrameError(frame, false); }
function armWatch(frame, url, retry) {
  const prev = watch.get(frame);
  if (prev) clearTimeout(prev.timer);
  if (!url || url === "about:blank") { watch.delete(frame); showFrameError(frame, false); return; }
  const base = url.replace(/([?&])_r=\d+/, "").replace(/[?&]$/, "");
  const tries = retry && prev && prev.base === base ? prev.tries : 0;
  const w = { url, base, tries, timer: setTimeout(() => stalled(frame), READY_MS) };
  watch.set(frame, w);
}
function stalled(frame) {
  const w = watch.get(frame);
  if (!w) return;
  if (w.tries >= MAX_TRIES) { showFrameError(frame, true); return; }
  w.tries++;
  const url = w.base + (w.base.includes("?") ? "&" : "?") + "_r=" + Date.now();
  const keep = w.tries;
  navFrame(frame, url, true);
  const nw = watch.get(frame); if (nw) nw.tries = keep;
}
function frameReady(frame) { if (frame && watch.has(frame)) clearWatch(frame); }
function showFrameError(frame, on) {
  const host = frame && frame.parentElement;
  if (!host) return;
  let box = host.querySelector(":scope > .frame-err[data-for='" + frame.id + "']");
  if (!on) { box?.remove(); return; }
  if (box) return;
  box = document.createElement("div");
  box.className = "frame-err"; box.dataset.for = frame.id;
  box.innerHTML = `<div><strong>This page didn't load.</strong><p>Check your connection and try again.</p><button type="button" class="btn primary">Try again</button></div>`;
  box.querySelector("button").onclick = () => { box.remove(); const w = watch.get(frame); const base = w ? w.base : frame.dataset.src || frame.src; if (w) w.tries = 0; navFrame(frame, base, false); };
  host.append(box);
}
// A frame that ended up showing the app shell itself (e.g. a stray link to index.html) is sent back to what it should show.
function frameEscaped(frame) {
  if (!frame) return;
  const want = frame.id === "callFrame" ? (st.call.chatId ? callUrl(st.call.chatId) : "about:blank") : (frame.dataset.src || "about:blank");
  navFrame(frame, want);
}
const nested = (() => { try { return window.parent !== window && !!window.parent.QM; } catch (_) { return false; } })();
if (nested) { try { window.stop(); const f = window.frameElement; setTimeout(() => window.parent.QM.frameEscaped(f), 0); } catch (_) { /* ignore */ } }

const callUrl = id => `call.html?chatId=${encodeURIComponent(id)}`;
function chatUrl(id) { return `message.html?chatId=${encodeURIComponent(id)}`; }

// ------------------------------------------------------------------ chat / account pane
function apply() {
  const { detail } = els();
  const q = new URLSearchParams(location.search);
  const chat = q.get("chat"), pane = q.get("pane");
  const want = pane === "account" ? "account.html" : chat && /^[\w-]{1,64}$/.test(chat) ? chatUrl(chat) : null;
  st.chatId = pane === "account" ? null : (want ? chat : null);
  st.pane = want ? (pane === "account" ? "account" : "chat") : null;
  const cur = detail.dataset.src || "";
  if (want && cur !== want) { detail.dataset.src = want; navFrame(detail, want); }
  if (!want && cur) { delete detail.dataset.src; navFrame(detail, "about:blank"); }
  document.body.classList.toggle("has-detail", !!want);
  document.querySelectorAll(".chat-item").forEach(a => a.classList.toggle("active", a.dataset.chat === st.chatId));
}

function go(params, { replace = false } = {}) {
  const qs = params ? "?" + new URLSearchParams(params).toString() : location.pathname;
  const target = params ? qs : location.pathname;
  if (target !== location.pathname + location.search) {
    (replace ? history.replaceState : history.pushState).call(history, { qm: 1 }, "", target);
  }
  apply();
}

function openChat(chatId) {
  if (!chatId) return;
  go({ chat: chatId }, { replace: st.pane !== null });
}
function openPane(name) { go({ pane: name }, { replace: st.pane !== null }); }
function closeDetail() {
  if (history.state && history.state.qm && st.pane && history.length > 1 && !split.matches) history.back();
  else go(null, { replace: true });
}

// The full-screen call owns one history entry, so the browser's Back button just minimises it and leaves you exactly where
// you were (chat, account page, …) instead of navigating anywhere.
let callEntry = false;
function pushCallEntry() {
  if (callEntry) return;
  callEntry = true;
  history.pushState({ qm: 1, call: 1 }, "", location.href);
}
function popCallEntry() {
  if (!callEntry) return Promise.resolve();
  callEntry = false;
  if (!(history.state && history.state.call)) return Promise.resolve();
  return new Promise(res => {
    const done = () => { clearTimeout(t); window.removeEventListener("popstate", done); res(); };
    const t = setTimeout(done, 400);
    window.addEventListener("popstate", done);
    history.back();
  });
}
window.addEventListener("popstate", () => {
  if (callEntry && !(history.state && history.state.call)) {   // Back pressed while the call is up
    callEntry = false;
    if (st.call.visible) hideCall();
  }
  apply();
});

// ------------------------------------------------------------------ call layer
function callWin() { try { return els().callFrame.contentWindow.__qmCall || null; } catch (_) { return null; } }

async function openCall(chatId) {
  if (!chatId) return;
  const { layer, callFrame } = els();
  if (st.call.joined && st.call.chatId !== chatId) {
    if (!confirm("You're already in a call. Leave it and join this one?")) return;
    await leaveCall(true);
  }
  if (callFrame.dataset.chat !== chatId) {
    callFrame.dataset.chat = chatId;
    st.call = { chatId, joined: false, visible: false, muted: false, canMic: true, startLocal: null, title: "" };
    navFrame(callFrame, callUrl(chatId));
  }
  layer.hidden = false;
  layer.classList.remove("min");
  st.call.visible = true;
  pushCallEntry();
  renderBar();
}

function closeCallFrame() {
  const { layer, callFrame } = els();
  popCallEntry();
  delete callFrame.dataset.chat;
  navFrame(callFrame, "about:blank");
  layer.hidden = true;
  layer.classList.remove("min");
  st.call = { chatId: null, joined: false, visible: false, muted: false, canMic: true, startLocal: null, title: "" };
  renderBar();
}

function hideCall() {
  const { layer } = els();
  if (!st.call.joined) { closeCallFrame(); return; }
  layer.classList.add("min");
  st.call.visible = false;
  renderBar();
}

/** Back arrow inside the call page: keep the call running and put the user back where they were. */
function minimizeCall() {
  hideCall();
  popCallEntry();
}

/** The call page has hung up (after it left the room): back to that chat. */
async function callEnded(chatId) {
  const popped = popCallEntry();      // must finish before we push the chat entry, or Back would pop the wrong one
  closeCallFrame();
  await popped;
  if (chatId) openChat(chatId);
}

async function leaveCall(silent = false) {
  const w = callWin();
  if (w) { try { await w.leave(); } catch (_) { /* ignore */ } }
  if (silent) closeCallFrame();
}

function setCallState(patch) {
  Object.assign(st.call, patch);
  renderBar();
}

// ------------------------------------------------------------------ "in call" bar
function renderBar() {
  const { bar } = els();
  const show = st.call.joined && !st.call.visible;
  bar.hidden = !show;
  document.documentElement.style.setProperty("--bar-h", show ? "44px" : "0px");
  clearInterval(timer);
  if (!show) return;
  bar.querySelector(".cbar-title").textContent = st.call.title || "In call";
  paintFaces(st.call.uids || []);
  const cam = bar.querySelector(".cbar-cam"), scr = bar.querySelector(".cbar-screen");
  cam.innerHTML = icon(st.call.camOn ? "camera" : "cameraOff", 18);
  cam.classList.toggle("off", !st.call.camOn);
  cam.disabled = !st.call.canCam;
  cam.title = st.call.camOn ? "Turn camera off" : "Turn camera on";
  scr.innerHTML = icon(st.call.screenOn ? "monitorOff" : "monitor", 18);
  scr.classList.toggle("on", !!st.call.screenOn);
  scr.disabled = !st.call.canScreen;
  scr.hidden = !st.call.canScreen;
  scr.title = st.call.screenOn ? "Stop sharing" : "Share your screen";
  const mic = bar.querySelector(".cbar-mic");
  mic.innerHTML = icon(st.call.muted ? "micOff" : "mic", 18);
  mic.classList.toggle("off", st.call.muted);
  mic.disabled = !st.call.canMic;
  mic.title = st.call.muted ? "Unmute" : "Mute";
  const tick = () => { bar.querySelector(".cbar-time").textContent = st.call.startLocal ? fmtDuration(Date.now() - st.call.startLocal) : ""; };
  tick();
  timer = setInterval(tick, 1000);
}

let facesKey = "";
async function paintFaces(uids) {
  const key = uids.join(",");
  if (key === facesKey) return;
  facesKey = key;
  const host = els().bar.querySelector(".cbar-faces");
  const profiles = await Promise.all(uids.filter(u => u !== uid).concat(uids.includes(uid) ? [uid] : []).slice(0, 4).map(getProfile));
  if (key !== facesKey) return;
  host.replaceChildren(...profiles.map(p => avatarEl(p.displayName, p.pfp, "avatar xs")));
}

function wire() {
  const { bar } = els();
  bar.innerHTML = `<span class="cbar-faces"></span><button type="button" class="cbar-main"><strong class="cbar-title"></strong><span class="cbar-time"></span></button>
    <button type="button" class="cbar-btn cbar-mic" aria-label="Mute"></button>
    <button type="button" class="cbar-btn cbar-cam" aria-label="Camera"></button>
    <button type="button" class="cbar-btn cbar-screen" aria-label="Share screen"></button>
    <button type="button" class="cbar-btn cbar-return">Return to call</button>
    <button type="button" class="cbar-btn cbar-leave" aria-label="Leave call"></button>`;
  bar.querySelector(".cbar-leave").innerHTML = icon("phoneOff", 18);
  const back = () => openCall(st.call.chatId);
  bar.querySelector(".cbar-main").onclick = back;
  bar.querySelector(".cbar-return").onclick = back;
  bar.querySelector(".cbar-mic").onclick = () => callWin()?.toggleMute();
  bar.querySelector(".cbar-cam").onclick = () => callWin()?.toggleCam();
  bar.querySelector(".cbar-screen").onclick = () => callWin()?.toggleScreen();
  bar.querySelector(".cbar-leave").onclick = () => leaveCall();

  const syncSplit = () => document.body.classList.toggle("split", split.matches);
  split.addEventListener("change", syncSplit);
  syncSplit();

  // Notification clicks while the app is already open: switch inside the shell instead of reloading it.
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.addEventListener("message", e => {
      if (!e.data || e.data.qm !== "open") return;
      try {
        const u = new URL(e.data.link, location.href);
        const id = u.searchParams.get("chatId") || u.searchParams.get("chat");
        if (!id) return;
        openChat(id);
        if (u.pathname.endsWith("call.html") || u.searchParams.has("session")) openCall(id);
      } catch (_) { /* ignore */ }
    });
  }
}

// ------------------------------------------------------------------ public API
export const QM = (window.QM = {
  openChat, openPane, closeDetail, openCall, minimizeCall, callEnded, setCallState, frameReady, frameEscaped,
  isSplit: () => split.matches,
  get state() { return st; }
});

// If the call page disappears while we think we're in a call (it navigated away, crashed, was unloaded), put it back; the
// call page joins by itself on load, so this is a seamless reconnect instead of a silent drop.
let misses = 0, recoveries = [];
setInterval(() => {
  if (!st.call.joined) { misses = 0; return; }
  const { callFrame } = els();
  let healthy = false;
  try { healthy = !!(callFrame.contentWindow.__qmCall && callFrame.contentWindow.location.pathname.endsWith("call.html")); } catch (_) { healthy = false; }
  if (healthy) { misses = 0; return; }
  if (++misses < 2) return;
  misses = 0;
  const now = Date.now();
  recoveries = recoveries.filter(t => now - t < 120000);
  if (recoveries.length >= 3) { showFrameError(callFrame, true); return; }   // stop looping; the user can press Try again
  recoveries.push(now);
  localToast("Call connection lost — reconnecting…", "info", 3500);
  st.call.joined = false;
  navFrame(callFrame, callUrl(st.call.chatId));
}, 3000);

let wired = false;
export function initShell(userId) {
  if (nested) return;
  uid = userId;
  if (!wired) { wired = true; wire(); }
  apply();
  const q = new URLSearchParams(location.search);
  // A call link / notification carries a one-shot timestamp. It must be fresh AND come from a real navigation, so
  // reloading, restoring a tab or pressing Back can never start (or restart) a call by itself.
  const token = Number(q.get("call"));
  if (q.has("call")) {
    q.delete("call");
    const next = location.pathname + (q.toString() ? "?" + q : "");
    history.replaceState({ qm: 1 }, "", next);
    let navType = "navigate";
    try { navType = performance.getEntriesByType("navigation")[0]?.type || "navigate"; } catch (_) { /* ignore */ }
    if (st.chatId && token > 1 && Date.now() - token < 20000 && navType === "navigate") openCall(st.chatId);
  }
  stopRings?.();
  stopRings = watchIncomingCalls({
    uid,
    onAnswer: chatId => { openChat(chatId); openCall(chatId); },
    inCall: chatId => st.call.joined && st.call.chatId === chatId
  });
}

export function resetShell() {
  uid = null;
  stopRings?.(); stopRings = null;
  if (wired) { closeCallFrame(); go(null, { replace: true }); }
}
