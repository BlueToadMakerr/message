// QuickMessage runs as one "shell" (index.html): chat list on the left, the open chat (message.html / account.html)
// in an <iframe> on the right, and the call (call.html) in a persistent <iframe> layer that survives switching chats.
// Pages loaded inside the shell use this helper to talk to it (same origin, so `parent.QM` is a plain object).
export const QM = (() => {
  try { return window.parent !== window && window.parent.QM ? window.parent.QM : null; } catch (_) { return null; }
})();
export const embedded = !!QM;

/** Leave the current page for the chat list. */
export function toHome() {
  if (QM) QM.closeDetail(); else if (window.parent !== window) toTop("index.html"); else location.replace("index.html");
}

/** Top-level navigation that works from inside the shell too. */
export function toTop(url) {
  try { (window.top || window).location.replace(url); } catch (_) { location.replace(url); }
}

/** Mark the document `split` while the shell shows list + chat side by side (hides redundant back buttons). */
export function trackSplit() {
  if (!QM) return;
  const apply = () => document.documentElement.classList.toggle("split", !!QM.isSplit());
  apply();
  window.parent.addEventListener("resize", apply);
}

/** Standalone (top-level) page → send the visitor into the shell instead. */
export function enterShell(query) {
  if (window.top === window && !new URLSearchParams(location.search).has("standalone")) {
    location.replace("index.html?" + query);
    return true;
  }
  return false;
}

/** Tell the shell this page has fully booted (its watchdog reloads frames that never do). Call at the end of the page's main module. */
export function markReady() {
  try { if (QM && window.frameElement) QM.frameReady(window.frameElement); } catch (_) { /* ignore */ }
}
