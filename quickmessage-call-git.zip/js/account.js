import { toHome, toTop, QM, trackSplit, markReady } from "./embed.js";
import { auth, db } from "./firebase.js";
import {
  onAuthStateChanged, signOut, EmailAuthProvider, GoogleAuthProvider,
  reauthenticateWithCredential, reauthenticateWithPopup, updatePassword, deleteUser, sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import { ref, get, update, remove } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import {
  toast, confirmDialog, promptDialog, avatarEl, hydrateIcons, copyText, authErrorMessage
} from "./ui.js";
import { ensureProfile, invalidateProfile } from "./users.js";
import { applyTheme, getTheme } from "./theme.js";
import { createPairing, confirmPairing, rejectPairing, unpair, watchCompanions, sendCommand } from "./companion.js";

hydrateIcons();
const $ = id => document.getElementById(id);

let user = null;

function renderHeader(name, pfp) {
  $("headAvatar").replaceChildren(avatarEl(name, pfp, "avatar-lg"));
  $("headName").textContent = name;
}

// Live theme preview while choosing (saved to the profile on "Save changes").
$("themeSelect").addEventListener("change", e => applyTheme(e.target.value));

// Live avatar preview
$("pfpUrl").addEventListener("input", () => {
  renderHeader($("displayName").value.trim() || user?.email || "?", $("pfpUrl").value.trim());
});

onAuthStateChanged(auth, async u => {
  if (!u) { toHome(); return; }
  user = u;

  let profile;
  try { profile = await ensureProfile(u); }
  catch (err) { console.error(err); toast("Couldn't load your profile.", "error"); profile = { displayName: u.displayName || "", pfp: "", theme: null }; }

  $("headEmail").textContent = u.email || "";
  $("uidText").textContent = u.uid;
  $("displayName").value = profile.displayName === "Unknown user" ? "" : profile.displayName;
  $("pfpUrl").value = profile.pfp || "";
  // Bug fix: the old page read an undefined `info.theme` here and crashed.
  const theme = profile.theme || getTheme();
  $("themeSelect").value = applyTheme(theme);
  renderHeader($("displayName").value || u.email || "?", profile.pfp);

  $("passwordSection").classList.toggle("hidden", !u.providerData.some(p => p.providerId === "password"));
  $("loading").classList.add("hidden");
  $("content").classList.remove("hidden");
  startCompanions();
});

// ---------- Android companion ----------
let stopWatch = null, pairing = null, pairTimer = null, claimed = null;
function startCompanions() {
  stopWatch?.();
  stopWatch = watchCompanions(user.uid, renderCompanions);
}
function renderCompanions(list) {
  const host = $("companionList");
  host.replaceChildren(...list.map(d => {
    const row = document.createElement("div");
    row.className = "participant-row";
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = d.name || "Android device";
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = d.online ? "Online" : "Offline";
    if (d.online) tag.style.color = "#16a34a";
    name.append(tag);
    const ping = document.createElement("button");
    ping.type = "button"; ping.className = "btn"; ping.textContent = "Ping"; ping.disabled = !d.online;
    ping.onclick = async () => {
      const t0 = Date.now();
      try { await sendCommand(user.uid, d.deviceId, { type: "ping" }); toast("Ping sent.", "info", 1500); } catch { toast("Couldn't reach it.", "error"); return; }
      void t0;
    };
    const un = document.createElement("button");
    un.type = "button"; un.className = "btn danger"; un.textContent = "Unpair";
    un.onclick = async () => {
      if (!await confirmDialog({ title: "Unpair device?", message: `${d.name || "This device"} will stop working until you pair it again.`, okText: "Unpair", danger: true })) return;
      try { await unpair(user.uid, d.deviceId, d.authUid); toast("Device unpaired.", "success"); } catch { toast("Couldn't unpair.", "error"); }
    };
    row.append(name, ping, un);
    return row;
  }));
}
function endPairing() {
  clearInterval(pairTimer); pairTimer = null;
  pairing?.stop(); pairing = null; claimed = null;
  $("pairBox").classList.add("hidden"); $("pairClaim").classList.add("hidden"); $("pairBtn").classList.remove("hidden");
}
$("pairBtn").onclick = async () => {
  try {
    pairing = await createPairing(user.uid, claim => {
      claimed = claim;
      $("pairClaim").classList.toggle("hidden", !claim);
      if (claim) $("pairClaimName").textContent = `"${String(claim.name || "Android device").slice(0, 40)}" wants to pair. Is that your device?`;
    });
  } catch (err) { toast(err.message || "Couldn't start pairing.", "error"); return; }
  $("pairCode").textContent = pairing.code.replace(/(\d{3})(\d{3})/, "$1 $2");
  $("pairBox").classList.remove("hidden"); $("pairBtn").classList.add("hidden");
  const tick = () => {
    const left = Math.max(0, pairing.expiresAt - Date.now());
    $("pairHint").textContent = left ? `Enter this code in the Android app. Expires in ${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, "0")}.` : "Code expired.";
    if (!left) endPairing();
  };
  tick(); pairTimer = setInterval(tick, 1000);
};
$("pairCancel").onclick = endPairing;
$("pairConfirm").onclick = async () => {
  if (!pairing || !claimed) return;
  const code = pairing.code, c = claimed;
  try { await confirmPairing(user.uid, code, c); toast("Android device paired.", "success"); pairing.stop = () => {}; endPairing(); }
  catch (err) { console.error(err); toast("Couldn't pair that device.", "error"); }
};
$("pairReject").onclick = async () => { if (pairing) { await rejectPairing(pairing.code).catch(() => {}); } endPairing(); };

$("copyUidBtn").onclick = () => copyText(user.uid);

// ---------- save profile ----------
$("profileForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!user) return;
  const displayName = $("displayName").value.trim();
  const pfp = $("pfpUrl").value.trim();
  if (!displayName) return toast("Display name can't be empty.", "error");
  if (pfp && !/^https?:\/\//i.test(pfp)) return toast("Profile picture must be an http(s) link.", "error");

  const btn = $("saveSettingsBtn");
  btn.disabled = true;
  try {
    await update(ref(db, `accsettings/${user.uid}/settings`), { displayName, pfp, theme: $("themeSelect").value });
    invalidateProfile(user.uid);
    applyTheme($("themeSelect").value);
    renderHeader(displayName, pfp);
    toast("Profile saved.", "success");
  } catch (err) {
    console.error(err);
    toast("Couldn't save: " + (err.message || err), "error");
  } finally { btn.disabled = false; }
});

// ---------- password ----------
$("passwordForm").addEventListener("submit", async e => {
  e.preventDefault();
  const oldPass = $("oldPassword").value, newPass = $("newPassword").value;
  if (!oldPass || newPass.length < 6) return toast("Enter your current password and a new one (6+ characters).", "error");
  const btn = $("changePassBtn");
  btn.disabled = true;
  try {
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, oldPass));
    await updatePassword(user, newPass);
    $("oldPassword").value = $("newPassword").value = "";
    toast("Password updated.", "success");
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  } finally { btn.disabled = false; }
});

$("resetBtn").onclick = async () => {
  try {
    await sendPasswordResetEmail(auth, user.email);
    toast("Reset email sent to " + user.email, "success");
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  }
};

// ---------- logout ----------
$("logoutBtn").onclick = async () => {
  await signOut(auth);
  toTop("index.html");
};

// ---------- delete account ----------
async function reauthenticate() {
  const hasPassword = user.providerData.some(p => p.providerId === "password");
  if (hasPassword) {
    const pass = await promptDialog({
      title: "Confirm it's you", message: "Enter your password to continue.",
      input: { type: "password", placeholder: "Password" }, okText: "Continue"
    });
    if (!pass) return false;
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, pass));
    return true;
  }
  await reauthenticateWithPopup(user, new GoogleAuthProvider());
  return true;
}

$("deleteBtn").onclick = async () => {
  const ok = await confirmDialog({
    title: "Delete your account?",
    message: "This permanently deletes your account and profile and removes you from all chats. This can't be undone.",
    okText: "Delete account", danger: true
  });
  if (!ok) return;

  try {
    // Re-authenticate first so the final deleteUser can't fail halfway through the cleanup.
    if (!(await reauthenticate())) return;

    const uid = user.uid;
    const chatIds = Object.keys((await get(ref(db, `chatList/${uid}`)).catch(() => null))?.val() || {});
    for (const chatId of chatIds) {
      try {
        const parts = (await get(ref(db, `privateChats/${chatId}/participants`))).val() || {};
        if (Object.keys(parts).filter(p => p !== uid).length === 0) {
          await remove(ref(db, `privateChats/${chatId}`));
        } else {
          await update(ref(db), {
            [`privateChats/${chatId}/participants/${uid}`]: null,
            [`privateChats/${chatId}/messageRead/${uid}`]: null,
            [`privateChats/${chatId}/typing/${uid}`]: null
          });
        }
      } catch (err) { console.warn("Couldn't clean up chat", chatId, err); }
    }
    await Promise.allSettled([
      remove(ref(db, `chatList/${uid}`)),
      remove(ref(db, `FCM/${uid}`)),
      remove(ref(db, `accsettings/${uid}`))
    ]);
    await deleteUser(user);
    toast("Account deleted.");
    setTimeout(() => toHome(), 800);
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  }
};

trackSplit();
if (QM) document.querySelector('a[aria-label="Back to chats"]')?.addEventListener("click", e => { e.preventDefault(); QM.closeDetail(); });

markReady();   // tells the app shell this frame booted (see frame watchdog in shell.js)
