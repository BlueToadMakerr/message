# QuickMessage Companion (Android)

A paired media device for the QuickMessage website. The site stays the brain; this app has **no login**: you enter a 6-digit code.

## Status
| Phase | What | State |
|---|---|---|
| 1 | Pairing (code, confirm on the website, persistent credential), device list, unpair | written |
| 2 | Persistent connection: heartbeat/presence, command stream, auto-reconnect, unpair detection | written |
| 3 | Remote controls: `ping`, `set-microphone/camera/screen` (acknowledged only, no capture yet) | written |
| 4-8 | Mic / camera / screen via WebRTC, background service types, mesh integration | not started |

**This code has not been compiled or run yet** (the sandbox it was written in can't download the Android toolchain). Expect to fix a typo or two on the first build.

## Build
No Android Studio needed: push the repo to GitHub, open **Actions > Build Android companion > Run workflow**, then download the
`quickmessage-companion-debug` artifact (`app-debug.apk`) and install it on the phone (allow "install unknown apps").
Or open the `android/` folder in Android Studio and press Run.

## One-time Firebase setup
1. **Authentication > Sign-in method > Anonymous > Enable.** The app's anonymous account is only a handle; it can do nothing until you confirm the pairing on the website.
2. Publish the updated `database.rules.json` (new `pairings`, `companionAuth`, `companions`, `companionLink` sections).
3. If your Realtime Database isn't in the default region, set `Config.DB_URL` in `Api.kt`.

## How it works (no Firebase SDK, no google-services.json)
The app talks to Firebase over REST + server-sent events with an anonymous account kept for the install via its refresh token.
- Website creates `pairings/{code}`; the app enters the code and writes a `claim` (its anonymous uid, a new `deviceId`, device name).
- You press **Confirm pairing** on the website (you see the device name). It writes `companionAuth/{appUid}`: that node *is* the app's credential. Deleting it (Unpair) cuts the app off at once.
- `companionLink/{you}/{deviceId}`: `state` is written by the app (online, lastSeen, capabilities, media); `commands` is written by the website and deleted by the app once handled.

## Command protocol
```json
{ "type": "ping" }
{ "type": "set-microphone", "enabled": true }
```
(`set-camera` and `set-screen` work the same way.) The app replies through `state` (`lastPing`, `media`), so the website shows actual state, not assumed state.
