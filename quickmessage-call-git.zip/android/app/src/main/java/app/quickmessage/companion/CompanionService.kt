package app.quickmessage.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.Manifest
import android.os.Build
import android.os.IBinder
import org.json.JSONObject

/**
 * Keeps the paired phone connected (presence heartbeat + command stream) and runs "use my phone in the call" sessions.
 *
 * A session is requested by the website (companionLink/{you}/{device}/session). We show a notification; tapping Connect opens
 * the app so Android lets us use the camera / microphone, then we answer the website's WebRTC offer and send whatever the
 * website asks for. The website removing the session, or the user pressing Disconnect here, ends it on both sides.
 */
class CompanionService : Service() {
    companion object {
        const val APP_VERSION = "0.2.0"
        const val ACTION_ACCEPT = "app.quickmessage.companion.ACCEPT"      // extras: sid, cam, mic (permission results)
        const val ACTION_DECLINE = "app.quickmessage.companion.DECLINE"
        const val ACTION_DISCONNECT = "app.quickmessage.companion.DISCONNECT"
        const val ACTION_PROJECTION = "app.quickmessage.companion.PROJECTION"  // extra: data (MediaProjection consent)
        private const val CH_LINK = "link"
        private const val CH_ASK = "ask"
        private const val ID_FG = 1
        private const val ID_ASK = 2
        private const val REQUEST_TTL_MS = 120_000L
    }

    @Volatile private var running = false
    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val sv = JSONObject().put(".sv", "timestamp")
    private val lock = Any()

    // current session
    private var sid: String? = null
    private var rtc: PhoneRtc? = null
    private var rtcThread: Thread? = null
    @Volatile private var live = false
    private var canCam = false
    private var canMic = false
    private var lastError: String? = null
    private val done = HashSet<String>()            // session ids already answered/ended: never ring for them again

    override fun onBind(i: Intent?): IBinder? = null

    private val base get() = "companionLink/${store.owner}/${store.deviceId}"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        store = Store(this); fb = Firebase(store)
        startFg(false, false, false)
        if (!running && store.paired) {
            running = true
            Thread({ commandLoop() }, "companion-commands").start()
            Thread({ sessionLoop() }, "companion-session").start()
            Thread({ heartbeat() }, "companion-heartbeat").start()
        }
        when (intent?.action) {
            ACTION_ACCEPT -> Thread { accept(intent.getStringExtra("sid"), intent.getBooleanExtra("cam", false), intent.getBooleanExtra("mic", false)) }.start()
            ACTION_DECLINE -> Thread { decline(intent.getStringExtra("sid")) }.start()
            ACTION_DISCONNECT -> Thread { endSession(true) }.start()
            ACTION_PROJECTION -> {
                @Suppress("DEPRECATION") val data = intent.getParcelableExtra<Intent>("data")
                Thread { onProjection(data) }.start()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; endSession(true); super.onDestroy() }

    // ------------------------------------------------------------------ foreground notification
    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    @Suppress("DEPRECATION")
    private fun builder(channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)

    private fun channels() {
        if (Build.VERSION.SDK_INT < 26) return
        nm().createNotificationChannel(NotificationChannel(CH_LINK, "Connection", NotificationManager.IMPORTANCE_LOW))
        nm().createNotificationChannel(NotificationChannel(CH_ASK, "Connection requests", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun activityIntent(action: String?, sid: String? = null, req: Int = 0): PendingIntent {
        val i = Intent(this, MainActivity::class.java).setAction(action).putExtra("sid", sid).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun serviceIntent(action: String, sid: String? = null, req: Int = 0): PendingIntent {
        val i = Intent(this, CompanionService::class.java).setAction(action).putExtra("sid", sid)
        val f = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, req, i, f) else PendingIntent.getService(this, req, i, f)
    }

    /** (Re)declare the foreground service with exactly the types we are allowed to use right now. */
    private fun startFg(camera: Boolean, mic: Boolean, projection: Boolean) {
        channels()
        val inCall = sid != null && live
        val b = builder(CH_LINK).setContentTitle("QuickMessage Companion")
            .setContentText(if (inCall) "Connected to your call" else "Ready — connected to your QuickMessage account")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setOngoing(true)
            .setContentIntent(activityIntent(null))
        if (sid != null) b.addAction(Notification.Action.Builder(null, "Disconnect", serviceIntent(ACTION_DISCONNECT, sid, 3)).build())
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (camera) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (mic) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (projection) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            try { startForeground(ID_FG, n, t) } catch (e: Exception) { startForeground(ID_FG, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        } else startForeground(ID_FG, n)
    }

    private fun status(s: String) { store.status = s }

    // ------------------------------------------------------------------ presence + unpair detection
    private fun unpaired() {
        status("Unpaired from the website")
        store.forget(); running = false
        endSession(false)
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun stillPaired(): Boolean = try { fb.get("companionAuth/${store.authUid}") != null } catch (e: ApiException) { e.code != 401 && e.code != 403 } catch (e: Exception) { true }

    private fun mediaJson(): JSONObject {
        val r = rtc
        return JSONObject().put("microphone", r?.micOn ?: false).put("camera", r?.camOn ?: false).put("screen", r?.screenOn ?: false).put("facing", r?.facing ?: "front")
    }

    private fun heartbeat() {
        var first = true
        while (running) {
            try {
                val state = JSONObject().put("online", true).put("lastSeen", sv).put("name", store.name).put("appVersion", APP_VERSION)
                if (first) state.put("capabilities", JSONObject().put("microphone", true).put("camera", true).put("screen", true)
                    .put("backgroundCamera", true).put("backgroundMicrophone", true).put("controlOnly", false))
                fb.patch("$base/state", state.toString()); first = false
            } catch (e: ApiException) {
                if ((e.code == 401 || e.code == 403) && !stillPaired()) { unpaired(); return }
            } catch (_: Exception) { /* offline: next beat */ }
            try { Thread.sleep(20_000) } catch (_: InterruptedException) { return }
        }
    }

    private fun publish(vararg kv: Pair<String, Any?>) {
        val j = JSONObject(); for ((k, v) in kv) j.put(k, v ?: JSONObject.NULL)
        try { fb.patch("$base/state", j.toString()) } catch (_: Exception) { /* next heartbeat/update will catch up */ }
    }
    private fun publishSession(status: String?) {
        val id = sid ?: return
        publish("session" to if (status == null) null else JSONObject().put("id", id).put("status", status))
    }
    private fun publishMedia() { publish("media" to mediaJson()) }
    private fun publishError(msg: String) {
        lastError = msg
        publish("error" to JSONObject().put("at", sv).put("msg", msg))
    }

    // ------------------------------------------------------------------ commands (ping / set-* / switch-camera)
    private fun commandLoop() {
        var backoff = 2000L
        while (running) {
            try {
                if (!stillPaired()) { unpaired(); return }
                status("Connected")
                fb.stream("$base/commands", { running }) { _, path, data ->
                    backoff = 2000L
                    when {
                        path == "/" && data is JSONObject -> data.keys().asSequence().sorted().forEach { k -> data.optJSONObject(k)?.let { handleCommand(k, it) } }
                        path != "/" && data is JSONObject -> handleCommand(path.trim('/'), data)
                    }
                }
                status("Reconnecting…")
            } catch (e: ApiException) {
                if ((e.code == 401 || e.code == 403) && !stillPaired()) { unpaired(); return }
                status("Reconnecting… (${e.code})")
            } catch (e: Exception) { status("Offline, retrying…") }
            try { Thread.sleep(backoff) } catch (_: InterruptedException) { return }
            backoff = (backoff * 2).coerceAtMost(30_000L)
        }
    }

    private fun handleCommand(id: String, cmd: JSONObject) {
        val age = System.currentTimeMillis() - cmd.optLong("t", 0)
        try { fb.delete("$base/commands/$id") } catch (_: Exception) {}
        if (age > 120_000) return                       // from before we were online
        when (cmd.optString("type")) {
            "ping" -> publish("lastPing" to JSONObject().put("id", id).put("at", sv))
            "set-microphone" -> setWant { it.wantMic = cmd.optBoolean("enabled") }
            "set-camera" -> setWant { it.wantCam = cmd.optBoolean("enabled"); if (cmd.has("facing")) it.wantCamFacing = cmd.optString("facing") }
            "switch-camera" -> setWant { it.wantCamFacing = if (it.facing == "front") "back" else "front"; it.wantCam = true }
            "set-screen" -> {
                val on = cmd.optBoolean("enabled")
                setWant { it.wantScreen = on }
                if (on && rtc?.projection == null && rtc?.screenOn != true) askScreen()
            }
        }
        status("Last command: ${cmd.optString("type")}")
    }

    private fun setWant(f: (PhoneRtc) -> Unit) {
        val r = synchronized(lock) { rtc } ?: return
        if (!hasPerms(r)) return
        f(r); r.apply()
    }

    private fun hasPerms(r: PhoneRtc): Boolean {
        if ((r.wantCam && !canCam) ) { publishError("Camera permission was not granted on the phone."); r.wantCam = false }
        if ((r.wantMic && !canMic)) { publishError("Microphone permission was not granted on the phone."); r.wantMic = false }
        return true
    }

    // ------------------------------------------------------------------ sessions
    private fun sessionLoop() {
        var backoff = 2000L
        while (running) {
            try {
                onSessionValue(fb.get("$base/session") as? JSONObject)
                fb.stream("$base/session", { running }) { _, _, _ ->
                    backoff = 2000L
                    try { onSessionValue(fb.get("$base/session") as? JSONObject) } catch (_: Exception) {}
                }
            } catch (e: ApiException) {
                if ((e.code == 401 || e.code == 403) && !stillPaired()) { unpaired(); return }
            } catch (_: Exception) {}
            try { Thread.sleep(backoff) } catch (_: InterruptedException) { return }
            backoff = (backoff * 2).coerceAtMost(30_000L)
        }
    }

    /** The website's session request changed. null = it ended the session (or none exists). */
    private fun onSessionValue(s: JSONObject?) {
        if (s == null) { if (sid != null) endSession(false); return }
        val id = s.optString("id")
        if (id.isEmpty()) return
        if (id == sid || id in done) return                         // already ours, or already handled
        if (System.currentTimeMillis() - s.optLong("t", 0) > REQUEST_TTL_MS) return    // stale request
        if (sid != null) endSession(false)                          // a newer request replaces the old session
        sid = id
        publishSession("ringing")
        ask(id)
    }

    private fun ask(id: String) {
        channels()
        val n = builder(CH_ASK).setContentTitle("Use this phone in your call?")
            .setContentText("Your QuickMessage website is asking to use this phone's camera, microphone or screen.")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setAutoCancel(true)
            .setContentIntent(activityIntent(MainActivity.ACTION_ASK, id, 10))
            .addAction(Notification.Action.Builder(null, "Connect", activityIntent(MainActivity.ACTION_ASK, id, 11)).build())
            .addAction(Notification.Action.Builder(null, "Decline", serviceIntent(ACTION_DECLINE, id, 12)).build())
            .build()
        nm().notify(ID_ASK, n)
        status("Waiting for you to tap Connect")
        // The activity opens straight away when the app is already in the foreground.
        try { startActivity(Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_ASK).putExtra("sid", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun decline(id: String?) {
        if (id == null || id != sid) return
        nm().cancel(ID_ASK)
        publishSession("declined")
        done.add(id)
        sid = null
        status("Declined")
    }

    /** The user tapped Connect and the activity has asked for permissions: start the media session. */
    private fun accept(id: String?, cam: Boolean, mic: Boolean) {
        if (id == null || id != sid) return
        nm().cancel(ID_ASK)
        canCam = cam; canMic = mic
        startFg(cam, mic, false)
        publishSession("accepted")
        val r = PhoneRtc(this, { m -> sendSignal(m) }, { msg -> failed(msg) }, { publishMedia(); updateNotification() })
        synchronized(lock) { rtc = r }
        live = true
        status("Connected to the website")
        // read the website's offer + candidates in order
        rtcThread = Thread({
            var backoff = 1000L
            while (running && sid == id && rtc === r) {
                try {
                    fb.stream("$base/rtc/$id/web", { running && sid == id && rtc === r }) { _, path, data ->
                        backoff = 1000L
                        when {
                            path == "/" && data is JSONObject -> data.keys().asSequence().sorted().forEach { k -> data.optJSONObject(k)?.let { r.onSignal(it) } }
                            path != "/" && data is JSONObject -> r.onSignal(data)
                        }
                    }
                } catch (_: Exception) {}
                try { Thread.sleep(backoff) } catch (_: InterruptedException) { return@Thread }
                backoff = (backoff * 2).coerceAtMost(10_000L)
            }
        }, "companion-rtc").also { it.start() }
        publishSession("live")
        publishMedia()
    }

    private fun sendSignal(m: JSONObject) {
        val id = sid ?: return
        try { fb.post("$base/rtc/$id/app", m.toString()) } catch (_: Exception) {}
    }

    private fun failed(msg: String) {
        publishError(msg)
        endSession(true)
    }

    private fun updateNotification() { if (running) startFgSafe() }
    private fun startFgSafe() {
        val r = rtc
        try { startFg(canCam && (r?.camOn == true || r?.wantCam == true), canMic && (r?.micOn == true || r?.wantMic == true), r?.screenOn == true) } catch (_: Exception) {}
    }

    /** Screen capture needs a fresh system consent each time: ask the user through the app. */
    private fun askScreen() {
        channels()
        val n = builder(CH_ASK).setContentTitle("Allow screen sharing?")
            .setContentText("Tap to share this phone's screen in your call.").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setAutoCancel(true)
            .setContentIntent(activityIntent(MainActivity.ACTION_SCREEN, sid, 20)).build()
        nm().notify(ID_ASK, n)
        try { startActivity(Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_SCREEN).putExtra("sid", sid).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun onProjection(data: Intent?) {
        val r = synchronized(lock) { rtc } ?: return
        nm().cancel(ID_ASK)
        if (data == null) { r.wantScreen = false; publishError("Screen sharing was not allowed on the phone."); publishMedia(); return }
        r.projection = data
        startFg(canCam, canMic, true)                  // the mediaProjection type must be active before capture starts
        r.apply()
    }

    /** End the session on this side. [tell] = also tell the website (it removes the session and closes its end). */
    private fun endSession(tell: Boolean) {
        var id: String? = null
        var r: PhoneRtc? = null
        synchronized(lock) { id = sid; r = rtc; rtc = null; sid = null }
        id?.let { done.add(it) }
        live = false
        nm().cancel(ID_ASK)
        r?.close()
        rtcThread?.interrupt(); rtcThread = null
        if (id != null && tell) {
            try { fb.patch("$base/state", JSONObject().put("session", JSONObject().put("id", id).put("status", "ended")).put("media", mediaJson()).toString()) } catch (_: Exception) {}
        }
        if (id != null) status("Disconnected")
        if (running && id != null) try { startFg(false, false, false) } catch (_: Exception) {}
    }
}
