// Android app only: hands the signed-in account to the app (so it can show message / incoming-call notifications natively,
// even when the page isn't open) and forgets it on sign-out. Does nothing in a normal browser.
import { auth } from "./firebase.js";
import { onIdTokenChanged } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
if (window.top === window && window.QMApp && window.QMApp.setSession) {
  onIdTokenChanged(auth, user => {
    try { user ? window.QMApp.setSession(user.uid, user.refreshToken) : window.QMApp.logout(); } catch (_) { /* ignore */ }
  });
}
