package app.quickmessage.companion

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack

private open class Sdp : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

/**
 * One WebRTC session with the website. The website is the *offerer* with three receive-only m-lines in a fixed order:
 *   0 = microphone (audio), 1 = camera (video), 2 = screen (video)
 * We answer all three as send-only (with no track yet) and later just plug tracks in and out of those senders, so
 * turning things on and off never needs renegotiation.
 */
class PhoneRtc(
    private val ctx: Context,
    private val sendSignal: (JSONObject) -> Unit,
    private val onFailed: (String) -> Unit,
    private val onMedia: () -> Unit
) {
    companion object {
        private var factory: PeerConnectionFactory? = null
        private var egl: EglBase? = null
        @Synchronized fun factory(ctx: Context): PeerConnectionFactory {
            factory?.let { return it }
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext).createInitializationOptions())
            val e = EglBase.create(); egl = e
            return PeerConnectionFactory.builder()
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(e.eglBaseContext, true, true))
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(e.eglBaseContext))
                .createPeerConnectionFactory().also { factory = it }
        }
    }

    // what is actually being sent right now (reported back to the website)
    @Volatile var micOn = false
        private set
    @Volatile var camOn = false
        private set
    @Volatile var screenOn = false
        private set
    @Volatile var facing = "front"
        private set

    private val f = factory(ctx)
    private var pc: PeerConnection? = null
    private var closed = false
    private val pendingCands = ArrayList<IceCandidate>()
    private var answered = false

    private var micSource: AudioSource? = null
    private var micTrack: AudioTrack? = null
    private var camCapturer: CameraVideoCapturer? = null
    private var camSource: VideoSource? = null
    private var camTrack: VideoTrack? = null
    private var camHelper: SurfaceTextureHelper? = null
    private var scrCapturer: VideoCapturer? = null
    private var scrSource: VideoSource? = null
    private var scrTrack: VideoTrack? = null
    private var scrHelper: SurfaceTextureHelper? = null

    // desired state; applied as soon as the answer is done
    var wantMic = false
    var wantCam = false
    var wantCamFacing = "front"
    var wantScreen = false
    var projection: Intent? = null

    private fun create() {
        val cfg = PeerConnection.RTCConfiguration(listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        ))
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        cfg.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
        pc = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED && !closed) onFailed("The connection to the website failed. Both devices need internet access.")
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate) {
                sendSignal(JSONObject().put("t", "cand").put("d", JSONObject()
                    .put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)))
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: org.webrtc.DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
        })
    }

    /** A signalling message from the website: {t:"desc", d:{type, sdp}} or {t:"cand", d:{candidate, sdpMid, sdpMLineIndex}}. */
    @Synchronized fun onSignal(m: JSONObject) {
        if (closed) return
        val d = m.optJSONObject("d") ?: return
        when (m.optString("t")) {
            "desc" -> if (d.optString("type") == "offer") answer(d.getString("sdp"))
            "cand" -> {
                val c = IceCandidate(d.optString("sdpMid"), d.optInt("sdpMLineIndex"), d.optString("candidate"))
                if (answered) pc?.addIceCandidate(c) else pendingCands.add(c)
            }
        }
    }

    private fun answer(sdp: String) {
        if (pc == null) create()
        val p = pc ?: return
        p.setRemoteDescription(object : Sdp() {
            override fun onSetSuccess() {
                // answer every m-line as send-only; real tracks are plugged in later
                p.transceivers.forEach { it.setDirection(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY) }
                p.createAnswer(object : Sdp() {
                    override fun onCreateSuccess(d: SessionDescription) {
                        p.setLocalDescription(object : Sdp() {
                            override fun onSetSuccess() {
                                sendSignal(JSONObject().put("t", "desc").put("d", JSONObject().put("type", "answer").put("sdp", d.description)))
                                synchronized(this@PhoneRtc) {
                                    answered = true
                                    pendingCands.forEach { p.addIceCandidate(it) }
                                    pendingCands.clear()
                                }
                                apply()
                            }
                            override fun onSetFailure(e: String?) { onFailed("Couldn't set up the connection ($e)") }
                        }, d)
                    }
                    override fun onCreateFailure(e: String?) { onFailed("Couldn't answer the website ($e)") }
                }, MediaConstraints())
            }
            override fun onSetFailure(e: String?) { onFailed("The website's offer was rejected ($e)") }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    // ------------------------------------------------------------------ reconcile desired -> actual
    @Synchronized fun apply() {
        if (closed || !answered) return
        val tx = pc?.transceivers ?: return
        if (tx.size < 3) return
        try {
            // microphone
            if (wantMic && micTrack == null) {
                micSource = f.createAudioSource(MediaConstraints())
                micTrack = f.createAudioTrack("mic", micSource)
                tx[0].sender.setTrack(micTrack, false)
            } else if (!wantMic && micTrack != null) {
                tx[0].sender.setTrack(null, false)
                micTrack?.dispose(); micSource?.dispose(); micTrack = null; micSource = null
            }
            micOn = micTrack != null

            // camera
            if (wantCam && camTrack != null && facing != wantCamFacing) camCapturer?.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFront: Boolean) { facing = if (isFront) "front" else "back"; onMedia() }
                override fun onCameraSwitchError(e: String?) {}
            })
            if (wantCam && camTrack == null) startCamera(tx[1])
            else if (!wantCam && camTrack != null) stopCamera(tx[1])
            camOn = camTrack != null

            // screen
            if (wantScreen && scrTrack == null && projection != null) startScreen(tx[2])
            else if (!wantScreen && scrTrack != null) stopScreen(tx[2])
            screenOn = scrTrack != null
        } catch (e: Exception) {
            onFailed("Media error: ${e.message}")
        }
        onMedia()
    }

    private fun startCamera(t: RtpTransceiver) {
        val en = Camera2Enumerator(ctx)
        val wantFront = wantCamFacing == "front"
        val name = en.deviceNames.firstOrNull { en.isFrontFacing(it) == wantFront } ?: en.deviceNames.firstOrNull() ?: throw IllegalStateException("No camera")
        val cap = en.createCapturer(name, null) ?: throw IllegalStateException("Couldn't open the camera")
        val helper = SurfaceTextureHelper.create("cam", egl!!.eglBaseContext)
        val src = f.createVideoSource(false)
        cap.initialize(helper, ctx, src.capturerObserver)
        cap.startCapture(1280, 720, 30)
        val track = f.createVideoTrack("cam", src)
        t.sender.setTrack(track, false)
        camCapturer = cap; camHelper = helper; camSource = src; camTrack = track
        facing = if (en.isFrontFacing(name)) "front" else "back"
    }

    private fun stopCamera(t: RtpTransceiver) {
        t.sender.setTrack(null, false)
        try { camCapturer?.stopCapture() } catch (_: InterruptedException) {}
        camCapturer?.dispose(); camTrack?.dispose(); camSource?.dispose(); camHelper?.dispose()
        camCapturer = null; camTrack = null; camSource = null; camHelper = null
    }

    private fun startScreen(t: RtpTransceiver) {
        val cap = ScreenCapturerAndroid(projection, object : MediaProjection.Callback() {
            override fun onStop() { wantScreen = false; projection = null; android.os.Handler(android.os.Looper.getMainLooper()).post { apply() } }
        })
        val helper = SurfaceTextureHelper.create("screen", egl!!.eglBaseContext)
        val src = f.createVideoSource(true)
        cap.initialize(helper, ctx, src.capturerObserver)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val scale = minOf(1.0, 1280.0 / maxOf(dm.widthPixels, dm.heightPixels))
        cap.startCapture((dm.widthPixels * scale).toInt() and 1.inv(), (dm.heightPixels * scale).toInt() and 1.inv(), 15)
        val track = f.createVideoTrack("screen", src)
        track.setEnabled(true)
        t.sender.setTrack(track, false)
        scrCapturer = cap; scrHelper = helper; scrSource = src; scrTrack = track
    }

    private fun stopScreen(t: RtpTransceiver) {
        t.sender.setTrack(null, false)
        try { scrCapturer?.stopCapture() } catch (_: InterruptedException) {}
        scrCapturer?.dispose(); scrTrack?.dispose(); scrSource?.dispose(); scrHelper?.dispose()
        scrCapturer = null; scrTrack = null; scrSource = null; scrHelper = null
        projection = null                                  // a projection token is single-use
    }

    /** Stop everything: capture off, connection closed. */
    @Synchronized fun close() {
        if (closed) return
        closed = true
        val tx = try { pc?.transceivers } catch (_: Exception) { null }
        try { if (tx != null && tx.size >= 3) { if (camTrack != null) stopCamera(tx[1]); if (scrTrack != null) stopScreen(tx[2]) } } catch (_: Exception) {}
        micTrack?.dispose(); micSource?.dispose(); micTrack = null; micSource = null
        micOn = false; camOn = false; screenOn = false
        try { pc?.close(); pc?.dispose() } catch (_: Exception) {}
        pc = null
    }
}
