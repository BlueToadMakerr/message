# QuickMessage

Lightweight private chat on Firebase Realtime Database. Static front-end (HTML + ES modules, no build step) plus one PHP endpoint (`notify.php`) for push notifications. Upload the whole folder to your host (it's laid out to live at `/message/`).

## What's new

- **Typing indicators** — "typing…" in the chat header, animated dots in the thread, and live "typing…" in the chat list.
- Redesigned UI: responsive chat bubbles, light / dark / match-device theme (`dark.css` is gone — one `style.css` handles all three), modal dialogs and toasts instead of `alert()`/`confirm()`/`prompt()`, avatars with initials fallback, unread dots, chats sorted by latest activity, jump-to-latest button, auto-growing composer (Enter sends on desktop), message copy / edit / delete menu.
- Real `manifest.json` + icons (the manifest used to be an inline data URI).
- Code split into small modules in `js/`.

## Bugs fixed

**Crashes / broken features**
- `account.html` crashed on load (`info.theme` was undefined → should have been `data.theme`) and referenced `darkThemeToggle` before it was defined.
- `message.html` had duplicate `#popup` / `#overlay` ids, so the "add user" confirmation popup never worked properly.
- New sign-ups and Google logins never got a profile record, which produced "User does not exist" errors and broken chat rows for everyone who chatted with them. A profile is now created automatically.
- Message authors showed as "Unknown" if they rendered before the participant list finished loading.
- Image/video messages never updated the chat-list preview or sent notifications.
- Videos up to 20 MB were allowed, but Realtime Database rejects writes that large once base64-encoded — limit is now 8 MB, and images are resized/compressed in the browser first.
- Editing a message changed its timestamp, so it jumped to a new position on reload. Edits now set `editedAt` instead.
- Deleting the newest message left the deleted text in the chat-list preview.
- The page attached `child_*` listeners to the whole `messages` node, which downloaded the entire history and defeated pagination. Listeners now cover only the loaded window.
- Every send downloaded the entire message history to compute the next numeric id (slow, and racy when two people send at once). Messages now use Firebase push ids.
- Read receipts used `Number(key)`, which breaks for push ids; receipts now store the key as-is (old numeric receipts still match). Receipts no longer show "Read by" yourself, and a single-message chat is now marked read.
- Starting a chat with someone you already chat with created a duplicate; it now opens the existing chat.
- `getToken()` ran on page load and could pop the notification permission prompt unprompted; it now only runs silently if permission was already granted.
- Deleting an account failed with `requires-recent-login` and didn't clean up data; it now re-authenticates, leaves your chats, and removes your records first.
- Service worker used `/icon.png` (404); the `notificationclick` link logic was fragile.

**Security**
- **XSS**: message text, chat names and display names were injected with `innerHTML` and a regex "sanitizer". Everything is now built with DOM nodes / `textContent`, links are only auto-linked for `http(s)`, and media URLs are allow-listed.
- **`notify.php` trusted a `?uid=` query value**, so anyone could pretend to be any participant. It now verifies the caller's Firebase ID token.
- **Hard-coded admin e-mail + password removed** — the service account is used for database access instead.
- The "already notified" flag is now an atomic conditional write (previously two quick requests could both send).
- Only truly dead FCM tokens are deleted (`INVALID_ARGUMENT` used to wipe tokens on any payload error).
- Pinch-zoom is no longer disabled (accessibility).

## ⚠️ Do this after deploying

1. **Rotate your credentials.** The old `notify.php` contained the service-account private key *and* the admin account's password in plain text, and both have now been pasted into chat tools. Treat them as exposed:
   - Firebase console → Project settings → Service accounts → generate a new private key, delete the old key, and paste the new values into `secrets.php`.
   - Change the password of `adminaccount@admin.com` (or delete that user — nothing uses it any more).
2. Upload `secrets.php`, `config.php`, `notify.php`, `.htaccess` together. `secrets.php` is a PHP file that only `return`s an array, so it can't be downloaded as text even if `.htaccess` isn't honoured.
3. **Replace your Realtime Database rules** with the contents of `database.rules.json` (Firebase console → Realtime Database → Rules → Publish). It keeps your admin override and the same overall model, plus:
   - the typing indicator and read receipts are covered (members write only their own);
   - `accsettings` is readable only by signed-in users (was: anyone on the internet), `participants` is no longer world-readable;
   - you can no longer push a chat into a stranger's list — the other person must already be a member;
   - members can only edit/delete their own messages, and can only post as themselves;
   - a chat can only be created if you're in it, and deleted only by a member (rules can't count members, so the "last one out" check is done by the app);
   - `chatList/$uid` and `FCM/$uid` are writable by their owner as a whole, which account deletion needs;
   - basic type/length validation on profile, chat name, messages and `lastMessage`.

   After publishing, try the Rules Playground once or just send a message, edit it, delete it, and start a new chat to confirm. Keep `".indexOn": ["timestamp"]` on `messages` (already in the file).
4. Hard-refresh once (or unregister the old service worker) so devices pick up the new `firebase-messaging-sw.js`.

## Notes

- Notifications need HTTPS; on iOS the site must be installed to the home screen first.
- Photos/videos are stored inline in the database (as before). That's fine for a tiny app but will grow your DB quickly; a storage bucket would be the next step if usage grows.
- `notify.php` caches its short-lived Google access token in the system temp dir to avoid a token request on every message.

## Group calls (`call.html`)

Open `call.html?chatId=<chatId>`. Everyone in the chat shares one call; whoever opens the page can join, others can be rung from the People panel.

**Wire the button.** In `message.js`, once `chatId` is known:
```js
document.getElementById('callBtn').href = `call.html?chatId=${encodeURIComponent(chatId)}`;
```

**Files:** `call.html`, `call.css`, `js/call.js` (orchestration), `js/call/` — `signal.js` (Firebase sessions + inbox), `mesh.js` (WebRTC perfect negotiation per peer), `media.js` (mic/camera/screen), `tile.js`, `layout.js`, `ring.js`, `rtc-config.js`, `device.js`. Also changed: `js/ui.js` (new icons), `style.css` (old call CSS removed), `call-notify.php` (allows ringing your own other devices), `firebase-messaging-sw.js` (call rings persist and aren't swallowed by an open chat tab), `database.rules.json` (new `calls` section — merge it into your live rules).

**How it works**
- Each device/tab is its own *session* (`calls/{chatId}/sessions/{sessionId}`), so one account on a phone and a laptop is two participants (the second is labelled "Your other device"). Leaving on one device leaves the other in the call.
- Signalling goes through `calls/{chatId}/inbox/{uid}/{sessionId}/…` and is deleted once read, so stale offers/answers can't be replayed. Every link has an epoch; messages from an older epoch are dropped, which removes the "Called in wrong state: stable" class of error. Screen sharing renegotiates cleanly and appears as its own tile.
- Sessions heartbeat every 15 s; dead ones (>120 s) are removed by any member. A dropped network re-registers the session and rebuilds the links.
- It is a full mesh: great for 2–4 people, usable to ~6. For anything bigger you'd want an SFU.
- **TURN:** `js/call/rtc-config.js` only has public STUN. Add a TURN server there for users behind strict NATs/corporate networks — without one some pairs will show "Connection failed".


## App shell, persistent calls, split view (added with the call upgrade)

`index.html` is now the **shell**: chat list on the left, the open chat (`message.html`) or account page on the right (≥ 900 px wide; on phones the chat covers the list). Opening `message.html`, `account.html`-style deep links or `call.html` directly still works — they forward into the shell (`?chat=<id>`), unless you add `&standalone=1` (handy for debugging).

- **Calls survive navigation.** The call runs in its own iframe layer inside the shell. The arrow on the call screen *minimises* it: a green "in call" bar (mute / return / leave) appears at the top and you can open other chats. Hanging up returns to that chat's room.
- **Incoming calls** are shown full-screen on whatever page you're on (`js/incoming.js`, fed by `callRings/{uid}/{chatId}`, which `ring.js` writes next to `calls/{chatId}/ringing/{uid}`). Background push (`call-notify.php` + service worker) covers the app being closed. **Re-publish `database.rules.json`** — it has the new `callRings` section.
- Chat page shows a Discord-style **"Call in progress · 3 people · 12:34 · Join"** strip; the call screen shows the running duration.
- In the call: chat panel (same messages as the chat room), speaking glow, per-tile volume up to 200 %, own screen-share preview tile, mic/camera on/off remembered per browser (`localStorage`: `qm-call-mic`, `qm-call-cam`), controls fade with the cursor when the mouse rests, join/leave toasts.
- New files: `js/shell.js`, `js/embed.js`, `js/incoming.js`, `js/call/audio.js`. Changed: `index.html`, `message.html`, `style.css`, `js/index.js`, `js/message.js`, `js/account.js`, `js/call.js`, `js/call-banner.js`, `js/call/{tile,media,ring,mesh}.js`, `call.css`, `firebase-messaging-sw.js`, `database.rules.json`.
- Limits: reloading the page ends the call (it lives in the page). Volume above 100 % uses WebAudio gain, so very quiet sources can sound noisy.


## Chat upgrades (files, events, read markers)

- **Files via Litterbox.** Any file can be sent. Photos/videos that are too big to store in the database, and every non-media file, are uploaded to Litterbox with a 72 h expiry (the maximum) and a random 16-character name; the chat shows a notice first. The message stores the link, original name, size and expiry, shows the expiry under the file, displays images/video/audio inline, and greys the file out once expired. If the browser can't reach Litterbox directly, `upload.php` (needs `config.php`'s `api_key`) is used as a proxy. Re-publish `database.rules.json` (new message types/fields).
- **Camera:** the "Camera" button opens a live preview in-page to take a photo (falls back to the system camera picker on old browsers).
- **Inline events:** call started / ended (with duration), someone added, left or removed — stored as `type: "event"` messages; they never change the chat's last-message preview or send pushes.
- **Read markers:** every member's avatar sits under the last message they read (on anyone's messages and on events).
- **History paging** now pages by message key instead of the timestamp field, so older messages that have odd/missing timestamps no longer end the history early.
- **In a call:** the chat button opens the real chat page in a panel; the unread badge counts messages newer than your last-read marker. Streams are really pinned when they start (unless something is already pinned), videos have a pop-out (picture-in-picture) button and no browser right-click menu, and the minimised call bar shows participants' avatars with mic / camera / screen-share controls.
- Call links and notifications now carry a one-shot, short-lived token, so reloading, restoring a tab or pressing Back can't start a call by itself; the app's iframes are navigated with `location.replace` so Back no longer leaves a blank white pane on mobile.

## Sending, uploads and notifications (latest round)

- **Pending messages.** Everything you send (text, photos, videos, files, links) first appears as a grey copy of what it will
  look like. Litterbox uploads show `Uploading… NN%` where the expiry text will later appear. When the send is acknowledged the
  grey copy is swapped for the real message.
- **Failures.** A failed send turns red, shows "Failed to send", still raises the error toast, and the "more" button becomes an
  alert icon with **Retry / See error / Cancel**. Retry reuses the same message key, so it can never post twice; an upload that
  already finished is not re-uploaded.
- **Litterbox CORS.** Litterbox answers CORS preflights (`OPTIONS`) with 405, and any `xhr.upload.onprogress` listener forces a
  preflight. So: files that fit `upload.php` (its `post_max_size`/`upload_max_filesize`, reported by `upload.php?limits`) go
  through the same-origin relay, which gives a real progress percentage. Bigger files are posted straight to Litterbox as a
  *simple* request (no preflight); browsers can't report progress for that path, so it shows an animated "Uploading…".
  Each route falls back to the other. `upload.php` now returns readable errors (size limits, missing token, …).
- **Toasts are global.** Pages inside the app shell hand their toasts to the top page (`window.__qmToast`), so they stack in
  one place instead of overlapping inside iframes.
- **In-call chat** is loaded the first time you open it, then kept alive (hidden) so closing/reopening doesn't reload it. While
  hidden it doesn't mark messages as read.
- **Back.** The call arrow and the browser Back button just minimise the call and leave you where you were (chat, account page…).
  Hanging up still takes you to the call's chat.

## Call length, frame watchdog and the Android companion (latest round)

- **Call length** now comes from `calls/{chatId}/startedAt`, written by the first person into an empty call and cleared by the last one out, so it no longer resets when the person who started the call leaves. (New rule in `database.rules.json`.)
- **Frame watchdog** (`shell.js`): every embedded page calls `markReady()` once it has booted. If it doesn't within 15 s the shell reloads that frame (3 tries, cache-busted), then shows a "This page didn't load / Try again" panel instead of a white screen. If the call page disappears while you're in a call, the shell reloads it and the call page rejoins by itself (max 3 recoveries per 2 min). A frame that ends up showing the app shell inside itself is sent back to what it should show.
- **Android companion**: see `android/README.md`. Website side: Account, *Android companion* (`js/companion.js`).

## Phone as a call source (Android companion, round 2)

- **"My phone"** button in the call dock (shown once a phone is paired): pick an online phone, then choose per source: microphone (this device / phone / off), camera (this device / phone / off, with flip), and screen sharing from this device, the phone, or **both at once** (the phone's screen is a second shared screen, `screen2`, with its own tile).
- Online status uses the database server clock, and `companionLink/{uid}` is now readable by its owner in `database.rules.json` (without that rule the list could never be read, so every phone looked offline: publish the rules).
- Hanging up on the site ends the phone session too; either side can disconnect. See `android/README.md` for the protocol.
