// Android app only: hands the signed-in account to the app (so it can show message / incoming-call notifications natively,
// even when the page isn't open) and forgets it on sign-out. Does nothing in a normal browser.
import { auth } from "./firebase.js";
import { onIdTokenChanged } from "./sdk.js";
import { activeDbUrl } from "./dburl.js";
if (window.top === window && window.QMApp && window.QMApp.setSession) {
  onIdTokenChanged(auth, user => {
    try { window.QMApp.setDbUrl && window.QMApp.setDbUrl(activeDbUrl()); } catch (_) { /* ignore */ }
    try { user ? window.QMApp.setSession(user.uid, user.refreshToken) : window.QMApp.logout(); } catch (_) { /* ignore */ }
  });
}

// The app evaluates these in the top window; the call lives in an iframe, so pass screen-share frames/state down to it.
if (window.top === window && window.QMApp) {
  const callWin = () => { try { return document.getElementById("callFrame").contentWindow; } catch (_) { return null; } };
  window.__qmScreenAudio = b64 => { const w = callWin(); if (w && w.__qmScreenAudio) w.__qmScreenAudio(b64); };
  window.__qmScreenFrame = b64 => { const w = callWin(); if (w && w.__qmScreenFrame) w.__qmScreenFrame(b64); };
  window.__qmScreenState = s => { const w = callWin(); if (w && w.__qmScreenState) w.__qmScreenState(s); };
}
