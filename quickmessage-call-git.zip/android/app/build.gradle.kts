plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.quickmessage.companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.quickmessage.companion"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // WebRTC for Android (prebuilt, from Maven Central). Firebase itself is reached over its REST/SSE API, so there is no
    // google-services.json and no Firebase SDK.
    implementation("io.github.webrtc-sdk:android:125.6422.07")
}
