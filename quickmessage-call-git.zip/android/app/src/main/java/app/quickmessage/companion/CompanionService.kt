package app.quickmessage.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONObject

/**
 * Keeps the paired device connected: heartbeat (presence), command stream, and unpair detection.
 * Phases 2-3: it understands ping and set-microphone/camera/screen but only *acknowledges* the latter; real capture
 * (WebRTC) arrives in later phases and will be added here as extra foreground-service types.
 */
class CompanionService : Service() {
    @Volatile private var running = false
    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val media = JSONObject().put("microphone", false).put("camera", false).put("screen", false)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        store = Store(this); fb = Firebase(store)
        startForegroundCompat()
        if (!running && store.paired) {
            running = true
            Thread({ loop() }, "companion-link").start()
            Thread({ heartbeat() }, "companion-heartbeat").start()
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("link", "Connection", NotificationManager.IMPORTANCE_LOW))
        val n = builder()
            .setContentTitle("QuickMessage Companion").setContentText("Connected to your QuickMessage account")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "link") else Notification.Builder(this)

    private val base get() = "companionLink/${store.owner}/${store.deviceId}"
    private val sv = JSONObject().put(".sv", "timestamp")

    private fun status(s: String) { store.status = s }

    private fun unpaired() {
        status("Unpaired from the website")
        store.forget(); running = false
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    /** Is our credential still there? (The website deletes companionAuth/{uid} when you unpair.) */
    private fun stillPaired(): Boolean = try { fb.get("companionAuth/${store.authUid}") != null } catch (e: ApiException) { e.code != 401 && e.code != 403 } catch (e: Exception) { true }

    private fun heartbeat() {
        var first = true
        while (running) {
            try {
                val state = JSONObject().put("online", true).put("lastSeen", sv).put("name", store.name).put("appVersion", APP_VERSION)
                if (first) {
                    state.put("capabilities", JSONObject().put("microphone", false).put("camera", false).put("screen", false)
                        .put("backgroundCamera", false).put("backgroundMicrophone", false).put("controlOnly", true))
                    state.put("media", media)
                }
                fb.patch("$base/state", state.toString()); first = false
            } catch (e: ApiException) {
                if ((e.code == 401 || e.code == 403) && !stillPaired()) { unpaired(); return }
            } catch (_: Exception) { /* offline: try again next beat */ }
            try { Thread.sleep(20_000) } catch (_: InterruptedException) { return }
        }
    }

    private fun loop() {
        var backoff = 2000L
        while (running) {
            try {
                if (!stillPaired()) { unpaired(); return }
                status("Connected")
                fb.stream("$base/commands", { running }) { _, path, data ->
                    backoff = 2000L
                    when {
                        path == "/" && data is JSONObject -> data.keys().forEach { k -> data.optJSONObject(k)?.let { handle(k, it) } }
                        path != "/" && data is JSONObject -> handle(path.trim('/'), data)
                    }
                }
                status("Reconnecting…")
            } catch (e: ApiException) {
                if ((e.code == 401 || e.code == 403) && !stillPaired()) { unpaired(); return }
                status("Reconnecting… (${e.code})")
            } catch (e: Exception) { status("Offline, retrying…") }
            try { Thread.sleep(backoff) } catch (_: InterruptedException) { return }
            backoff = (backoff * 2).coerceAtMost(30_000L)
        }
    }

    private fun handle(id: String, cmd: JSONObject) {
        val age = System.currentTimeMillis() - cmd.optLong("t", 0)
        try { fb.delete("$base/commands/$id") } catch (_: Exception) {}
        if (age > 120_000) return                      // stale: from before we were online
        when (cmd.optString("type")) {
            "ping" -> fb.patch("$base/state", JSONObject().put("lastPing", JSONObject().put("id", id).put("at", sv)).toString())
            "set-microphone", "set-camera", "set-screen" -> {
                val key = cmd.getString("type").removePrefix("set-")
                // Phase 3 stub: acknowledge only. Phases 4-6 replace this with real capture and report the *actual* state.
                media.put(key, cmd.optBoolean("enabled"))
                fb.patch("$base/state", JSONObject().put("media", media).toString())
            }
        }
        status("Last command: ${cmd.optString("type")}")
    }

    companion object { const val APP_VERSION = "0.1.0" }
}
