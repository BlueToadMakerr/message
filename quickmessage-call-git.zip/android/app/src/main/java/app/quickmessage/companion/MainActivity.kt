package app.quickmessage.companion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Pair screen (enter the 6-digit code from the website) and a status screen with a Disconnect button. It is also where
 * Android's permission and screen-capture consent dialogs appear, which is why "Connect" in the notification opens it.
 */
class MainActivity : Activity() {
    companion object {
        const val ACTION_ASK = "app.quickmessage.companion.ASK"          // the website wants to use the phone
        const val ACTION_SCREEN = "app.quickmessage.companion.SCREEN"    // the website wants the phone's screen
        private const val REQ_PERMS = 7
        private const val REQ_PROJECTION = 8
    }

    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var pairing = false
    @Volatile private var cancelled = false
    private lateinit var root: LinearLayout
    private var statusView: TextView? = null
    private var pendingSid: String? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this); fb = Firebase(store)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        setContentView(root)
        render()
        ui.post(object : Runnable { override fun run() { tick(); ui.postDelayed(this, 1000) } })
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); handle(i) }
    override fun onDestroy() { cancelled = true; super.onDestroy() }

    private fun svc(action: String, fill: (Intent) -> Unit = {}) {
        val i = Intent(this, CompanionService::class.java).setAction(action).also(fill)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun handle(i: Intent?) {
        when (i?.action) {
            ACTION_ASK -> {
                pendingSid = i.getStringExtra("sid")
                val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (need.isEmpty()) acceptNow() else requestPermissions(need.toTypedArray(), REQ_PERMS)
            }
            ACTION_SCREEN -> {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
            }
        }
        i?.action = null
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERMS) acceptNow()      // use whatever was granted; the website is told if the rest is missing
    }

    private fun acceptNow() {
        val sid = pendingSid ?: return
        pendingSid = null
        val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        svc(CompanionService.ACTION_ACCEPT) { it.putExtra("sid", sid).putExtra("cam", cam).putExtra("mic", mic) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_PROJECTION) svc(CompanionService.ACTION_PROJECTION) { if (res == RESULT_OK && data != null) it.putExtra("data", data) }
    }

    private var shownPaired: Boolean? = null
    private fun tick() {
        if (shownPaired != store.paired && !pairing) render()
        if (store.paired) statusView?.text = "Paired as \"${store.name}\"\n${store.status}"
    }

    private fun render() {
        shownPaired = store.paired
        root.removeAllViews()
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; gravity = Gravity.CENTER; setPadding(0, 16, 0, 16) }
        root.addView(text("QuickMessage Companion", 24f))
        if (store.paired) {
            statusView = text("")
            root.addView(statusView)
            svc("app.quickmessage.companion.START")
            root.addView(Button(this).apply {
                text = "Disconnect from the call"
                setOnClickListener { svc(CompanionService.ACTION_DISCONNECT) }
            })
            root.addView(Button(this).apply {
                text = "Forget this pairing on the phone"
                setOnClickListener { stopService(Intent(this@MainActivity, CompanionService::class.java)); store.forget(); render() }
            })
            root.addView(text("To remove the device completely, use Unpair on the website's Account page.", 13f))
        } else {
            root.addView(text("On the website open Account → Android companion → Pair an Android device, then enter the 6-digit code here."))
            val code = EditText(this).apply { hint = "123456"; inputType = InputType.TYPE_CLASS_NUMBER; gravity = Gravity.CENTER; textSize = 28f; maxLines = 1
                filters = arrayOf(android.text.InputFilter.LengthFilter(6)) }
            val msg = text("")
            val go = Button(this).apply { text = "Pair" }
            go.setOnClickListener {
                val c = code.text.toString().trim()
                if (c.length != 6) { msg.text = "Enter all 6 digits."; return@setOnClickListener }
                pairing = true; cancelled = false; go.isEnabled = false
                Thread {
                    val r = Pairing.pair(fb, store, c, { s -> ui.post { msg.text = s } }, { cancelled })
                    ui.post {
                        pairing = false
                        if (r.ok) render() else { go.isEnabled = true; msg.text = r.error ?: "" }
                    }
                }.start()
            }
            root.addView(code); root.addView(go); root.addView(msg)
        }
    }
}
