package app.quickmessage.chat

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.FrameLayout

/**
 * The floating chat bubble. It shows ONE chat (message.html?bubble=1) and nothing else: the page hides its back / call buttons and
 * this activity refuses to navigate anywhere but that chat, so the rest of the app is not reachable from a bubble — the same
 * "call area only" idea as the lock-screen protection. It shares the app's sign-in (same WebView storage) but runs its own page.
 */
class BubbleActivity : Activity() {
    private lateinit var web: WebView
    private var chat = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        chat = intent?.getStringExtra(MainActivity.EXTRA_CHAT).orEmpty()
        if (!Regex("^[\\w-]{1,64}$").matches(chat)) { finish(); return }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false; allowContentAccess = false
        }
        val allowed = Config.SITE_URL + "message.html"
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                return !(u.startsWith(allowed) && r.url.getQueryParameter("chatId") == chat)   // anything else: stay put
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest) { r.deny() }           // no camera / microphone in a bubble
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean { cb.onReceiveValue(null); return true }
        }
        web.loadUrl("$allowed?chatId=$chat&standalone=1&bubble=1")
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
