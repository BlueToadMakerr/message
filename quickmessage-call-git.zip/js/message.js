import { auth, db } from "./firebase.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import {
  ref, push, set, get, update, remove, onValue, onDisconnect,
  onChildAdded, onChildChanged, onChildRemoved,
  query, orderByChild, orderByKey, limitToLast, startAt, endBefore
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import {
  toast, confirmDialog, promptDialog, avatarEl, icon, hydrateIcons, linkify, safeMediaUrl,
  copyText, formatMsgTime, wireDialog, alertDialog
} from "./ui.js";
import { initCallBanner } from "./call-banner.js";
import { QM, enterShell, trackSplit, toHome, markReady } from "./embed.js";
import { uploadToLitterbox, isLitterUrl, fmtBytes, kindOf, MAX_BYTES } from "./litter.js";
import { logEvent } from "./chatlog.js";
import { getProfile, peekProfile, ensureProfile, profileExists, invalidateProfile } from "./users.js";

hydrateIcons();

const $ = id => document.getElementById(id);
const chatId = new URLSearchParams(location.search).get("chatId");
if (!chatId || !/^[\w-]{1,64}$/.test(chatId)) {
  location.replace("index.html");
  throw new Error("Missing or invalid chatId");
}
if (enterShell(`chat=${encodeURIComponent(chatId)}`)) throw new Error("Redirecting into the app shell");
trackSplit();
if (QM) document.querySelector('.topbar > a[aria-label="Back to chats"]')?.addEventListener("click", e => { e.preventDefault(); QM.closeDetail(); });

const PAGE = 30;
const OLDER_PAGE = 40;
const MAX_VIDEO_BYTES = 8 * 1024 * 1024; // base64 inflates ~33%; RTDB rejects very large writes
const TYPING_IDLE_MS = 4000;

const messagesDiv = $("messages"), typingRow = $("typingRow"), typingLabel = $("typingLabel");
const historyStatus = $("historyStatus"), jumpBtn = $("jumpBtn");
const composer = $("composer"), msgInput = $("msgInput"), sendBtn = $("sendBtn");
const menuEl = $("msgMenu");

const chatPath = `privateChats/${chatId}`;
initCallBanner({ chatId, callBtn: document.getElementById("callBtn"), after: document.querySelector(".topbar") });
const messagesRef = ref(db, `${chatPath}/messages`);
const lastRef = ref(db, `${chatPath}/lastMessage`);

// ---------- state ----------
let me = null;
let participants = [];
let customName = "";
let customPhoto = "";
let isGroup = false;
let baseSub = "";
let typingUids = [];
let typingNames = [];
let typingToken = 0;
let readReceipts = {};
const msgData = new Map();       // key -> message value
let latestKey = null;            // key of newest rendered message
let lastMarked = null;
let ready = false;
let stick = true;                // was the user at the bottom?
let oldestKey = null, loadingOlder = false, reachedStart = false;

// ---------- helpers ----------
const isNearBottom = () => messagesDiv.scrollHeight - messagesDiv.scrollTop - messagesDiv.clientHeight < 80;
let ignoreScrollUntil = 0, lastOlderAt = 0;
/** An image/video finished loading. Newly loaded media in the live part follows the bottom; media in OLDER messages (prepended above)
 *  must never move the reader: the scroll position is compensated for the growth instead, and the bottom is not forced. */
function onMedia(el) {
  const msg = el && el.closest && el.closest(".msg");
  if (msg && msg.dataset.old) {
    const h = msg.offsetHeight, d = h - (+msg.dataset.h || h);
    msg.dataset.h = h;
    if (d && msg.getBoundingClientRect().top < messagesDiv.getBoundingClientRect().top) { ignoreScrollUntil = Date.now() + 250; messagesDiv.scrollTop += d; }
    return;
  }
  if (stick) scrollToBottom();
}
const scrollToBottom = () => { messagesDiv.scrollTop = messagesDiv.scrollHeight; stick = true; jumpBtn.classList.add("hidden"); };
const isText = m => !m.type || m.type === "text";
const previewOf = m => m.type === "image" ? "📷 Photo" : m.type === "video" ? "🎥 Video" : m.type === "file" ? "📎 " + (m.name || "File") : (m.text ?? m.content ?? "");
const fmtDur = ms => { const t = Math.max(0, Math.round(ms / 1000)), h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), sec = t % 60; return h ? `${h}h ${m}m` : m ? `${m}m ${sec}s` : `${sec}s`; };
const fmtExpiry = ts => new Date(ts).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
if (new URLSearchParams(location.search).has("panel")) document.documentElement.classList.add("panel");

// ---------- header ----------
function renderSub() {
  const sub = $("chatSub");
  if (typingNames.length) {
    sub.textContent = typingNames.length === 1 ? "typing…" : `${typingNames.join(", ")} typing…`;
    sub.classList.add("typing");
  } else {
    sub.textContent = baseSub;
    sub.classList.remove("typing");
  }
}

async function updateHeader() {
  const others = participants.filter(u => u !== me);
  const profiles = await Promise.all(others.map(getProfile));
  const title = customName.trim() || profiles.map(p => p.displayName).join(", ") || "Chat";
  $("chatTitle").textContent = title;
  document.title = `${title} · QuickMessage`;
  const useOther = !customName.trim() && profiles.length === 1;
  $("headAvatar").replaceChildren(avatarEl(title, customPhoto || (useOther ? profiles[0].pfp : ""), "avatar sm"));
  isGroup = participants.length > 2;
  $("groupPhotoBox").hidden = !isGroup;
  messagesDiv.classList.toggle("group", isGroup);
  baseSub = isGroup ? `${participants.length} members` : "";
  renderSub();
}

// ---------- message rendering ----------
// Litterbox files: shown inline when possible, greyed out once they've expired (the message itself stays).
function fillFile(bubble, msg) {
  const url = isLitterUrl(msg.url) ? msg.url : null;
  const expired = typeof msg.expiresAt === "number" && Date.now() > msg.expiresAt;
  const wrap = document.createElement("div");
  wrap.className = "file-wrap" + (expired ? " expired" : "");
  const kind = msg.kind || "file";
  const card = () => {
    const c = document.createElement(url && !expired ? "a" : "div");
    c.className = "file-card";
    if (url && !expired) { c.href = url; c.target = "_blank"; c.rel = "noopener noreferrer"; c.download = msg.name || ""; }
    c.innerHTML = `<span class="file-ic">${icon("file", 22)}</span><span class="file-meta"><span class="file-name"></span><span class="file-size"></span></span>`;
    c.querySelector(".file-name").textContent = msg.name || "File";
    c.querySelector(".file-size").textContent = [typeof msg.size === "number" ? fmtBytes(msg.size) : "", expired ? "Expired" : ""].filter(Boolean).join(" · ");
    return c;
  };
  if (url && !expired && kind === "image") {
    const img = new Image();
    img.className = "media"; img.alt = msg.name || "Image"; img.loading = "lazy"; img.referrerPolicy = "no-referrer";
    img.addEventListener("load", ev => onMedia(ev.target));
    img.addEventListener("error", () => { wrap.classList.add("expired"); img.replaceWith(card()); });
    img.addEventListener("click", () => { $("lightboxImg").src = url; $("lightbox").showModal(); });
    img.src = url;
    wrap.append(img);
  } else if (url && !expired && kind === "video") {
    const v = document.createElement("video");
    v.className = "media"; v.controls = true; v.preload = "metadata"; v.playsInline = true;
    v.addEventListener("loadedmetadata", ev => onMedia(ev.target));
    v.addEventListener("error", () => { wrap.classList.add("expired"); v.replaceWith(card()); });
    v.src = url;
    wrap.append(v);
  } else if (url && !expired && kind === "audio") {
    const a = document.createElement("audio");
    a.controls = true; a.preload = "metadata"; a.src = url;
    wrap.append(a, card());
  } else {
    wrap.append(card());
    if (expired && kind === "image") wrap.classList.add("ghost-image");
  }
  const note = document.createElement("div");
  note.className = "file-expiry";
  note.textContent = typeof msg.expiresAt === "number" ? (expired ? "Expired " : "Expires ") + fmtExpiry(msg.expiresAt) : "";
  bubble.append(wrap, note);
  bubble.classList.add("file-bubble");
}

function eventText(msg) {
  const name = u => peekProfile(u)?.displayName || "Someone";
  switch (msg.event) {
    case "call_start": return `📞 ${name(msg.fromUid)} started a call`;
    case "call_end": return `📞 Call ended${typeof msg.duration === "number" ? " · " + fmtDur(msg.duration) : ""}`;
    case "chat_add": return `➕ ${name(msg.fromUid)} added ${name(msg.target)}`;
    case "chat_leave": return `👋 ${name(msg.fromUid)} left the chat`;
    case "chat_kick": return `🚫 ${name(msg.fromUid)} removed ${name(msg.target)}`;
    default: return msg.text || "";
  }
}

function buildEvent(key, msg) {
  const el = document.createElement("div");
  el.className = "msg-event";
  el.id = "msg-" + key;
  el.dataset.key = key;
  el.innerHTML = `<span class="ev-text"></span><span class="ev-time"></span><span class="readBy"></span>`;
  const paint = () => { el.querySelector(".ev-text").textContent = eventText(msg); };
  paint();
  el.querySelector(".ev-time").textContent = formatMsgTime(msg.timestamp);
  const ids = [msg.fromUid, msg.target].filter(Boolean);
  Promise.all(ids.map(getProfile)).then(paint);
  return el;
}
function fillMessage(el, key, msg) {
  const bubble = el.querySelector(".bubble");
  bubble.replaceChildren();
  bubble.classList.remove("media-bubble");

  if (msg.type === "file") {
    fillFile(bubble, msg);
  } else if (msg.type === "image" || msg.type === "video") {
    const kind = msg.type;
    const src = safeMediaUrl(msg.content || msg.text, kind);
    if (!src) {
      bubble.textContent = kind === "image" ? "Unsupported image" : "Unsupported video";
    } else if (kind === "image") {
      const img = new Image();
      img.className = "media";
      img.alt = "Image";
      img.loading = "lazy";
      img.referrerPolicy = "no-referrer";
      img.addEventListener("load", ev => onMedia(ev.target));
      img.addEventListener("click", () => { $("lightboxImg").src = src; $("lightbox").showModal(); });
      img.src = src;
      bubble.append(img);
      bubble.classList.add("media-bubble");
    } else {
      const v = document.createElement("video");
      v.className = "media";
      v.controls = true;
      v.preload = "metadata";
      v.playsInline = true;
      v.addEventListener("loadedmetadata", ev => onMedia(ev.target));
      v.src = src;
      bubble.append(v);
      bubble.classList.add("media-bubble");
    }
  } else {
    bubble.append(linkify(msg.text ?? msg.content ?? ""));
  }

  el.querySelector(".time").textContent = formatMsgTime(msg.timestamp);
  el.querySelector(".edited").classList.toggle("hidden", !msg.editedAt);
}

function buildMessage(key, msg) {
  if (msg.type === "event") return buildEvent(key, msg);
  const own = msg.fromUid === me;
  const el = document.createElement("div");
  el.className = `msg ${own ? "own" : "other"}`;
  el.id = "msg-" + key;
  el.dataset.key = key;

  const col = document.createElement("div");
  col.className = "msg-col";

  if (!own) {
    const av = avatarEl("", "", "msg-avatar");
    el.append(av);
    const name = document.createElement("div");
    name.className = "msg-name";
    col.append(name);
    const apply = p => { name.textContent = p.displayName; av.replaceWith(avatarEl(p.displayName, p.pfp, "msg-avatar")); };
    const cached = peekProfile(msg.fromUid);
    if (cached) apply(cached); else getProfile(msg.fromUid).then(apply);
  }

  const row = document.createElement("div");
  row.className = "bubble-row";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (own) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "icon-btn msg-menu";
    btn.setAttribute("aria-label", "Message actions");
    btn.innerHTML = icon("more", 16);
    btn.addEventListener("click", e => { e.stopPropagation(); showMenu(key, btn); });
    row.append(bubble, btn);
  } else {
    row.append(bubble);
    if (isText(msg)) {   // others' messages get a "more" button too (Copy)
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "icon-btn msg-menu";
      btn.setAttribute("aria-label", "Message actions");
      btn.innerHTML = icon("more", 16);
      btn.addEventListener("click", e => { e.stopPropagation(); showMenu(key, btn); });
      row.append(btn);
    }
  }

  const foot = document.createElement("div");
  foot.className = "msg-foot";
  foot.innerHTML = `<span class="time"></span><span class="edited hidden">· edited</span><span class="readBy"></span>`;

  col.append(row, foot);
  el.append(col);
  fillMessage(el, key, msg);
  return el;
}

function appendLive(key, msg) {
  if (document.getElementById("msg-" + key)) return null;
  msgData.set(key, msg);
  const el = buildMessage(key, msg);
  messagesDiv.insertBefore(el, typingRow);
  latestKey = key;
  return el;
}

function onAdded(snap) {
  const msg = snap.val();
  if (!msg || document.getElementById("msg-" + snap.key) || pendingKeys.has(snap.key)) return;   // pending: finishJob swaps it in
  const wasNear = isNearBottom();
  appendLive(snap.key, msg);
  renderReceipts();
  if (!ready) return;
  if (msg.fromUid === me || wasNear) scrollToBottom();
  else jumpBtn.classList.remove("hidden");
  maybeMarkRead();
}

function onChanged(snap) {
  const msg = snap.val();
  if (!msg) return;
  msgData.set(snap.key, msg);
  const el = document.getElementById("msg-" + snap.key);
  if (el && msg.type !== "event") fillMessage(el, snap.key, msg); else if (!el) onAdded(snap);
}

function onRemoved(snap) {
  msgData.delete(snap.key);
  document.getElementById("msg-" + snap.key)?.remove();
  if (latestKey === snap.key) {
    const msgs = messagesDiv.querySelectorAll(".msg");
    latestKey = msgs.length ? msgs[msgs.length - 1].dataset.key : null;
  }
}

let lastPageShort = false;
async function loadOlder() {
  if (loadingOlder || reachedStart || oldestKey == null) return;
  if (Date.now() - lastOlderAt < 600) { setTimeout(loadOlder, 650); return; }      // never chain page after page
  loadingOlder = true;
  historyStatus.textContent = "Loading older messages…";
  try {
    const snap = await get(query(messagesRef, orderByKey(), endBefore(oldestKey), limitToLast(OLDER_PAGE)));
    const list = [];
    snap.forEach(s => { list.push(s); });
    if (!list.length) {
      reachedStart = true;
      historyStatus.textContent = "Beginning of the conversation";
    } else {
      const prevHeight = messagesDiv.scrollHeight;
      const anchor = messagesDiv.querySelector(".msg") || typingRow;
      const added = [];
      for (const s of list) {
        if (document.getElementById("msg-" + s.key)) continue;
        const m = s.val();
        msgData.set(s.key, m);
        const el = buildMessage(s.key, m);
        el.dataset.old = "1";
        messagesDiv.insertBefore(el, anchor);
        added.push(el);
      }
      oldestKey = list[0].key;
      ignoreScrollUntil = Date.now() + 400;
      messagesDiv.scrollTop += messagesDiv.scrollHeight - prevHeight;
      added.forEach(el => { el.dataset.h = el.offsetHeight; });
      // A short page does not prove we reached the start (the SDK can answer from a partial cache): only an empty page does.
      historyStatus.textContent = "";
      lastPageShort = list.length < OLDER_PAGE;
    }
  } catch (err) {
    console.error("Failed to load history", err);
    historyStatus.textContent = "Couldn't load older messages";
  }
  loadingOlder = false; lastOlderAt = Date.now();
  if (!reachedStart && lastPageShort && messagesDiv.scrollTop < 40) { lastPageShort = false; setTimeout(loadOlder, 0); return; }   // confirm the start with an empty page
  fillViewport();
}

// If the loaded messages don't even fill the screen there's nothing to scroll, so keep pulling older ones.
function fillViewport() {
  if (!reachedStart && !loadingOlder && ready && messagesDiv.scrollHeight <= messagesDiv.clientHeight + 60) setTimeout(loadOlder, 0);
}

messagesDiv.addEventListener("scroll", () => {
  stick = isNearBottom();
  if (stick) jumpBtn.classList.add("hidden");
  if (messagesDiv.scrollTop < 40 && Date.now() > ignoreScrollUntil) loadOlder();
  closeMenu();
}, { passive: true });
jumpBtn.addEventListener("click", scrollToBottom);

// ---------- read receipts ----------
// When this page lives in the call's chat panel it stays loaded while the panel is closed; the call page tells us.
let panelHidden = false;
window.addEventListener("message", e => {
  if (e.origin !== location.origin || !e.data || e.data.qm !== "panel") return;
  panelHidden = !e.data.visible;
  if (!panelHidden) { maybeMarkRead(); scrollToBottom(); }
});
const IS_PANEL = new URLSearchParams(location.search).has("panel");
function maybeMarkRead() {
  if (!ready || !latestKey || document.hidden || panelHidden) return;
  // the full-screen call covers this chat: nothing here counts as read (the call's own chat panel marks its messages itself)
  if (!IS_PANEL) { try { if (QM && QM.state && QM.state.call && QM.state.call.visible) return; } catch (_) { /* ignore */ } }
  if (String(lastMarked) === String(latestKey)) return;
  lastMarked = latestKey;
  set(ref(db, `${chatPath}/messageRead/${me}`), latestKey).catch(() => {});
}
document.addEventListener("visibilitychange", () => { if (!document.hidden) maybeMarkRead(); });
window.addEventListener("focus", maybeMarkRead);
setInterval(maybeMarkRead, 1500);   // also catches the call overlay being minimised/closed

// A small avatar under the last message each other member has read — on every message, not just ours,
// so in groups you can see exactly where everyone left off.
function renderReceipts() {
  messagesDiv.querySelectorAll(".readBy").forEach(el => { el.replaceChildren(); });
  const byKey = {};
  for (const [uid, key] of Object.entries(readReceipts)) {
    if (uid === me || !participants.includes(uid)) continue;
    (byKey[String(key)] ||= []).push(uid);
  }
  for (const [key, uids] of Object.entries(byKey)) {
    const el = document.getElementById("msg-" + key);
    const host = el && el.querySelector(".readBy");
    if (!host) continue;
    for (const u of uids) {
      const p = peekProfile(u);
      const av = avatarEl(p?.displayName || "?", p?.pfp || "", "avatar read-av");
      av.title = "Seen by " + (p?.displayName || "someone");
      host.append(av);
    }
  }
}

// ---------- typing indicator ----------
let isTyping = false;
let typingTimer = null;
const myTypingRef = () => ref(db, `${chatPath}/typing/${me}`);

function setTyping(on) {
  if (!me || on === isTyping) return;
  isTyping = on;
  if (on) {
    set(myTypingRef(), true).catch(() => {});
    onDisconnect(myTypingRef()).remove().catch(() => {});
  } else {
    remove(myTypingRef()).catch(() => {});
  }
}

function bumpTyping() {
  clearTimeout(typingTimer);
  if (!msgInput.value.trim()) { setTyping(false); return; }
  setTyping(true);
  typingTimer = setTimeout(() => setTyping(false), TYPING_IDLE_MS);
}

async function renderTyping() {
  const token = ++typingToken;
  if (!typingUids.length) {
    typingRow.classList.add("hidden");
    typingNames = [];
    renderSub();
    return;
  }
  const ps = await Promise.all(typingUids.map(getProfile));
  if (token !== typingToken) return; // newer update superseded this one
  typingNames = ps.map(p => p.displayName);
  typingLabel.textContent =
    typingNames.length === 1 ? `${typingNames[0]} is typing…` :
    typingNames.length === 2 ? `${typingNames[0]} and ${typingNames[1]} are typing…` :
    "Several people are typing…";
  const wasNear = isNearBottom();
  typingRow.classList.remove("hidden");
  renderSub();
  if (wasNear) scrollToBottom();
}

msgInput.addEventListener("input", () => { autosize(); bumpTyping(); });
msgInput.addEventListener("blur", () => { clearTimeout(typingTimer); setTyping(false); });
document.addEventListener("visibilitychange", () => { if (document.hidden) { clearTimeout(typingTimer); setTyping(false); } });
window.addEventListener("pagehide", () => { if (isTyping) remove(myTypingRef()).catch(() => {}); });

// ---------- composer ----------
function autosize() {
  msgInput.style.height = "auto";
  msgInput.style.height = Math.min(msgInput.scrollHeight, 140) + "px";
}

msgInput.addEventListener("keydown", e => {
  // Enter sends on desktop; on touch devices Enter inserts a newline.
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing && matchMedia("(pointer: fine)").matches) {
    e.preventDefault();
    composer.requestSubmit();
  }
});
sendBtn.addEventListener("mousedown", e => e.preventDefault()); // keep keyboard open on mobile

composer.addEventListener("submit", e => {
  e.preventDefault();
  const text = msgInput.value.trim();
  if (!text) return;
  msgInput.value = "";
  autosize();
  clearTimeout(typingTimer);
  setTyping(false);
  startJob({ type: "text", text });
  msgInput.focus();
});

// ---------- sending: every outgoing message first shows up as a grey "pending" copy of what it will look like ----------
// A job owns that grey bubble. While it uploads/writes it shows progress; on failure it turns red with an alert button
// (Retry / Cancel / See error). A retry reuses the same message key, so it can never double-post.
const SEND_TIMEOUT = 20000;
const jobs = new Map();                 // id -> job
const pendingKeys = new Set();          // message keys whose real child_added is held back until the write is acknowledged
let jobSeq = 0;

const buildPayload = (spec, timestamp) =>
  spec.type === "text" ? { fromUid: me, text: spec.text, timestamp }
  : spec.type === "file" ? { fromUid: me, type: "file", text: spec.extra.name, ...spec.extra, timestamp }
  : { fromUid: me, type: spec.type, content: spec.content, timestamp };

/** @param spec {type:'text'|'image'|'video'|'file', text?, content?, extra?} message to send
 *  @param opts {file?:File, prepare?:(job)=>Promise<spec>} */
function startJob(spec, opts = {}) {
  const job = { id: ++jobSeq, spec, file: opts.file || null, prepare: opts.prepare || null, state: "sending", progress: null, error: null,
    ref: null, ts: 0, localUrl: opts.file ? URL.createObjectURL(opts.file) : null, ctrl: null, cancelled: false, litter: false };
  jobs.set(job.id, job);
  const fake = { fromUid: me, type: spec.type, text: spec.text, content: spec.content, timestamp: Date.now() };
  job.el = buildMessage("job-" + job.id, fake);
  job.el.classList.add("pending");
  const old = job.el.querySelector(".msg-menu");
  const btn = old.cloneNode(true);                   // drop the real-message menu handler
  old.replaceWith(btn);
  btn.addEventListener("click", e => { e.stopPropagation(); showJobMenu(job, btn); });
  job.btn = btn;
  messagesDiv.insertBefore(job.el, typingRow);
  paintJob(job);
  scrollToBottom();
  runJob(job);
  return job;
}

function paintJob(job) {
  const el = job.el, bubble = el.querySelector(".bubble"), failed = job.state === "error";
  el.classList.toggle("failed", failed);
  el.classList.toggle("pending", !failed);
  job.btn.innerHTML = icon(failed ? "alert" : "more", 16);
  job.btn.classList.add("job-btn");
  job.btn.classList.toggle("job-err", failed);
  job.btn.setAttribute("aria-label", failed ? "Message failed — options" : "Sending — options");
  const spec = job.spec, lit = job.litter || spec.type === "file";
  bubble.replaceChildren();
  bubble.classList.remove("media-bubble", "file-bubble");
  const src = job.localUrl || (spec.type === "image" || spec.type === "video" ? safeMediaUrl(spec.content, spec.type) : null);
  const kind = lit ? (spec.extra?.kind || kindOf(job.file?.type)) : spec.type;
  if (spec.type === "text") {
    bubble.append(linkify(spec.text));
  } else if (src && kind === "image") {
    const img = new Image(); img.className = "media"; img.alt = "Sending image"; img.referrerPolicy = "no-referrer";
    img.addEventListener("load", ev => onMedia(ev.target));
    img.src = src; bubble.append(img); bubble.classList.add("media-bubble");
  } else if (src && kind === "video") {
    const v = document.createElement("video"); v.className = "media"; v.muted = true; v.preload = "metadata"; v.playsInline = true;
    v.addEventListener("loadedmetadata", ev => onMedia(ev.target));
    v.src = src; bubble.append(v); bubble.classList.add("media-bubble");
  } else {
    const c = document.createElement("div");
    c.className = "file-card";
    c.innerHTML = `<span class="file-ic">${icon("file", 22)}</span><span class="file-meta"><span class="file-name"></span><span class="file-size"></span></span>`;
    c.querySelector(".file-name").textContent = job.file?.name || spec.extra?.name || "File";
    c.querySelector(".file-size").textContent = job.file ? fmtBytes(job.file.size) : "";
    const w = document.createElement("div"); w.className = "file-wrap"; w.append(c);
    bubble.append(w); bubble.classList.add("file-bubble");
  }
  // Litterbox uploads: percent (or "Uploading…") sits where the expiry text will go once it's sent.
  job.note = null;
  if (lit) {
    const bar = document.createElement("div"); bar.className = "up-bar"; bar.innerHTML = "<i></i>";
    const note = document.createElement("div"); note.className = "file-expiry up-note";
    bubble.append(bar, note);
    job.bar = bar; job.note = note;
  }
  paintJobProgress(job);
}

function paintJobProgress(job) {
  const failed = job.state === "error", uploading = job.progress !== "sending" && (job.litter || job.spec.type === "file") && !job.spec.extra?.url;
  const foot = job.el.querySelector(".time");
  const pct = typeof job.progress === "number" ? Math.floor(job.progress * 100) : null;
  if (foot) foot.textContent = failed ? "Failed to send" : (uploading ? "Uploading…" : "Sending…");
  if (job.note) job.note.textContent = failed ? (uploading ? "Upload failed" : "Couldn't send") : uploading ? (pct == null ? "Uploading…" : `Uploading… ${pct}%`) : "Sending…";
  if (job.bar) {
    job.bar.classList.toggle("indet", !failed && uploading && pct == null);
    job.bar.hidden = failed || !uploading;
    job.bar.firstChild.style.width = (pct ?? 0) + "%";
  }
}

async function runJob(job) {
  job.state = "sending"; job.error = null;
  job.ctrl = new AbortController();
  paintJob(job);
  try {
    if (job.prepare) {
      const spec = await job.prepare(job);
      if (job.cancelled) return;
      job.spec = spec;
      job.prepare = null;                                // cached: a retry goes straight to the write
      if (spec.type === "file") job.litter = true;
    }
    job.progress = "sending";
    paintJob(job);
    await Promise.race([writeJob(job), new Promise((_, rej) => setTimeout(() => rej(new Error("Timed out — check your connection and retry.")), SEND_TIMEOUT))]);
  } catch (err) {
    if (job.cancelled || err.aborted || !jobs.has(job.id)) return;
    failJob(job, err);
  }
}

function writeJob(job) {
  job.ref ||= push(messagesRef);
  job.ts ||= Date.now();
  const payload = buildPayload(job.spec, job.ts), key = job.ref.key;
  job.key = key; job.payload = payload;
  pendingKeys.add(key);
  const p = update(ref(db), {
    [`${chatPath}/messages/${key}`]: payload,
    [`${chatPath}/lastMessage`]: { fromUid: me, text: previewOf(payload), timestamp: job.ts, id: key }
  });
  p.then(() => { if (jobs.has(job.id) && !job.cancelled) finishJob(job); }, () => {});
  return p;
}

function finishJob(job) {
  jobs.delete(job.id);
  pendingKeys.delete(job.key);
  if (job.localUrl) URL.revokeObjectURL(job.localUrl);
  job.el.remove();
  closeMenu();
  if (!document.getElementById("msg-" + job.key)) {
    msgData.set(job.key, job.payload);
    appendLive(job.key, job.payload);
    renderReceipts();
  }
  scrollToBottom();
  maybeMarkRead();
  notifyServer();
}

function failJob(job, err) {
  console.error("Send failed", err);
  job.state = "error";
  job.error = (err && err.message) || String(err);
  paintJob(job);
  const what = job.spec.type === "text" ? "Message" : "File";
  toast(`${what} failed to send: ${friendlyError(job.error)}`, "error", 6000);
}

const friendlyError = m => /permission_denied/i.test(m) ? "you don't have permission to post here." : String(m).replace(/^Error:\s*/, "").slice(0, 140);

function cancelJob(job) {
  job.cancelled = true;
  job.ctrl?.abort();
  jobs.delete(job.id);
  if (job.key) { pendingKeys.delete(job.key); if (job.ref) remove(job.ref).catch(() => {}); }  // in case a timed-out write lands later
  if (job.localUrl) URL.revokeObjectURL(job.localUrl);
  job.el.remove();
}

function showJobMenu(job, btn) {
  const wasOpen = btn.classList.contains("open");
  closeMenu();
  if (wasOpen) return;
  btn.classList.add("open");
  menuEl.replaceChildren();
  const add = (label, ico, fn, danger = false) => {
    const b = document.createElement("button");
    b.type = "button";
    if (danger) b.className = "danger";
    b.innerHTML = icon(ico, 16);
    b.append(document.createTextNode(label));
    b.addEventListener("click", () => { closeMenu(); fn(); });
    menuEl.append(b);
  };
  if (job.state === "error") {
    add("Retry", "send", () => runJob(job));
    add("See error", "alert", () => alertDialog({ title: "Why it failed", message: job.error || "Unknown error" }));
  }
  add(job.state === "error" ? "Cancel" : "Cancel sending", "close", () => cancelJob(job), true);
  menuEl.classList.remove("hidden");
  const r = btn.getBoundingClientRect(), m = menuEl.getBoundingClientRect();
  menuEl.style.left = Math.min(Math.max(8, r.right - m.width), innerWidth - m.width - 8) + "px";
  let top = r.bottom + 4;
  if (top + m.height > innerHeight - 8) top = Math.max(8, r.top - m.height - 4);
  menuEl.style.top = top + "px";
}

// Used by anything that just needs "send this now" semantics (e.g. the link dialog).
function sendMessage(spec) { return startJob(spec); }

async function notifyServer() {
  try {
    const idToken = await auth.currentUser.getIdToken();
    await fetch("notify.php", { method: "POST", body: new URLSearchParams({ chatId, idToken }) });
  } catch (err) {
    console.warn("Notification request failed", err);
  }
}

// ---------- message actions ----------
function closeMenu() {
  if (menuEl.classList.contains("hidden")) return;
  menuEl.classList.add("hidden");
  messagesDiv.querySelectorAll(".msg-menu.open").forEach(b => b.classList.remove("open"));
}

function showMenu(key, btn) {
  const wasOpen = btn.classList.contains("open");
  closeMenu();
  if (wasOpen) return;
  const msg = msgData.get(key);
  if (!msg) return;
  btn.classList.add("open");
  menuEl.replaceChildren();
  const add = (label, ico, fn, danger = false) => {
    const b = document.createElement("button");
    b.type = "button";
    if (danger) b.className = "danger";
    b.innerHTML = icon(ico, 16);
    b.append(document.createTextNode(label));
    b.addEventListener("click", () => { closeMenu(); fn(); });
    menuEl.append(b);
  };
  if (isText(msg)) {
    add("Copy", "copy", () => copyText(msg.text ?? msg.content ?? ""));
    if (msg.fromUid === me) add("Edit", "more", () => editMessage(key));
  }
  if (msg.fromUid === me) add("Delete", "close", () => deleteMessage(key), true);

  menuEl.classList.remove("hidden");
  const r = btn.getBoundingClientRect();
  const m = menuEl.getBoundingClientRect();
  const left = Math.min(Math.max(8, r.right - m.width), innerWidth - m.width - 8);
  let top = r.bottom + 4;
  if (top + m.height > innerHeight - 8) top = Math.max(8, r.top - m.height - 4);
  menuEl.style.left = left + "px";
  menuEl.style.top = top + "px";
}

document.addEventListener("pointerdown", e => {
  if (!menuEl.contains(e.target) && !e.target.closest(".msg-menu")) closeMenu();
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeMenu(); });
window.addEventListener("resize", closeMenu);

async function isLastMessage(key, msg) {
  const last = (await get(lastRef)).val();
  if (!last) return null;
  if (last.id === key) return last;
  // Legacy messages have no id in lastMessage; fall back to matching sender + text.
  if (!last.id && last.fromUid === me && last.text === previewOf(msg)) return last;
  return null;
}

async function editMessage(key) {
  const msg = msgData.get(key);
  if (!msg || !isText(msg)) return;
  const val = await promptDialog({
    title: "Edit message", okText: "Save",
    input: { value: msg.text ?? "", multiline: true, maxLength: 4000 }
  });
  if (val === null) return;
  const text = val.trim();
  if (!text || text === msg.text) return;
  try {
    // Keep the original timestamp so the message doesn't jump in the ordering.
    await update(ref(db, `${chatPath}/messages/${key}`), { text, editedAt: Date.now() });
    if (await isLastMessage(key, msg)) await update(lastRef, { text, id: key });
  } catch (err) {
    console.error(err);
    toast("Couldn't edit that message.", "error");
  }
}

async function deleteMessage(key) {
  const msg = msgData.get(key);
  const ok = await confirmDialog({
    title: "Delete message?", message: "This removes it for everyone in the chat.",
    okText: "Delete", danger: true
  });
  if (!ok) return;
  try {
    const wasLast = msg ? await isLastMessage(key, msg) : null;
    await remove(ref(db, `${chatPath}/messages/${key}`));
    if (wasLast) {
      // Point the chat-list preview at the previous message instead of the deleted one.
      let prev = null;
      (await get(query(messagesRef, orderByChild("timestamp"), limitToLast(1)))).forEach(s => { prev = { key: s.key, ...s.val() }; });
      await set(lastRef, prev
        ? { fromUid: prev.fromUid, text: previewOf(prev), timestamp: prev.timestamp, id: prev.key, notifSent: true }
        : { fromUid: "", text: "(No messages yet)", timestamp: wasLast.timestamp || Date.now() });
    }
  } catch (err) {
    console.error(err);
    toast("Couldn't delete that message.", "error");
  }
}

// ---------- media ----------
const attachDialog = $("attachDialog");
wireDialog(attachDialog);
wireDialog($("optionsDialog"));
$("lightbox").addEventListener("click", () => $("lightbox").close());

$("attachBtn").onclick = () => { $("mediaUrl").value = ""; attachDialog.showModal(); };
$("attachClose").onclick = () => attachDialog.close();
$("pickFileBtn").onclick = () => $("fileInput").click();
$("pickCameraBtn").onclick = () => { attachDialog.close(); openCamera(); };
for (const id of ["fileInput", "cameraInput"]) {
  $(id).addEventListener("change", e => {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    attachDialog.close();
    sendFile(file);
  });
}

$("sendLinkBtn").onclick = async () => {
  const url = $("mediaUrl").value.trim();
  if (!/^https?:\/\/\S+$/i.test(url)) return toast("Enter a full http(s) link.", "error");
  const type = /\.(mp4|webm|mov|m4v|ogv|ogg)(\?|#|$)/i.test(url) ? "video" : "image";
  attachDialog.close();
  sendMessage({ type, content: url });
};

const readAsDataURL = file => new Promise((resolve, reject) => {
  const r = new FileReader();
  r.onload = () => resolve(r.result);
  r.onerror = () => reject(new Error("Couldn't read that file."));
  r.readAsDataURL(file);
});

async function prepareImage(file) {
  const LIMIT = 2.8 * 1024 * 1024; // characters in the data URL
  if (file.type === "image/gif" || file.type === "image/svg+xml") {
    if (file.size > 2 * 1024 * 1024) throw new Error("That file is over 2 MB.");
    return readAsDataURL(file);
  }
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: "from-image" }); }
  catch {
    if (file.size > 2 * 1024 * 1024) throw new Error("That image is over 2 MB.");
    return readAsDataURL(file);
  }
  try {
    for (const [dim, q] of [[1280, 0.82], [1024, 0.7], [800, 0.6]]) {
      const scale = Math.min(1, dim / Math.max(bmp.width, bmp.height));
      const w = Math.max(1, Math.round(bmp.width * scale)), h = Math.max(1, Math.round(bmp.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(bmp, 0, 0, w, h);
      const url = canvas.toDataURL("image/jpeg", q);
      if (url.length <= LIMIT) return url;
    }
  } finally { bmp.close?.(); }
  throw new Error("That image is too large even after resizing.");
}

const TOO_BIG = "That file is too big to send directly, so it's being uploaded to Litterbox. It will expire after 3 days.";
const OTHER = "Files are uploaded to Litterbox and expire after 3 days.";

async function litterSpec(job, why) {
  const file = job.file;
  if (file.size > MAX_BYTES) throw new Error("That file is over Litterbox's 1 GB limit.");
  job.litter = true;
  if (!job.noticed) { job.noticed = true; toast(why, "info", 7000); }
  paintJob(job);
  const info = await uploadToLitterbox(file, f => { job.progress = f; paintJobProgress(job); }, job.ctrl.signal);
  return { type: "file", extra: info };
}

// Every file becomes a job: it shows a grey preview straight away, and the work of resizing/uploading happens inside it.
function sendFile(file) {
  const t = file.type || "";
  const prepare = async job => {
    if (t.startsWith("image/")) {
      let dataUrl = null;
      try { dataUrl = await prepareImage(file); } catch (_) { /* too large for inline → Litterbox */ }
      return dataUrl ? { type: "image", content: dataUrl } : litterSpec(job, TOO_BIG);
    }
    if (t.startsWith("video/")) {
      return file.size > MAX_VIDEO_BYTES ? litterSpec(job, TOO_BIG) : { type: "video", content: await readAsDataURL(file) };
    }
    return litterSpec(job, OTHER);
  };
  // Until prepare() decides, give the placeholder the right look: images/videos preview, anything else is a file card.
  const guess = t.startsWith("image/") ? "image" : t.startsWith("video/") ? "video" : "file";
  startJob({ type: guess, extra: guess === "file" ? { name: file.name || "File", kind: kindOf(t) } : undefined }, { file, prepare });
}

// Paste an image straight from the clipboard (with a confirmation preview).
msgInput.addEventListener("paste", async e => {
  const item = [...(e.clipboardData?.items || [])].find(i => i.type.startsWith("image/"));
  if (!item) return;
  e.preventDefault();
  const file = item.getAsFile();
  if (!file) return;
  const objUrl = URL.createObjectURL(file);
  const preview = new Image();
  preview.src = objUrl;
  preview.alt = "Pasted image";
  preview.style.cssText = "max-width:100%;max-height:240px;border-radius:12px;align-self:center";
  const ok = await confirmDialog({ title: "Send this image?", node: preview, okText: "Send" });
  URL.revokeObjectURL(objUrl);
  if (ok) sendFile(file);
});

// ---------- chat options ----------
const optionsDialog = $("optionsDialog");
let participantsRenderToken = 0;

$("chatOptionsBtn").onclick = () => {
  $("chatNameInput").value = customName;
  $("chatPhotoInput").value = customPhoto;
  renderParticipants();
  optionsDialog.showModal();
};
$("optionsClose").onclick = () => optionsDialog.close();

$("savePhotoBtn").onclick = async () => {
  const v = $("chatPhotoInput").value.trim();
  if (v && !/^https?:\/\/\S+$/i.test(v)) { toast("Enter a full image URL starting with http:// or https://", "error"); return; }
  try { await set(ref(db, `${chatPath}/chatData/photo`), v); toast(v ? "Group photo saved." : "Group photo removed.", "success"); }
  catch (err) { console.error(err); toast("Couldn't save the photo.", "error"); }
};

$("saveChatNameBtn").onclick = async () => {
  try {
    await set(ref(db, `${chatPath}/chatData/name`), $("chatNameInput").value.trim());
    toast("Chat name saved.", "success");
  } catch (err) {
    console.error(err);
    toast("Couldn't save the chat name.", "error");
  }
};

async function renderParticipants() {
  const token = ++participantsRenderToken;
  const profiles = await Promise.all(participants.map(getProfile));
  if (token !== participantsRenderToken) return;
  const list = $("participantsList");
  list.replaceChildren();
  profiles.forEach(p => {
    const row = document.createElement("div");
    row.className = "participant-row";
    row.append(avatarEl(p.displayName, p.pfp, "avatar sm"));
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = p.displayName;
    if (p.uid === me) {
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = "You";
      name.append(tag);
    }
    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "icon-btn";
    copy.setAttribute("aria-label", `Copy ${p.displayName}'s UID`);
    copy.title = "Copy UID";
    copy.innerHTML = icon("copy", 18);
    copy.onclick = async () => { await copyText(p.uid); toast("UID copied.", "success", 1800); };
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn small" + (p.uid === me ? " danger" : "");
    btn.textContent = p.uid === me ? "Leave" : "Remove";
    btn.onclick = () => removeParticipant(p.uid);
    row.append(name, copy, btn);
    list.append(row);
  });
}

async function removeParticipant(uid) {
  const self = uid === me;
  const name = peekProfile(uid)?.displayName || "this user";
  const ok = await confirmDialog({
    title: self ? "Leave this chat?" : `Remove ${name}?`,
    message: self ? "You won't see this conversation anymore." : "They will no longer see this conversation.",
    okText: self ? "Leave" : "Remove", danger: true
  });
  if (!ok) return;

  try {
    const snap = await get(ref(db, `${chatPath}/participants`));
    const current = snap.val() || {};
    if (self && Object.keys(current).length === 1) {
      await remove(ref(db, chatPath));
      remove(ref(db, `chatList/${me}/${chatId}`)).catch(() => {});
      toast("Chat deleted because you were the only member.");
      setTimeout(() => toHome(), 600);
      return;
    }
    await logEvent(chatId, me, { event: self ? "chat_leave" : "chat_kick", target: self ? null : uid });
    await update(ref(db), {
      [`${chatPath}/participants/${uid}`]: null,
      [`${chatPath}/messageRead/${uid}`]: null,
      [`${chatPath}/typing/${uid}`]: null
    });
    if (self) {
      remove(ref(db, `chatList/${me}/${chatId}`)).catch(() => {});
      toast("You left the chat.");
      setTimeout(() => toHome(), 600);
    } else {
      toast(`${name} was removed.`);
    }
  } catch (err) {
    console.error(err);
    toast("That didn't work. You may not have permission.", "error");
  }
}

$("addUserBtn").onclick = async () => {
  const input = $("addUserUid");
  const newUid = input.value.trim();
  if (!newUid) return toast("Enter a UID.", "error");
  if (!/^[\w-]{6,128}$/.test(newUid)) return toast("That doesn't look like a valid UID.", "error");
  if (participants.includes(newUid)) return toast("They're already in this chat.", "error");

  try {
    if (!(await profileExists(newUid))) return toast("No user found with that UID.", "error");
    const p = await getProfile(newUid);
    const node = document.createElement("div");
    node.className = "profile-preview";
    const label = document.createElement("div");
    label.className = "name";
    label.textContent = p.displayName;
    node.append(avatarEl(p.displayName, p.pfp, "avatar"), label);
    const ok = await confirmDialog({ title: "Add to this chat?", node, okText: "Add" });
    if (!ok) return;
    await update(ref(db, `${chatPath}/participants`), { [newUid]: true });
    await set(ref(db, `chatList/${newUid}/${chatId}`), true);
    logEvent(chatId, me, { event: "chat_add", target: newUid });
    input.value = "";
    toast(`${p.displayName} was added.`, "success");
  } catch (err) {
    console.error(err);
    toast("Couldn't add that user.", "error");
  }
};

// ---------- boot ----------
function leaveChat(message) {
  toast(message, "error");
  setTimeout(() => toHome(), 900);
}

onAuthStateChanged(auth, async user => {
  if (!user) { toHome(); return; }
  if (me) return; // already initialised
  me = user.uid;
  ensureProfile(user).catch(() => {});

  // Membership + header (also detects being removed from the chat)
  onValue(ref(db, `${chatPath}/participants`), snap => {
    const v = snap.val();
    if (!v || !v[me]) { leaveChat("You're no longer in this chat."); return; }
    participants = Object.keys(v);
    updateHeader();
    renderReceipts();
    if (optionsDialog.open) renderParticipants();
  }, () => leaveChat("You don't have access to this chat."));

  onValue(ref(db, `${chatPath}/chatData/photo`), snap => { customPhoto = snap.val() || ""; updateHeader(); }, () => {});
  onValue(ref(db, `${chatPath}/chatData/name`), snap => {
    customName = snap.val() || "";
    updateHeader();
  }, () => {});

  onValue(ref(db, `${chatPath}/messageRead`), snap => {
    readReceipts = snap.val() || {};
    // make sure names are cached before drawing "Seen by …"
    Promise.all(Object.keys(readReceipts).map(getProfile)).then(renderReceipts);
  }, () => {});

  onValue(ref(db, `${chatPath}/typing`), snap => {
    const v = snap.val() || {};
    typingUids = Object.keys(v).filter(u => u !== me && v[u]);
    renderTyping();
  }, () => {});

  // Initial page of history, then a live window starting at its oldest message.
  historyStatus.textContent = "Loading messages…";
  const slowT = setTimeout(() => { if (!ready) historyStatus.textContent = "Still loading… your connection looks slow"; }, 5000);
  try {
    const initSnap = await Promise.race([get(query(messagesRef, orderByKey(), limitToLast(PAGE))), new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 25000))]);
    clearTimeout(slowT);
    if (historyStatus.textContent.startsWith("Loading") || historyStatus.textContent.startsWith("Still loading")) historyStatus.textContent = "";
    const initial = [];
    initSnap.forEach(s => { initial.push(s); });

    if (!initial.length) {
      reachedStart = true;
      historyStatus.textContent = "No messages yet — say hi 👋";
    }
    if (initial.length) oldestKey = initial[0].key;
    initial.forEach(s => appendLive(s.key, s.val()));
    renderReceipts();
    scrollToBottom();
    ready = true;
    maybeMarkRead();
    fillViewport();

    const live = query(messagesRef, orderByKey(), startAt(oldestKey ?? ""));
    onChildAdded(live, onAdded);
    onChildChanged(live, onChanged);
    onChildRemoved(live, onRemoved);
  } catch (err) {
    console.error("Failed to load messages", err);
    clearTimeout(slowT);
    const off = navigator.onLine === false || /offline/i.test(String(err && err.message));
    historyStatus.innerHTML = "";
    historyStatus.append(off ? "You're offline — messages couldn't load. " : "There was a problem loading this chat. ");
    const retry = document.createElement("button"); retry.type = "button"; retry.className = "btn small"; retry.textContent = "Try again";
    retry.onclick = () => location.reload();
    historyStatus.append(retry);
  }
});


// ---------- take a photo with the camera ----------
const camDlg = $("cameraDialog"), camVideo = $("camVideo"), camShot = $("camShot");
let camStream = null, camFacing = "environment", camBlob = null;
const stopCam = () => { camStream?.getTracks().forEach(t => t.stop()); camStream = null; camVideo.srcObject = null; };
async function startCam() {
  stopCam();
  camVideo.hidden = false; camShot.hidden = true; camBlob = null;
  $("camSnap").hidden = false; $("camSend").hidden = true; $("camRetake").hidden = true;
  camStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: camFacing }, width: { ideal: 1920 } }, audio: false });
  camVideo.srcObject = camStream;
  await camVideo.play().catch(() => {});
  const n = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput").length;
  $("camFlip").hidden = n < 2;
}
async function openCamera() {
  if (!navigator.mediaDevices?.getUserMedia) { $("cameraInput").click(); return; }   // old browsers: system camera picker
  camDlg.showModal();
  try { await startCam(); }
  catch (err) {
    camDlg.close();
    toast(err && err.name === "NotAllowedError" ? "Camera access was blocked. Allow it in your browser's site settings." : "Couldn't open the camera.", "error");
  }
}
wireDialog(camDlg);
camDlg.addEventListener("close", stopCam);
$("camClose").onclick = () => camDlg.close();
$("camFlip").onclick = async () => { camFacing = camFacing === "user" ? "environment" : "user"; try { await startCam(); } catch (_) { /* keep dialog */ } };
$("camSnap").onclick = () => {
  const w = camVideo.videoWidth, h = camVideo.videoHeight;
  if (!w) return;
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  c.getContext("2d").drawImage(camVideo, 0, 0, w, h);
  c.toBlob(b => {
    if (!b) return;
    camBlob = b;
    camShot.src = URL.createObjectURL(b);
    camShot.hidden = false; camVideo.hidden = true;
    $("camSnap").hidden = true; $("camSend").hidden = false; $("camRetake").hidden = false;
    stopCam();
  }, "image/jpeg", 0.9);
};
$("camRetake").onclick = () => { URL.revokeObjectURL(camShot.src); startCam().catch(() => camDlg.close()); };
$("camSend").onclick = () => {
  if (!camBlob) return;
  const file = new File([camBlob], "photo.jpg", { type: "image/jpeg" });
  camDlg.close();
  sendFile(file);
};

markReady();   // tells the app shell this frame booted (see frame watchdog in shell.js)
