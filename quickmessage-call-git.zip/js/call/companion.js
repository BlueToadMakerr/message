// CompanionLink — one "use my phone in this call" session between this browser and a paired Android device.
//
// The browser is the WebRTC *offerer* with three receive-only transceivers, always in this order:
//     0 = microphone (audio)   1 = camera (video)   2 = screen (video)
// The phone answers and sends on whichever of them are switched on. Signalling goes through the Realtime Database
// (companionLink/{uid}/{deviceId}/rtc/{sessionId}/web|app), requests through `session`, commands through `commands`,
// and the phone reports what it is *actually* doing in `state` (never assume a command worked).
import { db } from "../firebase.js";
import { ref, set, remove, push, onValue, onChildAdded, onDisconnect } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";
import { RTC_CONFIG } from "./rtc-config.js";
import { sendCommand } from "../companion.js";

const rid = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), b => b.toString(16).padStart(2, "0")).join("");
const REQUEST_TIMEOUT_MS = 120000;     // the phone has to show a notification and the user has to tap it

export const PHONE = Object.freeze({ IDLE: "idle", REQUESTING: "requesting", CONNECTING: "connecting", LIVE: "live", DECLINED: "declined", ENDED: "ended", ERROR: "error" });

export class CompanionLink {
  /** @param {{uid:string, deviceId:string, name:string, onChange:()=>void, log?:Function}} o */
  constructor({ uid, deviceId, name, onChange, log }) {
    this.uid = uid; this.deviceId = deviceId; this.name = name;
    this.onChange = onChange || (() => {});
    this.log = log || (() => {});
    this.sid = rid();
    this.status = PHONE.REQUESTING;
    this.error = null;
    this.media = { microphone: false, camera: false, screen: false };
    this.facing = null;
    this.tracks = { mic: null, cam: null, screen: null };
    this._base = `companionLink/${uid}/${deviceId}`;
    this._unsubs = [];
    this._pending = [];
    this._closed = false;
  }

  _set(status, error = null) {
    if (this._closed && status !== PHONE.ENDED) return;
    this.status = status; this.error = error;
    this.onChange();
  }

  async start(want = {}) {
    const sessionRef = ref(db, `${this._base}/session`);
    await set(sessionRef, { id: this.sid, status: "requested", t: Date.now(), want });
    onDisconnect(sessionRef).remove().catch(() => {});       // closing the tab / losing connection ends the session on the phone too

    const pc = (this.pc = new RTCPeerConnection(RTC_CONFIG));
    this.tx = [pc.addTransceiver("audio", { direction: "recvonly" }), pc.addTransceiver("video", { direction: "recvonly" }), pc.addTransceiver("video", { direction: "recvonly" })];
    this.tracks = { mic: this.tx[0].receiver.track, cam: this.tx[1].receiver.track, screen: this.tx[2].receiver.track };
    pc.onicecandidate = e => { if (e.candidate && !this._closed) this._sig({ t: "cand", d: e.candidate.toJSON() }); };
    pc.onconnectionstatechange = () => {
      if (this._closed) return;
      const s = pc.connectionState;
      if (s === "connected") this._set(PHONE.LIVE);
      else if (s === "failed") this._set(PHONE.ERROR, "The connection to the phone failed. Both devices need internet access.");
      else if (s === "disconnected") this.onChange();
    };

    const web = ref(db, `${this._base}/rtc/${this.sid}/web`);
    this._sig = msg => { set(push(web), msg).catch(e => this.log("signal write failed", e)); };

    // answers / candidates from the phone
    this._unsubs.push(onChildAdded(ref(db, `${this._base}/rtc/${this.sid}/app`), snap => this._onSignal(snap.val()), () => {}));
    // what the phone says it is doing
    this._unsubs.push(onValue(ref(db, `${this._base}/state`), snap => this._onState(snap.val() || {}), () => {}));

    await pc.setLocalDescription();
    this._sig({ t: "desc", d: { type: pc.localDescription.type, sdp: pc.localDescription.sdp } });
    this._timer = setTimeout(() => { if (this.status === PHONE.REQUESTING) this._set(PHONE.ERROR, "The phone didn't respond. Is the app running and online?"); }, REQUEST_TIMEOUT_MS);
  }

  async _onSignal(m) {
    const pc = this.pc;
    if (!m || !pc || this._closed) return;
    try {
      if (m.t === "desc" && m.d && m.d.type === "answer") {
        if (pc.signalingState !== "have-local-offer") return;
        await pc.setRemoteDescription(m.d);
        for (const c of this._pending.splice(0)) await pc.addIceCandidate(c).catch(() => {});
      } else if (m.t === "cand" && m.d) {
        if (!pc.remoteDescription) this._pending.push(m.d); else await pc.addIceCandidate(m.d).catch(() => {});
      }
    } catch (err) { this.log("signal error", err); }
  }

  _onState(st) {
    const s = st.session;
    if (s && s.id === this.sid) {
      if (s.status === "ringing" && this.status === PHONE.REQUESTING) this.onChange();
      else if ((s.status === "accepted" || s.status === "live") && this.status === PHONE.REQUESTING) { clearTimeout(this._timer); this._set(PHONE.CONNECTING); }
      else if (s.status === "declined") this._set(PHONE.DECLINED);
      else if (s.status === "ended") this._set(PHONE.ENDED);
      this.phoneStatus = s.status;
    }
    if (s && s.id === this.sid && st.error && st.error.at > (this._errAt || 0)) {
      this._errAt = st.error.at; this.lastError = st.error.msg;
    }
    const m = st.media || {};
    this.media = { microphone: !!m.microphone, camera: !!m.camera, screen: !!m.screen };
    this.facing = m.facing || null;
    this.onChange();
  }

  // ------------------------------------------------------------------ commands (the phone confirms through state.media)
  setMicrophone(on) { return sendCommand(this.uid, this.deviceId, { type: "set-microphone", enabled: !!on }); }
  setCamera(on, facing) { return sendCommand(this.uid, this.deviceId, { type: "set-camera", enabled: !!on, ...(facing ? { facing } : {}) }); }
  setScreen(on) { return sendCommand(this.uid, this.deviceId, { type: "set-screen", enabled: !!on }); }
  switchCamera() { return sendCommand(this.uid, this.deviceId, { type: "switch-camera" }); }

  /** End the session on both sides. Safe to call repeatedly. */
  async disconnect() {
    if (this._closed) return;
    this._closed = true;
    clearTimeout(this._timer);
    this._unsubs.forEach(u => { try { u(); } catch (_) { /* ignore */ } });
    this._unsubs = [];
    try { this.pc && this.pc.close(); } catch (_) { /* ignore */ }
    const sessionRef = ref(db, `${this._base}/session`);
    try { await onDisconnect(sessionRef).cancel(); } catch (_) { /* ignore */ }
    await Promise.allSettled([remove(sessionRef), remove(ref(db, `${this._base}/rtc`))]);
    this.status = PHONE.ENDED;
    this.onChange();
  }
}
