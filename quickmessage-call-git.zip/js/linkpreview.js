// Link previews: finds links in a message and shows what they are.
//  - images / videos / audio files → shown inline
//  - YouTube / Vimeo → a thumbnail that turns into the player when clicked (privacy-friendly nocookie embed)
//  - everything else → a card (title, description, picture) fetched by link-preview.php, plus an embeddable player when the site offers one
// Turn off per device in Account → Link previews.
import { auth, db } from "./firebase.js";
import { ref, get } from "./sdk.js";
import { customDbUrl } from "./dburl.js";

const URL_RE = /https?:\/\/[^\s<>"']+/gi;
const MAX_PER_MESSAGE = 2;
export const previewsOn = () => { try { return localStorage.getItem("qm-previews") !== "off"; } catch (_) { return true; } };
export const setPreviews = on => { try { localStorage.setItem("qm-previews", on ? "on" : "off"); } catch (_) { /* ignore */ } };

const cache = new Map();             // url -> Promise<{data, retry}>   (this page only)
const clean = u => u.replace(/[).,;:!?]+$/, "");
const extOf = u => { try { return new URL(u).pathname.split(".").pop().toLowerCase(); } catch (_) { return ""; } };

function youtubeId(u) {
  try {
    const x = new URL(u), h = x.hostname.replace(/^www\.|^m\./, "");
    if (h === "youtu.be") return x.pathname.slice(1).split("/")[0] || null;
    if (h === "youtube.com" || h === "music.youtube.com") {
      if (x.pathname === "/watch") return x.searchParams.get("v");
      const m = /^\/(shorts|embed|live)\/([\w-]{6,})/.exec(x.pathname); if (m) return m[2];
    }
  } catch (_) { /* ignore */ }
  return null;
}
function vimeoId(u) { try { const x = new URL(u); if (/(^|\.)vimeo\.com$/.test(x.hostname)) { const m = /^\/(\d{5,})/.exec(x.pathname); return m ? m[1] : null; } } catch (_) { /* ignore */ } return null; }

// Where a preview comes from, in order:
//  1. the shared cache in the database (linkPreviews/{id}, written by link-preview.php) — free of charge to the server, good for a week;
//  2. link-preview.php, which fetches the page (just its first part) and stores the good result in that cache.
// If the server finds nothing to show for a link that WAS cached, or can't be reached, the cached preview keeps being shown.
// A link that has no preview at all is not cached anywhere. A network failure is retried when the connection is back.
const WEEK = 7 * 864e5;
async function idOf(url) {
  const h = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(url));
  return [...new Uint8Array(h)].slice(0, 16).map(b => b.toString(16).padStart(2, "0")).join("");
}
const usingCustomDb = () => !!customDbUrl();     // another database: its previews never go into the default one
const hasContent = m => !!(m && (m.title || m.description || m.image));

async function loadMeta(url, priv) {
  priv = priv || usingCustomDb();
  let stale = null;
  if (!priv) {
    try {
      const snap = await get(ref(db, `linkPreviews/${await idOf(url)}`));
      const e = snap.val();
      if (e && hasContent(e.d)) {
        if (Date.now() - (e.t || 0) < WEEK) return { data: e.d, retry: false };
        stale = e.d;                                           // older than a week: ask for an update, but keep this as the fallback
      }
    } catch (_) { /* the database can't be reached right now: the server request below decides */ }
  }
  try {
    const idToken = await auth.currentUser.getIdToken();
    const r = await fetch("link-preview.php", { method: "POST", body: new URLSearchParams({ idToken, url, ...(priv ? { private: "1" } : {}) }) });
    if (!r.ok) return { data: stale, retry: r.status >= 500 || r.status === 429 };
    const j = await r.json();
    if (hasContent(j)) return { data: j, retry: false };
    return { data: stale, retry: false };                      // the page has no preview (any more): show the old one if there is one
  } catch (_) {
    return { data: stale, retry: true };                       // no network / server unreachable: try again when it is back
  }
}

function fetchMeta(url, priv) {
  const k = (priv ? "p:" : "") + url;
  if (!cache.has(k)) {
    cache.set(k, (async () => {
      const hit = (() => { try { return sessionStorage.getItem("qm-lp:" + k); } catch (_) { return null; } })();
      if (hit) return { data: JSON.parse(hit), retry: false };
      const r = await loadMeta(url, priv);
      if (r.retry) cache.delete(k);                            // don't remember a failure
      else if (r.data) { try { sessionStorage.setItem("qm-lp:" + k, JSON.stringify(r.data)); } catch (_) { /* full */ } }
      return r;
    })());
  }
  return cache.get(k);
}

const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

function playerCard(url, thumb, title, iframeSrc, host, creator) {
  const c = el("div", "lp-card lp-video");
  const stage = el("button", "lp-stage"); stage.type = "button"; stage.setAttribute("aria-label", "Play video");
  if (thumb) { const i = new Image(); i.src = thumb; i.alt = ""; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; stage.append(i); }
  stage.append(el("span", "lp-play", "▶"));
  stage.addEventListener("click", () => {
    const f = document.createElement("iframe");
    f.src = iframeSrc; f.allow = "autoplay; fullscreen; picture-in-picture; encrypted-media"; f.allowFullscreen = true;
    f.referrerPolicy = "strict-origin-when-cross-origin"; f.className = "lp-frame";
    f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-presentation allow-popups");
    stage.replaceWith(f);
  });
  const meta = el("a", "lp-meta"); meta.href = url; meta.target = "_blank"; meta.rel = "noopener noreferrer";
  meta.append(el("span", "lp-site", host), el("strong", "lp-title", title || url));
  if (creator) meta.append(el("span", "lp-desc", creator));
  c.append(stage, meta);
  return c;
}

async function build(url, onLayout, priv) {
  const ext = extOf(url);
  if (["png", "jpg", "jpeg", "gif", "webp", "avif", "bmp"].includes(ext)) {
    const i = new Image(); i.className = "lp-img"; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; i.alt = "Linked image";
    i.addEventListener("load", () => onLayout && onLayout(i)); i.addEventListener("error", () => i.remove());
    i.src = url; return { node: i };
  }
  if (["mp4", "webm", "mov", "m4v", "ogv"].includes(ext)) {
    const v = document.createElement("video"); v.className = "lp-img"; v.controls = true; v.preload = "metadata"; v.playsInline = true; v.src = url;
    v.addEventListener("loadedmetadata", () => onLayout && onLayout(v)); return { node: v };
  }
  if (["mp3", "wav", "m4a", "aac", "flac", "opus"].includes(ext)) { const a = document.createElement("audio"); a.controls = true; a.preload = "none"; a.src = url; return { node: a }; }
  const yt = youtubeId(url);
  const { data: meta, retry } = await fetchMeta(url, priv);
  if (yt) return { node: playerCard(url, `https://i.ytimg.com/vi/${yt}/hqdefault.jpg`, meta?.title, `https://www.youtube-nocookie.com/embed/${encodeURIComponent(yt)}?autoplay=1&rel=0`, "YouTube", meta?.creator), retry };
  const vm = vimeoId(url);
  if (vm) return { node: playerCard(url, meta?.image, meta?.title, `https://player.vimeo.com/video/${vm}?autoplay=1`, "Vimeo"), retry };
  if (!meta || !(meta.title || meta.description || meta.image)) return { node: null, retry };
  if (meta.embed) return { node: playerCard(url, meta.image, meta.title, meta.embed, meta.site || new URL(url).hostname), retry };
  const a = el("a", "lp-card"); a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer";
  if (meta.image) { const i = new Image(); i.src = meta.image; i.alt = ""; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; i.className = "lp-thumb"; i.addEventListener("load", () => onLayout && onLayout(i)); i.addEventListener("error", () => i.remove()); a.append(i); }
  const m = el("div", "lp-meta");
  m.append(el("span", "lp-site", meta.site || new URL(url).hostname));
  if (meta.title) m.append(el("strong", "lp-title", meta.title));
  if (meta.description) m.append(el("span", "lp-desc", meta.description));
  a.append(m);
  return { node: a, retry };
}

/** Adds preview cards under a text bubble. enc: the message is end-to-end encrypted, so its links are never put in the shared cache. */
export function attachPreviews(bubble, text, { onLayout, enc } = {}) {
  if (!previewsOn() || !text) return;
  const urls = [...new Set((String(text).match(URL_RE) || []).map(clean))].filter(u => { try { return /^https?:$/.test(new URL(u).protocol); } catch (_) { return false; } }).slice(0, MAX_PER_MESSAGE);
  if (!urls.length) return;
  const box = el("div", "lp-box");
  bubble.append(box);
  urls.forEach(u => {
    let shown = null, tries = 0;
    const run = () => build(u, onLayout, !!enc).then(({ node, retry }) => {
      if (!previewsOn() || bubble.isConnected === false) return;
      if (node && !shown) { shown = node; box.append(node); onLayout && onLayout(box); }
      if (retry && ++tries <= 8) waitForNetwork(run);          // couldn't reach the server: look again once the connection is back
    }).catch(() => {});
    run();
  });
}

// Runs fn when the device is back online (or after a pause if the browser doesn't say), once.
function waitForNetwork(fn) {
  let done = false;
  const go = () => { if (done) return; done = true; removeEventListener("online", go); clearTimeout(t); fn(); };
  addEventListener("online", go);
  const t = setTimeout(() => { if (navigator.onLine !== false) go(); else { done = true; removeEventListener("online", go); waitForNetwork(fn); } }, 30000);
}
