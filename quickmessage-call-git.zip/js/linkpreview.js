// Link previews: finds links in a message and shows what they are.
//  - images / videos / audio files → shown inline
//  - YouTube / Vimeo → a thumbnail that turns into the player when clicked (privacy-friendly nocookie embed)
//  - everything else → a card (title, description, picture) fetched by link-preview.php, plus an embeddable player when the site offers one
// Turn off per device in Account → Link previews.
import { auth } from "./firebase.js";

const URL_RE = /https?:\/\/[^\s<>"']+/gi;
const MAX_PER_MESSAGE = 2;
export const previewsOn = () => { try { return localStorage.getItem("qm-previews") !== "off"; } catch (_) { return true; } };
export const setPreviews = on => { try { localStorage.setItem("qm-previews", on ? "on" : "off"); } catch (_) { /* ignore */ } };

const cache = new Map();             // url -> Promise<data|null>
const clean = u => u.replace(/[).,;:!?]+$/, "");
const extOf = u => { try { return new URL(u).pathname.split(".").pop().toLowerCase(); } catch (_) { return ""; } };

function youtubeId(u) {
  try {
    const x = new URL(u), h = x.hostname.replace(/^www\.|^m\./, "");
    if (h === "youtu.be") return x.pathname.slice(1).split("/")[0] || null;
    if (h === "youtube.com" || h === "music.youtube.com") {
      if (x.pathname === "/watch") return x.searchParams.get("v");
      const m = /^\/(shorts|embed|live)\/([\w-]{6,})/.exec(x.pathname); if (m) return m[2];
    }
  } catch (_) { /* ignore */ }
  return null;
}
function vimeoId(u) { try { const x = new URL(u); if (/(^|\.)vimeo\.com$/.test(x.hostname)) { const m = /^\/(\d{5,})/.exec(x.pathname); return m ? m[1] : null; } } catch (_) { /* ignore */ } return null; }

async function fetchMeta(url) {
  if (!cache.has(url)) {
    cache.set(url, (async () => {
      try {
        const k = "qm-lp:" + url;
        const hit = sessionStorage.getItem(k);
        if (hit) return JSON.parse(hit);
        const idToken = await auth.currentUser.getIdToken();
        const r = await fetch("link-preview.php", { method: "POST", body: new URLSearchParams({ idToken, url }) });
        if (!r.ok) return null;
        const j = await r.json();
        try { sessionStorage.setItem(k, JSON.stringify(j)); } catch (_) { /* full */ }
        return j;
      } catch (_) { return null; }
    })());
  }
  return cache.get(url);
}

const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

function playerCard(url, thumb, title, iframeSrc, host) {
  const c = el("div", "lp-card lp-video");
  const stage = el("button", "lp-stage"); stage.type = "button"; stage.setAttribute("aria-label", "Play video");
  if (thumb) { const i = new Image(); i.src = thumb; i.alt = ""; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; stage.append(i); }
  stage.append(el("span", "lp-play", "▶"));
  stage.addEventListener("click", () => {
    const f = document.createElement("iframe");
    f.src = iframeSrc; f.allow = "autoplay; fullscreen; picture-in-picture; encrypted-media"; f.allowFullscreen = true;
    f.referrerPolicy = "strict-origin-when-cross-origin"; f.className = "lp-frame";
    f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-presentation allow-popups");
    stage.replaceWith(f);
  });
  const meta = el("a", "lp-meta"); meta.href = url; meta.target = "_blank"; meta.rel = "noopener noreferrer";
  meta.append(el("span", "lp-site", host), el("strong", "lp-title", title || url));
  c.append(stage, meta);
  return c;
}

async function build(url, onLayout) {
  const ext = extOf(url);
  if (["png", "jpg", "jpeg", "gif", "webp", "avif", "bmp"].includes(ext)) {
    const i = new Image(); i.className = "lp-img"; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; i.alt = "Linked image";
    i.addEventListener("load", () => onLayout && onLayout(i)); i.addEventListener("error", () => i.remove());
    i.src = url; return i;
  }
  if (["mp4", "webm", "mov", "m4v", "ogv"].includes(ext)) {
    const v = document.createElement("video"); v.className = "lp-img"; v.controls = true; v.preload = "metadata"; v.playsInline = true; v.src = url;
    v.addEventListener("loadedmetadata", () => onLayout && onLayout(v)); return v;
  }
  if (["mp3", "wav", "m4a", "aac", "flac", "opus"].includes(ext)) { const a = document.createElement("audio"); a.controls = true; a.preload = "none"; a.src = url; return a; }
  const yt = youtubeId(url);
  const meta = await fetchMeta(url);
  if (yt) return playerCard(url, `https://i.ytimg.com/vi/${yt}/hqdefault.jpg`, meta?.title, `https://www.youtube-nocookie.com/embed/${encodeURIComponent(yt)}?autoplay=1&rel=0`, "YouTube");
  const vm = vimeoId(url);
  if (vm) return playerCard(url, meta?.image, meta?.title, `https://player.vimeo.com/video/${vm}?autoplay=1`, "Vimeo");
  if (!meta || !(meta.title || meta.description || meta.image)) return null;
  if (meta.embed) return playerCard(url, meta.image, meta.title, meta.embed, meta.site || new URL(url).hostname);
  const a = el("a", "lp-card"); a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer";
  if (meta.image) { const i = new Image(); i.src = meta.image; i.alt = ""; i.loading = "lazy"; i.referrerPolicy = "no-referrer"; i.className = "lp-thumb"; i.addEventListener("load", () => onLayout && onLayout(i)); i.addEventListener("error", () => i.remove()); a.append(i); }
  const m = el("div", "lp-meta");
  m.append(el("span", "lp-site", meta.site || new URL(url).hostname));
  if (meta.title) m.append(el("strong", "lp-title", meta.title));
  if (meta.description) m.append(el("span", "lp-desc", meta.description));
  a.append(m);
  return a;
}

/** Adds preview cards under a text bubble. */
export function attachPreviews(bubble, text, { onLayout } = {}) {
  if (!previewsOn() || !text) return;
  const urls = [...new Set((String(text).match(URL_RE) || []).map(clean))].filter(u => { try { return /^https?:$/.test(new URL(u).protocol); } catch (_) { return false; } }).slice(0, MAX_PER_MESSAGE);
  if (!urls.length) return;
  const box = el("div", "lp-box");
  bubble.append(box);
  urls.forEach(u => build(u, onLayout).then(node => { if (node && bubble.isConnected !== false) { box.append(node); onLayout && onLayout(box); } }).catch(() => {}));
}
