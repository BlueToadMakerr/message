// Developer mode (Account → Developer). Off by default. When on, small "{ }" buttons appear (chat list, chat, message menu, call, account)
// that open raw, copyable information. Nothing else changes, so nothing gets in the way when it is off.
import { confirmDialog, copyText, toast } from "./ui.js";

const KEY = "qm-dev";
export const devOn = () => { try { return localStorage.getItem(KEY) === "1"; } catch (_) { return false; } };
const listeners = new Set();
function apply() { document.documentElement.classList.toggle("dev-on", devOn()); listeners.forEach(f => { try { f(devOn()); } catch (_) { /* ignore */ } }); }
export function setDev(on) { try { on ? localStorage.setItem(KEY, "1") : localStorage.removeItem(KEY); } catch (_) { /* ignore */ } apply(); }
export const onDev = fn => { listeners.add(fn); return () => listeners.delete(fn); };
apply();
addEventListener("storage", e => { if (e.key === KEY) apply(); });

/** JSON for display: long strings (data URLs, ciphertext, base64) are shortened, errors / maps / sets are readable. */
export function plain(v, max = 240) {
  const seen = new WeakSet();
  return JSON.stringify(v, (k, x) => {
    if (typeof x === "string" && x.length > max) return x.slice(0, max) + `… (${x.length} chars)`;
    if (x instanceof Map) return Object.fromEntries(x);
    if (x instanceof Set) return [...x];
    if (x instanceof Error) return { name: x.name, message: x.message };
    if (typeof x === "function") return "[function]";
    if (typeof x === "bigint") return String(x);
    if (x && typeof x === "object") { if (seen.has(x)) return "[circular]"; seen.add(x); }
    return x;
  }, 2);
}

/** A small button that exists only in developer mode. */
export function devButton(label, onclick, { title = "Developer info", cls = "" } = {}) {
  const b = document.createElement("button");
  b.type = "button"; b.className = "dev-btn " + cls; b.textContent = label; b.title = title; b.setAttribute("aria-label", title);
  b.addEventListener("click", e => { e.stopPropagation(); onclick(e); });
  return b;
}

/** Shows raw data in a dialog with a Copy button. `get` may be a function (re-read every `every` ms for live numbers). */
export async function showRaw(title, get, { every = 0 } = {}) {
  const data = () => { try { return typeof get === "function" ? get() : get; } catch (e) { return { error: String(e) }; } };
  const pre = document.createElement("pre"); pre.className = "dev-pre";
  const wrap = document.createElement("div"); wrap.className = "stack";
  const copy = document.createElement("button"); copy.type = "button"; copy.className = "btn small"; copy.textContent = "Copy all";
  let last = "";
  const paint = async () => { const d = await data(); last = typeof d === "string" ? d : plain(d); pre.textContent = last; };
  copy.onclick = async () => { try { await copyText(last); copy.textContent = "Copied ✓"; } catch (_) { copy.textContent = "Couldn't copy"; } setTimeout(() => { copy.textContent = "Copy all"; }, 1500); };
  wrap.append(copy, pre);
  await paint();
  const t = every ? setInterval(paint, every) : 0;
  try { await confirmDialog({ title, node: wrap, okText: "Close", hideCancel: true }); } finally { if (t) clearInterval(t); }
}

/** Handy facts about this page / device for every raw view. */
export function envInfo() {
  const nav = navigator, c = nav.connection || {};
  const res = (() => { try { const r = performance.getEntriesByType("resource"); const by = {}; let total = 0; for (const e of r) { const k = (e.initiatorType || "other"); by[k] = (by[k] || 0) + (e.transferSize || 0); total += e.transferSize || 0; } return { requests: r.length, transferredBytes: total, byType: by }; } catch (_) { return null; } })();
  let store = {}; try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); store[k] = (localStorage.getItem(k) || "").length; } } catch (_) { /* ignore */ }
  return {
    time: new Date().toISOString(), url: location.href, userAgent: nav.userAgent, language: nav.language, online: nav.onLine,
    app: !!window.QMApp, standalone: matchMedia("(display-mode: standalone)").matches,
    viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio }, network: { type: c.effectiveType, downlink: c.downlink, rtt: c.rtt, saveData: c.saveData },
    memoryMB: performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : undefined,
    loadedResources: res, localStorageBytesByKey: store,
    navigation: (() => { try { const n = performance.getEntriesByType("navigation")[0]; return n && { domContentLoadedMs: Math.round(n.domContentLoadedEventEnd), loadMs: Math.round(n.loadEventEnd) }; } catch (_) { return null; } })(),
  };
}
