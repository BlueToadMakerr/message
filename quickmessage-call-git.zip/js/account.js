import { toHome, toTop, QM, trackSplit, markReady } from "./embed.js";
import { auth, db } from "./firebase.js";
import {
  onAuthStateChanged, signOut, EmailAuthProvider, GoogleAuthProvider,
  reauthenticateWithCredential, reauthenticateWithPopup, updatePassword, deleteUser, sendPasswordResetEmail,
  linkWithPopup, linkWithCredential, unlink
} from "./sdk.js";
import { ref, get, update, remove } from "./sdk.js";
import {
  toast, confirmDialog, promptDialog, avatarEl, hydrateIcons, copyText, authErrorMessage
} from "./ui.js";
import { ensureProfile, invalidateProfile } from "./users.js";
import { applyTheme, getTheme } from "./theme.js";
import * as E2E from "./crypto.js";
import { previewsOn, setPreviews } from "./linkpreview.js";
import { refreshVerified, resendVerification } from "./verify.js";

hydrateIcons();
const $ = id => document.getElementById(id);

let user = null;

function renderHeader(name, pfp) {
  $("headAvatar").replaceChildren(avatarEl(name, pfp, "avatar-lg"));
  $("headName").textContent = name;
}

// Live theme preview while choosing (saved to the profile on "Save changes").
$("themeSelect").addEventListener("change", e => applyTheme(e.target.value));

// Live avatar preview
$("pfpUrl").addEventListener("input", () => {
  renderHeader($("displayName").value.trim() || user?.email || "?", $("pfpUrl").value.trim());
});

onAuthStateChanged(auth, async u => {
  if (!u) { toHome(); return; }
  user = u;

  let profile;
  try { profile = await ensureProfile(u); }
  catch (err) { console.error(err); toast("Couldn't load your profile.", "error"); profile = { displayName: u.displayName || "", pfp: "", theme: null }; }

  $("headEmail").textContent = u.email || "";
  $("uidText").textContent = u.uid;
  $("displayName").value = profile.displayName === "Unknown user" ? "" : profile.displayName;
  $("pfpUrl").value = profile.pfp || "";
  // Bug fix: the old page read an undefined `info.theme` here and crashed.
  const theme = profile.theme || getTheme();
  $("themeSelect").value = applyTheme(theme);
  renderHeader($("displayName").value || u.email || "?", profile.pfp);

  $("passwordSection").classList.toggle("hidden", !(u.providerData || []).some(p => p.providerId === "password"));
  $("loading").classList.add("hidden");
  $("content").classList.remove("hidden");
  if (window.QMApp) $("appCard").classList.remove("hidden");
  paintProviders();
  $("emailAddToggle").checked = profile.emailAdd !== false;
  $("previewToggle").checked = previewsOn();
  E2E.init(u.uid).then(() => { $("fpText").textContent = E2E.myFingerprint() || "not set up on this device"; }).catch(() => { $("fpText").textContent = "unavailable"; });
});

// ---------- email verification + sign-in methods ----------
const hasProvider = id => !!user && (user.providerData || []).some(p => p.providerId === id);
function paintProviders() {
  const list = $("providersList");
  list.replaceChildren();
  const add = t => { const d = document.createElement("div"); d.textContent = t; list.append(d); };
  if (hasProvider("password")) add("✓ Email & password");
  if (hasProvider("google.com")) add("✓ Google");
  $("linkGoogleBtn").classList.toggle("hidden", hasProvider("google.com"));
  $("showAddPwBtn").classList.toggle("hidden", hasProvider("password"));
  const vr = $("verifyRow");
  vr.replaceChildren();
  if (user.emailVerified) vr.textContent = "✓ Your email address is verified.";
  else {
    vr.append("Your email isn't verified yet. ");
    const a = document.createElement("button"); a.type = "button"; a.className = "btn small"; a.textContent = "Resend email";
    a.onclick = async () => { try { await resendVerification(); toast("Verification email sent.", "success"); } catch (_) { toast("Couldn't send the email right now.", "error"); } };
    const b = document.createElement("button"); b.type = "button"; b.className = "btn small primary"; b.textContent = "I've verified";
    b.onclick = async () => { if (await refreshVerified()) { paintProviders(); toast("Verified!", "success"); } else toast("Not verified yet.", "info"); };
    vr.append(a, " ", b);
  }
}

// Linking Google to an email account: Google must be the SAME email. A verified Google email also marks the account verified.
async function finishGoogleLink(cred) {
  const g = (cred.user || user).providerData.find(p => p.providerId === "google.com");
  if (!g || (g.email || "").toLowerCase() !== (user.email || "").toLowerCase()) {
    try { await unlink(user, "google.com"); } catch (_) { /* ignore */ }
    throw new Error("That Google account uses a different email address than this account.");
  }
  try {
    const r = await fetch("mark-verified.php", { method: "POST", body: new URLSearchParams({ idToken: await user.getIdToken(true) }) });
    if (!r.ok) console.warn("mark-verified", r.status);
  } catch (_) { /* best effort */ }
  await refreshVerified();
  paintProviders();
  toast("Google account linked. You can now sign in with Google.", "success");
}
$("linkGoogleBtn").onclick = async () => {
  try {
    if (window.QMApp && window.QMApp.googleSignIn) {
      // the app signs in through the browser; the shell hands the Google token to this callback instead of signing in
      window.top.__qmGoogleLink = async (idToken, err) => {
        if (!idToken) { toast(err ? "Google sign-in didn't finish." : "Cancelled.", "error"); return; }
        try { const c = await linkWithCredential(user, GoogleAuthProvider.credential(idToken)); await finishGoogleLink(c); }
        catch (e) { toast(authErrorMessage(e) || e.message, "error"); }
      };
      window.QMApp.googleSignIn();
      return;
    }
    await finishGoogleLink(await linkWithPopup(user, new GoogleAuthProvider()));
  } catch (e) { const m = authErrorMessage(e); toast(m || e.message || "Couldn't link Google.", "error"); }
};
$("showAddPwBtn").onclick = () => $("addPasswordBox").classList.toggle("hidden");
$("addPwBtn").onclick = async () => {
  const pw = $("newPw1").value;
  if (pw.length < 6) return toast("Use at least 6 characters.", "error");
  try {
    await linkWithCredential(user, EmailAuthProvider.credential(user.email, pw));
    $("newPw1").value = ""; $("addPasswordBox").classList.add("hidden");
    $("passwordSection").classList.remove("hidden");
    paintProviders();
    toast("Done. You can now sign in with your email and password.", "success");
  } catch (e) { const m = authErrorMessage(e); toast(m || "Couldn't add a password.", "error"); }
};

// ---------- privacy ----------
$("emailAddToggle").addEventListener("change", async e => {
  try { await update(ref(db, `accsettings/${user.uid}/settings`), { emailAdd: e.target.checked }); invalidateProfile(user.uid); toast(e.target.checked ? "People can add you by email." : "People need your UID to add you.", "success", 2500); }
  catch (_) { e.target.checked = !e.target.checked; toast("Couldn't save that.", "error"); }
});
$("previewToggle").addEventListener("change", e => { setPreviews(e.target.checked); toast(e.target.checked ? "Link previews on." : "Link previews off (reload chats to apply).", "success", 2500); });

// ---------- encryption ----------
$("showCodeBtn").onclick = async () => {
  const c = await E2E.savedCode(user.uid).catch(() => null);
  await confirmDialog({ title: "Your recovery code", message: c || "This device doesn't have the code stored (it was set up elsewhere).", okText: "Close", hideCancel: true });
};
$("newCodeBtn").onclick = async () => {
  if (!(await confirmDialog({ title: "Make a new recovery code?", message: "The old code stops working. Save the new one somewhere safe.", okText: "Make new code" }))) return;
  try { const c = await E2E.rotateCode(user.uid); await confirmDialog({ title: "Your new recovery code", message: c, okText: "I've saved it", hideCancel: true }); }
  catch (_) { toast("Couldn't change the code on this device (it needs your key).", "error"); }
};

// ---------- app: refresh cache ----------
$("refreshCacheBtn")?.addEventListener("click", async () => {
  const btn = $("refreshCacheBtn");
  btn.disabled = true; btn.textContent = "Refreshing…";
  try {
    if ("caches" in window) for (const k of await caches.keys()) await caches.delete(k);
    if (navigator.serviceWorker) for (const r of await navigator.serviceWorker.getRegistrations()) await r.unregister().catch(() => {});
  } catch (_) { /* best effort */ }
  try { window.QMApp && window.QMApp.clearCache && window.QMApp.clearCache(); } catch (_) { /* ignore */ }
  setTimeout(() => { try { (window.top || window).location.reload(); } catch (_) { location.reload(); } }, 400);
});

// ---------- save profile ----------
$("profileForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!user) return;
  const displayName = $("displayName").value.trim();
  const pfp = $("pfpUrl").value.trim();
  if (!displayName) return toast("Display name can't be empty.", "error");
  if (pfp && !/^https?:\/\//i.test(pfp)) return toast("Profile picture must be an http(s) link.", "error");

  const btn = $("saveSettingsBtn");
  btn.disabled = true;
  try {
    await update(ref(db, `accsettings/${user.uid}/settings`), { displayName, pfp, theme: $("themeSelect").value });
    invalidateProfile(user.uid);
    applyTheme($("themeSelect").value);
    renderHeader(displayName, pfp);
    toast("Profile saved.", "success");
  } catch (err) {
    console.error(err);
    toast("Couldn't save: " + (err.message || err), "error");
  } finally { btn.disabled = false; }
});

// ---------- password ----------
$("passwordForm").addEventListener("submit", async e => {
  e.preventDefault();
  const oldPass = $("oldPassword").value, newPass = $("newPassword").value;
  if (!oldPass || newPass.length < 6) return toast("Enter your current password and a new one (6+ characters).", "error");
  const btn = $("changePassBtn");
  btn.disabled = true;
  try {
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, oldPass));
    await updatePassword(user, newPass);
    $("oldPassword").value = $("newPassword").value = "";
    toast("Password updated.", "success");
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  } finally { btn.disabled = false; }
});

$("resetBtn").onclick = async () => {
  try {
    await sendPasswordResetEmail(auth, user.email);
    toast("Reset email sent to " + user.email, "success");
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  }
};

// ---------- logout ----------
$("logoutBtn").onclick = async () => {
  await signOut(auth);
  toTop("index.html");
};

// ---------- delete account ----------
async function reauthenticate() {
  const hasPassword = (user.providerData || []).some(p => p.providerId === "password");
  if (hasPassword) {
    const pass = await promptDialog({
      title: "Confirm it's you", message: "Enter your password to continue.",
      input: { type: "password", placeholder: "Password" }, okText: "Continue"
    });
    if (!pass) return false;
    await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, pass));
    return true;
  }
  await reauthenticateWithPopup(user, new GoogleAuthProvider());
  return true;
}

$("deleteBtn").onclick = async () => {
  const ok = await confirmDialog({
    title: "Delete your account?",
    message: "This permanently deletes your account and profile and removes you from all chats. This can't be undone.",
    okText: "Delete account", danger: true
  });
  if (!ok) return;

  try {
    // Re-authenticate first so the final deleteUser can't fail halfway through the cleanup.
    if (!(await reauthenticate())) return;

    const uid = user.uid;
    const chatIds = Object.keys((await get(ref(db, `chatList/${uid}`)).catch(() => null))?.val() || {});
    for (const chatId of chatIds) {
      try {
        const parts = (await get(ref(db, `privateChats/${chatId}/participants`))).val() || {};
        if (Object.keys(parts).filter(p => p !== uid).length === 0) {
          await remove(ref(db, `privateChats/${chatId}`));
        } else {
          await update(ref(db), {
            [`privateChats/${chatId}/participants/${uid}`]: null,
            [`privateChats/${chatId}/messageRead/${uid}`]: null,
            [`privateChats/${chatId}/typing/${uid}`]: null
          });
        }
      } catch (err) { console.warn("Couldn't clean up chat", chatId, err); }
    }
    await Promise.allSettled([
      remove(ref(db, `chatList/${uid}`)),
      remove(ref(db, `FCM/${uid}`)),
      remove(ref(db, `userKeys/${uid}`)),
      remove(ref(db, `accsettings/${uid}`))
    ]);
    await deleteUser(user);
    toast("Account deleted.");
    setTimeout(() => toHome(), 800);
  } catch (err) {
    const m = authErrorMessage(err); if (m) toast(m, "error");
  }
};

trackSplit();
if (QM) document.querySelector('a[aria-label="Back to chats"]')?.addEventListener("click", e => { e.preventDefault(); QM.closeDetail(); });

markReady();   // tells the app shell this frame booted (see frame watchdog in shell.js)
