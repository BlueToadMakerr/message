<?php
// Link previews: POST url, idToken → {title, description, image, site, embed?}. Only public web pages; good previews are cached in linkPreviews/{id} (see lp_store).
declare(strict_types=1);
require __DIR__ . '/lib.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') qm_out(405, ['error' => 'Use POST']);
$config = require __DIR__ . '/config.php';
$caller = qm_caller($config, (string)($_POST['idToken'] ?? ''));
qm_rate('lp:' . $caller['uid'], 90, 600);
$url = trim((string)($_POST['url'] ?? ''));
if (!preg_match('#^https?://[^\s]{4,2000}$#i', $url)) qm_out(400, ['error' => 'Bad link']);

$private = ($_POST['private'] ?? '') === '1';      // links from encrypted chats are never stored on the server
$id = substr(hash('sha256', $url), 0, 32);          // same id the app computes, to look the preview up in the database first

/** Stores a good preview in the shared cache (linkPreviews/{id}); the app reads it from there for a week before asking again. */
function lp_store(string $id, string $url, array $out): void {
    global $private;
    if ($private || !$out) return;
    try {
        $config = require __DIR__ . '/config.php';
        $sa = require __DIR__ . '/secrets.php';
        $tok = qm_service_token($sa, 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email');
        if (!$tok) return;
        qm_http('PUT', rtrim($config['database_url'], '/') . '/linkPreviews/' . $id . '.json', ['Authorization: Bearer ' . $tok],
            json_encode(['u' => $url, 'd' => $out, 't' => (int)round(microtime(true) * 1000)], JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) { /* the cache is best effort */ }
}

// YouTube: the page itself is huge and mostly script; its oEmbed answer is tiny and has the video's name and channel.
$h0 = strtolower((string)parse_url($url, PHP_URL_HOST));
$h0 = preg_replace('/^(www\.|m\.)/', '', $h0);
if (in_array($h0, ['youtube.com', 'music.youtube.com', 'youtu.be'], true)) {
    $o = qm_safe_fetch('https://www.youtube.com/oembed?format=json&url=' . rawurlencode($url), 60000, 2);
    $j = $o ? json_decode($o['body'], true) : null;
    if (is_array($j) && !empty($j['title'])) {
        $out = array_filter([
            'title' => mb_substr((string)$j['title'], 0, 160), 'creator' => mb_substr((string)($j['author_name'] ?? ''), 0, 80),
            'image' => (string)($j['thumbnail_url'] ?? ''), 'site' => 'YouTube',
        ], fn($v) => $v !== '');
        lp_store($id, $url, $out);
        qm_out(200, $out);
    }
    qm_out(200, []);       // unknown / removed video: no preview (and nothing cached)
}

$res = qm_safe_fetch($url, 700000, 4, true);
if (!$res || !str_contains($res['type'], 'html')) qm_out(200, []);
$html = $res['body'];
// charset → UTF-8
$cs = 'UTF-8';
if (preg_match('/charset=([\w-]+)/i', $res['type'], $m) || preg_match('/<meta[^>]+charset=["\']?([\w-]+)/i', substr($html, 0, 4096), $m)) $cs = $m[1];
if (strcasecmp($cs, 'utf-8') !== 0 && @mb_list_encodings() && in_array(strtolower($cs), array_map('strtolower', mb_list_encodings()), true)) $html = mb_convert_encoding($html, 'UTF-8', $cs);
$doc = new DOMDocument();
libxml_use_internal_errors(true);
@$doc->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR);
libxml_clear_errors();
$meta = [];
foreach ($doc->getElementsByTagName('meta') as $mt) {
    $k = strtolower($mt->getAttribute('property') ?: $mt->getAttribute('name'));
    $v = trim($mt->getAttribute('content'));
    if ($k !== '' && $v !== '' && !isset($meta[$k])) $meta[$k] = $v;
}
$title = $meta['og:title'] ?? $meta['twitter:title'] ?? '';
if ($title === '') { $t = $doc->getElementsByTagName('title')->item(0); if ($t) $title = trim($t->textContent); }
$desc = $meta['og:description'] ?? $meta['twitter:description'] ?? $meta['description'] ?? '';
$image = $meta['og:image:secure_url'] ?? $meta['og:image'] ?? $meta['twitter:image'] ?? '';
$site = $meta['og:site_name'] ?? (parse_url($res['url'], PHP_URL_HOST) ?: '');
$abs = function (string $u) use ($res): string {
    if ($u === '') return '';
    if (preg_match('#^https?://#i', $u)) return $u;
    $p = parse_url($res['url']);
    $base = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    if (str_starts_with($u, '//')) return $p['scheme'] . ':' . $u;
    return $u[0] === '/' ? $base . $u : $base . rtrim(dirname($p['path'] ?? '/'), '/') . '/' . $u;
};
$image = $abs($image);
if (!preg_match('#^https?://#i', $image)) $image = '';

// embeddable players: only from sites known to allow it
$embed = '';
$cand = $meta['og:video:secure_url'] ?? $meta['og:video:url'] ?? $meta['twitter:player'] ?? '';
$cand = $abs($cand);
$allowed = '#^https://(www\.youtube(-nocookie)?\.com/embed/|player\.vimeo\.com/video/|open\.spotify\.com/embed/|w\.soundcloud\.com/player/|streamable\.com/e/|www\.dailymotion\.com/embed/|www\.loom\.com/embed/)#i';
if ($cand !== '' && preg_match($allowed, $cand)) $embed = $cand;
$host = strtolower(parse_url($res['url'], PHP_URL_HOST) ?: '');
if ($embed === '') {
    $path = parse_url($res['url'], PHP_URL_PATH) ?: '';
    if (str_ends_with($host, 'open.spotify.com') && preg_match('#^/(track|album|playlist|episode|show)/(\w+)#', $path, $m)) $embed = "https://open.spotify.com/embed/{$m[1]}/{$m[2]}";
    elseif ($host === 'streamable.com' && preg_match('#^/(\w+)$#', $path, $m)) $embed = "https://streamable.com/e/{$m[1]}";
    elseif (str_ends_with($host, 'loom.com') && preg_match('#^/share/(\w+)#', $path, $m)) $embed = "https://www.loom.com/embed/{$m[1]}";
}
$out = array_filter([
    'title' => mb_substr(html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, 160),
    'description' => mb_substr(html_entity_decode($desc, ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, 300),
    'image' => $image, 'site' => mb_substr($site, 0, 60), 'embed' => $embed,
], fn($v) => $v !== '');
if (!($out['title'] ?? '') && !($out['description'] ?? '') && !($out['image'] ?? '')) qm_out(200, []);   // nothing to show: don't keep it
lp_store($id, $url, $out);
qm_out(200, $out);
