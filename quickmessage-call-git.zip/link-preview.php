<?php
// Link previews: POST url, idToken → {title, description, image, site, embed?}. Only public web pages; nothing is stored beyond a 1-hour cache.
declare(strict_types=1);
require __DIR__ . '/lib.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') qm_out(405, ['error' => 'Use POST']);
$config = require __DIR__ . '/config.php';
$caller = qm_caller($config, (string)($_POST['idToken'] ?? ''));
qm_rate('lp:' . $caller['uid'], 90, 600);
$url = trim((string)($_POST['url'] ?? ''));
if (!preg_match('#^https?://[^\s]{4,2000}$#i', $url)) qm_out(400, ['error' => 'Bad link']);

$cache = sys_get_temp_dir() . '/qm_lp_' . md5($url) . '.json';
if (is_readable($cache) && filemtime($cache) > time() - 3600) { $c = json_decode((string)@file_get_contents($cache), true); if (is_array($c)) qm_out(200, $c); }

$res = qm_safe_fetch($url);
if (!$res || !str_contains($res['type'], 'html')) qm_out(200, []);
$html = $res['body'];
// charset → UTF-8
$cs = 'UTF-8';
if (preg_match('/charset=([\w-]+)/i', $res['type'], $m) || preg_match('/<meta[^>]+charset=["\']?([\w-]+)/i', substr($html, 0, 4096), $m)) $cs = $m[1];
if (strcasecmp($cs, 'utf-8') !== 0 && @mb_list_encodings() && in_array(strtolower($cs), array_map('strtolower', mb_list_encodings()), true)) $html = mb_convert_encoding($html, 'UTF-8', $cs);
$doc = new DOMDocument();
libxml_use_internal_errors(true);
@$doc->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR);
libxml_clear_errors();
$meta = [];
foreach ($doc->getElementsByTagName('meta') as $mt) {
    $k = strtolower($mt->getAttribute('property') ?: $mt->getAttribute('name'));
    $v = trim($mt->getAttribute('content'));
    if ($k !== '' && $v !== '' && !isset($meta[$k])) $meta[$k] = $v;
}
$title = $meta['og:title'] ?? $meta['twitter:title'] ?? '';
if ($title === '') { $t = $doc->getElementsByTagName('title')->item(0); if ($t) $title = trim($t->textContent); }
$desc = $meta['og:description'] ?? $meta['twitter:description'] ?? $meta['description'] ?? '';
$image = $meta['og:image:secure_url'] ?? $meta['og:image'] ?? $meta['twitter:image'] ?? '';
$site = $meta['og:site_name'] ?? (parse_url($res['url'], PHP_URL_HOST) ?: '');
$abs = function (string $u) use ($res): string {
    if ($u === '') return '';
    if (preg_match('#^https?://#i', $u)) return $u;
    $p = parse_url($res['url']);
    $base = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    if (str_starts_with($u, '//')) return $p['scheme'] . ':' . $u;
    return $u[0] === '/' ? $base . $u : $base . rtrim(dirname($p['path'] ?? '/'), '/') . '/' . $u;
};
$image = $abs($image);
if (!preg_match('#^https?://#i', $image)) $image = '';

// embeddable players: only from sites known to allow it
$embed = '';
$cand = $meta['og:video:secure_url'] ?? $meta['og:video:url'] ?? $meta['twitter:player'] ?? '';
$cand = $abs($cand);
$allowed = '#^https://(www\.youtube(-nocookie)?\.com/embed/|player\.vimeo\.com/video/|open\.spotify\.com/embed/|w\.soundcloud\.com/player/|streamable\.com/e/|www\.dailymotion\.com/embed/|www\.loom\.com/embed/)#i';
if ($cand !== '' && preg_match($allowed, $cand)) $embed = $cand;
$host = strtolower(parse_url($res['url'], PHP_URL_HOST) ?: '');
if ($embed === '') {
    $path = parse_url($res['url'], PHP_URL_PATH) ?: '';
    if (str_ends_with($host, 'open.spotify.com') && preg_match('#^/(track|album|playlist|episode|show)/(\w+)#', $path, $m)) $embed = "https://open.spotify.com/embed/{$m[1]}/{$m[2]}";
    elseif ($host === 'streamable.com' && preg_match('#^/(\w+)$#', $path, $m)) $embed = "https://streamable.com/e/{$m[1]}";
    elseif (str_ends_with($host, 'loom.com') && preg_match('#^/share/(\w+)#', $path, $m)) $embed = "https://www.loom.com/embed/{$m[1]}";
}
$out = array_filter([
    'title' => mb_substr(html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, 160),
    'description' => mb_substr(html_entity_decode($desc, ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, 300),
    'image' => $image, 'site' => mb_substr($site, 0, 60), 'embed' => $embed,
], fn($v) => $v !== '');
@file_put_contents($cache, json_encode($out, JSON_UNESCAPED_UNICODE), LOCK_EX);
qm_out(200, $out);
