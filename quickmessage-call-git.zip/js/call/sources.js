// Sources — decides where the call's microphone / camera / screen come from: this device, the paired Android phone, or off.
// It owns the CompanionLink and the "Phone" panel. The phone's *reported* state (state.media) is the single source of
// truth: the panel only sends commands, and the real change happens when the phone confirms it.
import { watchCompanions } from "../companion.js";
import { CompanionLink, PHONE } from "./companion.js";
import { icon } from "../ui.js";

const INTENT_MS = 8000;

export class Sources {
  /**
   * @param {object} o
   * @param {string} o.uid
   * @param {()=>import("./media.js").LocalMedia} o.getMedia
   * @param {(track:MediaStreamTrack|null)=>void} o.setPhoneScreen   publish/clear the phone's screen as an extra shared screen
   * @param {()=>boolean} o.localScreenOn
   * @param {()=>void} o.toggleLocalScreen
   * @param {(msg:string, kind?:string)=>void} o.notify
   * @param {()=>void} o.onChange                                   dock / panel should repaint
   */
  constructor(o) {
    Object.assign(this, o);
    this.devices = [];
    this.link = null;
    this.intent = {};          // slot -> { want:"on"|"off"|"local", at }
    this._screenPub = false;
    this.host = null;
    this.stopWatch = watchCompanions(this.uid, list => { this.devices = list; this._changed(); });
    this.getMedia().onExternal = (slot, on) => this.onExternal(slot, on);
  }

  get hasDevices() { return this.devices.length > 0; }
  get live() { return !!this.link && this.link.status === PHONE.LIVE; }
  get active() { return !!this.link && [PHONE.REQUESTING, PHONE.CONNECTING, PHONE.LIVE].includes(this.link.status); }
  camIsPhone() { const m = this.getMedia(); return !!m && m.camSource === "phone" && m.camOn; }

  _changed() { this.onChange(); if (this.host) this.render(this.host); }

  // ------------------------------------------------------------------ connect / disconnect
  async connect(dev) {
    if (this.link) await this.disconnect(true);
    const link = (this.link = new CompanionLink({ uid: this.uid, deviceId: dev.deviceId, name: dev.name || "Phone", onChange: () => this._linkChanged(link) }));
    this._changed();
    try { await link.start({}); }
    catch (err) {
      console.error(err);
      this.notify("Couldn't reach your phone.", "error");
      await this.disconnect(true);
    }
  }

  /** User pressed Disconnect, or the call ended. Also tells the phone, which stops capturing and drops its notification. */
  async disconnect(silent = false) {
    const link = this.link;
    if (!link) return;
    this.link = null;
    this._fallback();
    this.intent = {};
    await link.disconnect().catch(() => {});
    if (!silent) this.notify("Phone disconnected.", "info");
    this._changed();
  }

  destroy() {
    this.stopWatch?.();
    const link = this.link;
    this.link = null;
    this._screenPub = false;                       // (the call is ending: no need to reopen this device's mic/camera)
    link?.disconnect().catch(() => {});
    this.host = null;
  }

  /** Phone gone (it hung up, was declined, or the link failed): take everything back to this device. */
  _fallback() {
    const m = this.getMedia();
    if (m) {
      if (m.micSource === "phone") m.useMicSource("local", null).catch(() => {});      // stays muted: never surprise-open a mic
      if (m.camSource === "phone") m.phoneCamOff();
    }
    if (this._screenPub) { this._screenPub = false; this.setPhoneScreen(null); }
  }

  // ------------------------------------------------------------------ phone → website
  _gate(slot, actual) {
    const i = this.intent[slot];
    if (!i) return false;
    if (Date.now() - i.at > INTENT_MS) { delete this.intent[slot]; return false; }
    if (actual === (i.want === "on")) { delete this.intent[slot]; return false; }
    return true;                                   // we asked for something else and the phone hasn't caught up yet
  }

  _linkChanged(link) {
    if (link !== this.link) return;
    const m = this.getMedia();
    if (link.status === PHONE.DECLINED) { this.notify("The phone declined the connection.", "error"); this.disconnect(true); return; }
    if (link.status === PHONE.ENDED) { this.notify(`${link.name} disconnected.`, "info"); this.disconnect(true); return; }
    if (link.status === PHONE.ERROR) { this.notify(link.error || "Phone connection failed.", "error"); this.disconnect(true); return; }
    if (m && (link.status === PHONE.LIVE || link.status === PHONE.CONNECTING)) {
      const md = link.media;
      if (!this._gate("mic", md.microphone)) {
        if (md.microphone) { if (m.micSource !== "phone") m.useMicSource("phone", link.tracks.mic).catch(() => {}); else if (!m.micOn) m.setMicOn(true); }
        else if (m.micSource === "phone" && m.micOn) m.setMicOn(false);
      }
      if (!this._gate("cam", md.camera)) {
        if (md.camera) { if (m.camSource !== "phone" || !m.camOn) m.useCamSource("phone", link.tracks.cam).catch(() => {}); }
        else if (m.camSource === "phone") m.phoneCamOff();
      }
      if (!this._gate("screen", md.screen) && md.screen !== this._screenPub) {
        this._screenPub = md.screen;
        this.setPhoneScreen(md.screen ? link.tracks.screen : null);
      }
    }
    this._changed();
  }

  /** The dock's mute button was used while the phone is the microphone. */
  onExternal(slot, on) {
    if (slot !== "mic" || !this.link) return;
    this.intent.mic = { want: on ? "on" : "off", at: Date.now() };
    this.link.setMicrophone(on).catch(() => this.notify("Couldn't reach your phone.", "error"));
  }

  // ------------------------------------------------------------------ website → phone
  micMode() { const m = this.getMedia(); const i = this.intent.mic; if (i) return i.want === "on" ? "phone" : i.want; return !m.micOn ? "off" : m.micSource === "phone" ? "phone" : "local"; }
  camMode() { const m = this.getMedia(); const i = this.intent.cam; if (i) return i.want === "on" ? "phone" : i.want; return !m.camOn ? "off" : m.camSource === "phone" ? "phone" : "local"; }

  async setMic(mode) {
    const m = this.getMedia(), L = this.link;
    if (!L || !this.live) return;
    try {
      if (mode === "phone") { this.intent.mic = { want: "on", at: Date.now() }; await L.setMicrophone(true); }
      else if (mode === "local") { this.intent.mic = { want: "local", at: Date.now() }; await L.setMicrophone(false); await m.useMicSource("local", null, { unmute: true }); }
      else { this.intent.mic = { want: "off", at: Date.now() }; if (m.micSource === "phone") await L.setMicrophone(false); m.setMicOn(false); }
    } catch (err) { console.error(err); this.notify("Couldn't change the microphone.", "error"); delete this.intent.mic; }
    this._changed();
  }

  async setCam(mode) {
    const m = this.getMedia(), L = this.link;
    if (!L || !this.live) return;
    try {
      if (mode === "phone") { this.intent.cam = { want: "on", at: Date.now() }; await L.setCamera(true); }
      else if (mode === "local") { this.intent.cam = { want: "local", at: Date.now() }; await L.setCamera(false); await m.useCamSource("local"); }
      else {
        this.intent.cam = { want: "off", at: Date.now() };
        if (m.camSource === "phone") { await L.setCamera(false); m.phoneCamOff(); }
        else if (m.camOn) await m.toggleCam();
        else await L.setCamera(false);
      }
    } catch (err) {
      console.error(err);
      this.notify(err && err.name === "NotAllowedError" ? "Camera is blocked in your browser settings." : "Couldn't change the camera.", "error");
      delete this.intent.cam;
    }
    this._changed();
  }

  async togglePhoneScreen() {
    const L = this.link;
    if (!L || !this.live) return;
    const on = !(this.intent.screen ? this.intent.screen.want === "on" : L.media.screen);
    this.intent.screen = { want: on ? "on" : "off", at: Date.now() };
    try { await L.setScreen(on); } catch (_) { this.notify("Couldn't reach your phone.", "error"); delete this.intent.screen; }
    if (!on && this._screenPub) { this._screenPub = false; this.setPhoneScreen(null); }
    this._changed();
  }

  switchPhoneCamera() { this.link?.switchCamera().catch(() => this.notify("Couldn't reach your phone.", "error")); }

  // ------------------------------------------------------------------ the Phone panel
  render(host) {
    this.host = host;
    const L = this.link, m = this.getMedia();
    host.replaceChildren();
    const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const btn = (label, cls, fn, opts = {}) => { const b = el("button", cls, label); b.type = "button"; if (opts.disabled) b.disabled = true; if ("pressed" in opts) b.setAttribute("aria-pressed", String(opts.pressed)); b.onclick = fn; return b; };

    if (!L) {
      if (!this.devices.length) { host.append(el("p", "hint", "No phone is paired yet. On the website open Account → Android companion.")); return; }
      const anyOnline = this.devices.some(d => d.online);
      for (const d of this.devices) {
        const row = el("div", "person");
        const r = el("div", "person-row");
        const info = el("div", "info");
        info.append(el("strong", "", d.name || "Android phone"));
        const stat = el("div", "stat", d.online ? "Online" : "Offline");
        if (d.online) stat.classList.add("ok");
        info.append(stat);
        r.append(info, btn("Use in this call", "btn primary", () => this.connect(d), { disabled: !d.online }));
        row.append(r);
        host.append(row);
      }
      if (!anyOnline) host.append(el("p", "hint", "Your phone shows as offline. Open the Companion app once; it keeps itself connected in the background."));
      return;
    }

    const head = el("div", "phone-head");
    head.append(el("strong", "", L.name));
    const st = L.status === PHONE.LIVE ? "Connected" : L.status === PHONE.CONNECTING ? "Connecting…" : (L.phoneStatus === "ringing" ? "Waiting for you to tap Connect on the phone…" : "Asking your phone…");
    head.append(el("div", "stat" + (L.status === PHONE.LIVE ? " ok" : ""), st));
    host.append(head);

    if (L.status !== PHONE.LIVE) {
      host.append(el("p", "hint", "A notification is on its way to the phone. Tap Connect there to allow the camera and microphone."));
      host.append(btn("Cancel", "btn", () => this.disconnect()));
      return;
    }

    const seg = (title, options, current, onPick, extra) => {
      const box = el("div", "phone-sec");
      box.append(el("div", "phone-lbl", title));
      const row = el("div", "phone-seg");
      for (const [val, label] of options) row.append(btn(label, "seg", () => onPick(val), { pressed: current === val }));
      box.append(row);
      if (extra) box.append(extra);
      host.append(box);
    };
    seg("Microphone", [["local", "This device"], ["phone", "Phone"], ["off", "Off"]], this.micMode(), v => this.setMic(v));
    const sw = this.camMode() === "phone" ? btn("Flip phone camera" + (L.facing ? ` (${L.facing})` : ""), "btn", () => this.switchPhoneCamera()) : null;
    seg("Camera", [["local", "This device"], ["phone", "Phone"], ["off", "Off"]], this.camMode(), v => this.setCam(v), sw);

    const sc = el("div", "phone-sec");
    sc.append(el("div", "phone-lbl", "Share screen (both at once is fine)"));
    const srow = el("div", "phone-seg");
    srow.append(btn("This device", "seg", () => this.toggleLocalScreen(), { pressed: this.localScreenOn() }));
    const pOn = this.intent.screen ? this.intent.screen.want === "on" : L.media.screen;
    srow.append(btn("Phone", "seg", () => this.togglePhoneScreen(), { pressed: pOn }));
    sc.append(srow);
    host.append(sc);
    if (L.lastError) host.append(el("p", "hint warn", L.lastError));
    host.append(btn("Disconnect phone", "btn danger", () => this.disconnect()));
  }
}
