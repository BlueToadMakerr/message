package app.quickmessage.chat

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Native notifications, independent of the page being open (a WebView can't receive web push reliably):
 *   - incoming calls: a full-screen alert (callRings/{you}) that opens the app on the call
 *   - new messages: a notification per chat (privateChats/{chat}/lastMessage), only while the app isn't on screen
 * It talks to the database directly with the signed-in account's token, handed over by the website (js/app-bridge.js).
 */
class NotifyService : Service() {
    companion object {
        private const val CH_RUN = "run"
        private const val CH_MSG = "messages"
        private const val CH_CALL = "calls"
        private const val ID_FG = 1
        private const val MAX_CHATS = 40

        @Volatile var inCall = false

        /** Tells the service a call is up, so it can hold the camera/microphone foreground types (Android blocks background capture otherwise). */
        fun setCall(ctx: Context, on: Boolean) {
            inCall = on
            val i = Intent(ctx, NotifyService::class.java).putExtra("call", on)
            try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {}
        }

        fun start(ctx: Context) {
            val st = Store(ctx)
            if (!st.signedIn || (!st.notify && !inCall)) return
            val i = Intent(ctx, NotifyService::class.java)
            try { if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i) } catch (_: Exception) {}
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, NotifyService::class.java)); cancelAll(ctx) }
        fun cancelAll(ctx: Context) { (ctx.getSystemService(NOTIFICATION_SERVICE) as NotificationManager).let { nm -> nm.cancelAll(); } }
    }

    @Volatile private var running = false
    private lateinit var store: Store
    private lateinit var fb: Firebase
    private val names = ConcurrentHashMap<String, String>()
    private val chatThreads = ConcurrentHashMap<String, Thread>()
    private val seenRings = HashSet<String>()

    override fun onBind(i: Intent?): IBinder? = null
    private fun nm() = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        store = Store(this)
        if (intent?.hasExtra("call") == true) inCall = intent.getBooleanExtra("call", false)
        if (!store.signedIn && !inCall) { stopSelf(); return START_NOT_STICKY }
        fb = Firebase(store)
        foreground()
        if (!inCall && !store.notify) { running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        if (!running && store.signedIn) {
            running = true
            Thread({ ringsLoop() }, "rings").start()
            Thread({ chatsLoop() }, "chats").start()
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; chatThreads.values.forEach { it.interrupt() }; chatThreads.clear(); super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun builder(ch: String) = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)

    private fun foreground() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel(CH_RUN, "Running in background", NotificationManager.IMPORTANCE_MIN))
            nm().createNotificationChannel(NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH))
            nm().createNotificationChannel(NotificationChannel(CH_CALL, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC; enableVibration(true) })
        }
        val n = builder(CH_RUN).setContentTitle("QuickMessage").setContentText(if (inCall) "In a call" else "Listening for messages and calls")
            .setSmallIcon(android.R.drawable.stat_notify_chat).setOngoing(true).setContentIntent(open(null, false, 0)).build()
        if (Build.VERSION.SDK_INT >= 34) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (inCall) {   // keep the call's microphone/camera alive while the app is in the background
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            try { startForeground(ID_FG, n, t) } catch (e: Exception) { startForeground(ID_FG, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) }
        } else startForeground(ID_FG, n)
    }

    private fun open(chat: String?, ring: Boolean, req: Int): PendingIntent {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (chat != null) i.putExtra(MainActivity.EXTRA_CHAT, chat)
        if (ring) i.putExtra(MainActivity.EXTRA_RING, true)
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun nameOf(uid: String): String = names.getOrPut(uid) {
        try { (fb.get("accsettings/$uid/settings/displayName") as? String)?.takeIf { it.isNotBlank() } ?: "Someone" } catch (_: Exception) { "Someone" }
    }

    private fun nap(ms: Long): Boolean = try { Thread.sleep(ms); true } catch (_: InterruptedException) { false }

    /** Runs [body] again (with a growing pause) whenever the stream ends or fails; stops when the service stops or we sign out. */
    private fun forever(body: () -> Unit) {
        var backoff = 2000L
        while (running && store.signedIn && store.notify) {
            try { body(); backoff = 2000L }
            catch (e: ApiException) { if (e.code == 401 || e.code == 403) backoff = 60_000L }
            catch (_: Exception) {}
            if (!nap(backoff)) return
            backoff = (backoff * 2).coerceAtMost(60_000L)
        }
    }

    // ------------------------------------------------------------------ incoming calls
    private fun ringsLoop() = forever {
        val me = store.uid ?: return@forever
        fb.stream("callRings/$me", { running }) { _, path, data ->
            val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
            when {
                parts.isEmpty() && data is JSONObject -> data.keys().forEach { k -> data.optJSONObject(k)?.let { ring(k, it) } }
                parts.size == 1 && data is JSONObject -> ring(parts[0], data)
                parts.size == 1 && data == null -> nm().cancel(("ring" + parts[0]).hashCode())
            }
        }
    }

    private fun ring(chatId: String, r: JSONObject) {
        if (!store.notify) return
        val me = store.uid ?: return
        val id = r.optString("ringId"); val from = r.optString("fromUid")
        if (id.isEmpty() || from == me || !seenRings.add(id)) return
        if (System.currentTimeMillis() - r.optLong("createdAt", 0) > 90_000) return     // an old ring left behind
        if (MainActivity.visible) return                                                // the page shows its own call overlay
        val who = nameOf(from)
        val pi = open(chatId, true, ("ring$chatId").hashCode())
        val n = builder(CH_CALL).setContentTitle("Incoming call").setContentText("$who is calling you")
            .setSmallIcon(android.R.drawable.sym_action_call).setCategory(Notification.CATEGORY_CALL).setPriority(Notification.PRIORITY_MAX)
            .setOngoing(true).setAutoCancel(true).setContentIntent(pi).setFullScreenIntent(pi, true).setTimeoutAfter(45_000).build()
        nm().notify(("ring$chatId").hashCode(), n)
    }

    // ------------------------------------------------------------------ messages
    private fun chatsLoop() = forever {
        val me = store.uid ?: return@forever
        fb.stream("chatList/$me", { running }) { _, path, data ->
            val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
            when {
                parts.isEmpty() && data is JSONObject -> data.keys().forEach { watchChat(it) }
                parts.size == 1 && data != null -> watchChat(parts[0])
            }
        }
    }

    private fun watchChat(chatId: String) {
        if (chatThreads.size >= MAX_CHATS || chatThreads.containsKey(chatId)) return
        val t = Thread({
            var baseline: String? = null
            forever {
                fb.stream("privateChats/$chatId/lastMessage", { running }) { _, path, data ->
                    if (path != "/" || data !is JSONObject) return@stream
                    val id = data.optString("id")
                    if (baseline == null) { baseline = id; return@stream }
                    if (id == baseline) return@stream
                    baseline = id
                    message(chatId, data)
                }
            }
        }, "chat-$chatId")
        chatThreads[chatId] = t
        t.start()
    }

    private fun message(chatId: String, m: JSONObject) {
        if (!store.notify) return
        val me = store.uid ?: return
        val from = m.optString("fromUid")
        if (from == me || MainActivity.visible) return
        val text = m.optString("text").ifBlank { "Sent an attachment" }
        var title = nameOf(from)
        try {
            val chatName = fb.get("privateChats/$chatId/chatData/name") as? String
            if (!chatName.isNullOrBlank()) title = "$title · $chatName"
        } catch (_: Exception) {}
        val n = builder(CH_MSG).setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.stat_notify_chat).setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE)
            .setContentIntent(open(chatId, false, chatId.hashCode())).build()
        nm().notify(chatId.hashCode(), n)
    }
}
