package app.quickmessage.chat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.*
import android.widget.FrameLayout
import android.app.PictureInPictureParams
import android.media.AudioManager
import android.util.Rational
import org.json.JSONObject

/**
 * QuickMessage as an app: the website runs in a WebView and the app adds what a WebView can't do by itself, through the
 * `QMApp` bridge (see js/app-bridge.js, js/bars.js, js/call/media.js):
 *   - screen sharing (captured natively, streamed into the page)
 *   - notifications for messages and full-screen incoming-call alerts (NotifyService)
 *   - status / navigation bars that follow the site's background colour
 *   - clearing the cache from Account → App
 */
class MainActivity : Activity() {
    companion object {
        @Volatile var visible = false
        @Volatile var instance: MainActivity? = null
        const val EXTRA_CHAT = "chatId"
        const val EXTRA_RING = "ring"
        private const val REQ_PERMS = 1
        private const val REQ_FILE = 2
        private const val REQ_PROJECTION = 3
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var pendingWebPerm: PermissionRequest? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var barColor = Color.WHITE
    private var loaded = false
    @Volatile private var inCall = false
    @Volatile private var callVisible = false
    @Volatile private var pip = false
    @Volatile private var ins = intArrayOf(0, 0, 0, 0)     // top, bottom, left, right in dp
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        instance = this
        root = FrameLayout(this).apply { setBackgroundColor(barColor) }
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        // Edge to edge: the page draws under the status and navigation bars and keeps clear of them itself (--sat/--sab, see js/bars.js),
        // so the bars simply show the site's background.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        else run { window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val d = resources.displayMetrics.density
            var top: Int; var bottom: Int; var left: Int; var right: Int; var ime = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                ime = insets.getInsets(WindowInsets.Type.ime()).bottom
                top = bars.top; bottom = bars.bottom; left = bars.left; right = bars.right
            } else run {
                top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom; left = insets.systemWindowInsetLeft; right = insets.systemWindowInsetRight
            }
            // with the keyboard up, shrink the page to sit above it (and report no bottom inset: the keyboard covers that area)
            v.setPadding(0, 0, 0, if (ime > bottom) ime else 0)
            val bDp = if (ime > bottom) 0 else bottom
            ins = intArrayOf(Math.round(top / d), Math.round(bDp / d), Math.round(left / d), Math.round(right / d))
            insets
        }
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            @Suppress("DEPRECATION") databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = true
            setSupportMultipleWindows(false)
            userAgentString = userAgentString + " QuickMessageApp/1"
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.isLongClickable = false; web.setOnLongClickListener { true }; web.isHapticFeedbackEnabled = false
        web.addJavascriptInterface(Bridge(), "QMApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val site = Uri.parse(Config.SITE_URL)
                if (u.host == site.host || u.scheme == "blob" || u.scheme == "about" || u.scheme == "file") return false
                if (u.scheme == "quickmessage") { handleAuth(u); return true }
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
            override fun onPageFinished(v: WebView, url: String?) { loaded = true }
            // Network errors show the same offline page the website uses (assets/offline.html), with the net:: code.
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (!r.isForMainFrame || r.url.scheme == "file") return
                val code = (e.description?.toString() ?: "").removePrefix("net::")
                val u = Uri.encode(r.url.toString())
                v.loadUrl("file:///android_asset/offline.html?code=" + Uri.encode(code) + "&url=" + u)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
                web.visibility = View.INVISIBLE
                immersive(true)
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null; customCb?.onCustomViewHidden(); customCb = null
                web.visibility = View.VISIBLE
                immersive(false)
            }
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { askWebPermission(r) } }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { startActivityForResult(p.createIntent(), REQ_FILE); true } catch (_: Exception) { fileCb = null; false }
            }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_PERMS)
        NotifyService.start(this)
        if (b != null) web.restoreState(b) else if (intent?.data?.scheme == "quickmessage") { open(null); web.postDelayed({ handleAuth(intent.data!!) }, 2500) } else open(intent)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i); setIntent(i)
        val d = i.data
        if (d != null && d.scheme == "quickmessage") handleAuth(d) else open(i)
    }

    /** quickmessage://auth?idToken=… comes back from the browser sign-in page (app-login.html). */
    private fun handleAuth(u: Uri) {
        val id = u.getQueryParameter("idToken") ?: ""
        val err = u.getQueryParameter("error") ?: ""
        val safe = Regex("^[\\w.\\-]+$")
        if (id.isNotEmpty() && safe.matches(id)) js("window.__qmGoogleSignIn&&window.__qmGoogleSignIn('$id','')")
        else js("window.__qmGoogleSignIn&&window.__qmGoogleSignIn('','" + Uri.encode(err) + "')")
    }

    private fun open(i: Intent?) {
        val chat = i?.getStringExtra(EXTRA_CHAT)
        if (i?.getBooleanExtra(EXTRA_RING, false) == true) {
            if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
            else window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        val safe = chat != null && Regex("^[\\w-]{1,64}$").matches(chat)
        if (!loaded || web.url == null) { web.loadUrl(Config.SITE_URL + "index.html" + if (safe) "?chat=$chat" else ""); return }
        if (safe) web.evaluateJavascript("window.QM&&QM.openChat&&QM.openChat('$chat')", null)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); web.saveState(o) }
    override fun onStart() { super.onStart(); visible = true; NotifyService.cancelAll(this) }
    override fun onStop() { super.onStop(); if (!pip) visible = false }
    override fun onResume() { super.onResume(); web.onResume(); web.resumeTimers() }
    // Never paused at all: a paused WebView freezes JavaScript timers and the page's live connections, which is what made the app drop
    // offline after a while in the background. (The foreground service + wake lock keep the process itself alive.)
    override fun onPause() { super.onPause() }
    override fun onDestroy() { if (instance === this) instance = null; web.destroy(); super.onDestroy() }

    override fun onUserLeaveHint() { if (inCall && callVisible) enterPipNow() }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, cfg: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPip, cfg)
        pip = isInPip
        if (!isInPip && !visible) visible = true
    }

    private var pipRatio = Rational(16, 9)
    private fun ratio(): Rational { val r = pipRatio.toDouble(); return if (r > 2.39) Rational(239, 100) else if (r < 0.42) Rational(42, 100) else pipRatio }   // Android only accepts 0.42 – 2.39
    /** Asks once to be exempt from battery optimisation, so Android doesn't cut the connection when the app is unused for a while. */
    @android.annotation.SuppressLint("BatteryLife")
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("quickmessage", MODE_PRIVATE)
        if (prefs.getBoolean("batteryAsked", false)) return
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(packageName)) {
            prefs.edit().putBoolean("batteryAsked", true).apply()
            try { startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
        }
    }

    private fun updatePip() {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val b = PictureInPictureParams.Builder().setAspectRatio(ratio())
            if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(inCall && callVisible)
            setPictureInPictureParams(b.build())
        } catch (_: Exception) {}
    }

    private fun enterPipNow() {
        if (Build.VERSION.SDK_INT < 26 || pip) return
        try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio()).build()) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { c ->
                if (on) { c.hide(WindowInsets.Type.systemBars()); c.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
                else c.show(WindowInsets.Type.systemBars())
            }
        } else run {
            window.decorView.systemUiVisibility = if (on) View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            else View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    /** Back is decided by the website (it minimises the call, closes the open chat, …) rather than walking WebView history,
     *  which could navigate a frame to a blank page. If the site has nothing to close, the app goes to the background. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) { web.webChromeClient?.onHideCustomView(); return }
        web.evaluateJavascript("(function(){try{return !!(window.QM&&QM.androidBack&&QM.androidBack())}catch(e){return false}})()") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    // ------------------------------------------------------------------ camera / microphone for calls
    private fun askWebPermission(r: PermissionRequest) {
        val need = ArrayList<String>()
        for (res in r.resources) {
            if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) need.add(Manifest.permission.CAMERA)
            if (res == PermissionRequest.RESOURCE_AUDIO_CAPTURE) need.add(Manifest.permission.RECORD_AUDIO)
        }
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { r.grant(r.resources); return }
        pendingWebPerm?.deny(); pendingWebPerm = r
        requestPermissions(missing.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 10) return
        val r = pendingWebPerm ?: return
        pendingWebPerm = null
        val granted = r.resources.filter {
            (it != PermissionRequest.RESOURCE_VIDEO_CAPTURE || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) &&
            (it != PermissionRequest.RESOURCE_AUDIO_CAPTURE || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        }
        if (granted.isEmpty()) r.deny() else r.grant(granted.toTypedArray())
    }

    // ------------------------------------------------------------------ screen share + results
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_FILE -> { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); fileCb = null }
            REQ_PROJECTION -> {
                if (res == RESULT_OK && data != null) {
                    ScreenService.onFrame = { b64 -> runOnUiThread { js("window.__qmScreenFrame&&window.__qmScreenFrame('$b64')") } }
                    ScreenService.onState = { st -> runOnUiThread { js("window.__qmScreenState&&window.__qmScreenState('$st')") } }
                    ScreenService.start(this, res, data)
                } else js("window.__qmScreenState&&window.__qmScreenState('denied')")
            }
        }
    }

    private fun js(code: String) { if (!isDestroyed) web.evaluateJavascript(code, null) }

    /** What the website can call (window.QMApp.*). */
    inner class Bridge {
        @JavascriptInterface fun isApp() = true

        /** Safe-area insets in CSS pixels, polled by js/bars.js in every frame. */
        @JavascriptInterface fun insets(): String = JSONObject().put("t", ins[0]).put("b", ins[1]).put("l", ins[2]).put("r", ins[3]).toString()
        @JavascriptInterface fun inPip() = pip
        @JavascriptInterface fun enterPip() = runOnUiThread { enterPipNow() }
        @JavascriptInterface fun enterPipSized(w: Int, h: Int) = runOnUiThread { if (w > 0 && h > 0) pipRatio = Rational(w.coerceIn(1, 4000), h.coerceIn(1, 4000)); enterPipNow() }

        /** The website says whether a call is up / on screen. */
        @JavascriptInterface fun setInCall(joined: Boolean, shown: Boolean) = runOnUiThread {
            inCall = joined; callVisible = joined && shown
            NotifyService.setCall(this@MainActivity, joined)
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.mode = if (joined) AudioManager.MODE_IN_COMMUNICATION else AudioManager.MODE_NORMAL
            if (joined) @Suppress("DEPRECATION") am.isSpeakerphoneOn = true
            updatePip()
        }

        @JavascriptInterface fun isDark(): Boolean = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES

        /** Google sign-in can't run inside a WebView, so it happens in the browser and comes back via quickmessage://auth. */
        @JavascriptInterface fun googleSignIn() = runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Config.SITE_URL + "app-login.html"))) } catch (_: Exception) { js("window.__qmGoogleSignIn&&window.__qmGoogleSignIn('','no-browser')") }
        }

        @JavascriptInterface fun openNotificationSettings() = runOnUiThread {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
            } catch (_: Exception) {}
        }

        /** The video being popped out: Android's PiP window takes its shape (updated as the video's size changes). */
        @JavascriptInterface fun setPipRatio(w: Int, h: Int) = runOnUiThread { pipRatio = if (w > 0 && h > 0) Rational(w.coerceIn(1, 4000), h.coerceIn(1, 4000)) else Rational(16, 9); updatePip() }

        @JavascriptInterface fun notifyEnabled() = Store(this@MainActivity).notify
        @JavascriptInterface fun canNotify() = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        @JavascriptInterface fun setNotify(on: Boolean) = runOnUiThread {
            Store(this@MainActivity).notify = on
            if (on) {
                if (Build.VERSION.SDK_INT >= 33 && !canNotify()) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_PERMS)
                NotifyService.start(this@MainActivity)
            } else if (!inCall) NotifyService.stop(this@MainActivity)
        }

        @JavascriptInterface fun startScreen() = runOnUiThread {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
        }

        @JavascriptInterface fun stopScreen() { ScreenService.stop(this@MainActivity) }

        @JavascriptInterface fun setSession(uid: String, refreshToken: String) {
            val s = Store(this@MainActivity)
            if (s.uid != uid || s.refreshToken != refreshToken) { s.uid = uid; s.refreshToken = refreshToken }
            NotifyService.start(this@MainActivity)
            runOnUiThread { askBatteryOnce() }
        }

        @JavascriptInterface fun logout() { Store(this@MainActivity).forget(); NotifyService.stop(this@MainActivity) }

        @JavascriptInterface fun clearCache() = runOnUiThread { web.clearCache(true) }   // HTTP cache only: signing in lives in site storage, which stays

        /** Colours the area behind the status and navigation bars like the site's background. */
        @JavascriptInterface fun setBars(color: String, lightBackground: Boolean) = runOnUiThread {
            try { barColor = Color.parseColor(color) } catch (_: Exception) { return@runOnUiThread }
            root.setBackgroundColor(barColor)
            if (Build.VERSION.SDK_INT >= 30) {
                val m = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                window.insetsController?.setSystemBarsAppearance(if (lightBackground) m else 0, m)
            } else {
                @Suppress("DEPRECATION") run {
                    var f = window.decorView.systemUiVisibility
                    f = if (lightBackground) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                    window.decorView.systemUiVisibility = f
                }
            }
        }
    }
}
