package app.quickmessage.companion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** After a reboot, bring the connection back so the website can see the phone as online. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || !Store(ctx).paired) return
        val svc = Intent(ctx, CompanionService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc) else ctx.startService(svc)
    }
}
